<?php
// akun.php
// Halaman akun penjual: lihat & edit data profil, ganti foto, ganti password
// Ditambahkan tombol "Kembali" (history.back())
// Pastikan koneksi mysqli di ../conn/koneksi.php

session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];

/* ============ UPLOAD CONFIG ============ */
$upload_base = __DIR__ . "/../uploads";
$upload_sub  = "penjual";
$upload_dir  = $upload_base . "/" . $upload_sub;

if (!is_dir($upload_dir)) {
    if (!mkdir($upload_dir, 0755, true) && !is_dir($upload_dir)) {
        error_log("Gagal membuat folder upload: $upload_dir");
    }
}

/* ============ HELPERS ============ */
function esc($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

function save_uploaded_foto_penjual(array $file, string $upload_dir, string $upload_sub, int $maxSize = 5*1024*1024) {
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];
    if (empty($file) || !isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) return '';
    if ($file['error'] !== UPLOAD_ERR_OK) return '';
    if ($file['size'] > $maxSize) return '';

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!isset($allowed[$mime])) return '';

    $ext = $allowed[$mime];
    $hash = hash_file('sha256', $file['tmp_name']);
    if ($hash === false) return '';

    $name = $hash . '.' . $ext;
    $target = rtrim($upload_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $name;

    if (!file_exists($target)) {
        if (!move_uploaded_file($file['tmp_name'], $target)) return '';
        @chmod($target, 0644);
    }

    return $upload_sub . '/' . $name;
}

/* ============ AMBIL DATA PENJUAL ============ */
$stm = $conn->prepare("SELECT * FROM penjual WHERE username = ? LIMIT 1");
$stm->bind_param("s", $username);
$stm->execute();
$penjual = $stm->get_result()->fetch_assoc();
$stm->close();

if (!$penjual) {
    session_destroy();
    header("Location: ../auth/login_users.php");
    exit;
}

$id_penjual = (int) $penjual['id_penjual'];

/* ============ HANDLE AJAX/POST ============ */
/*
 Expected POST actions:
 - update_profile: update nama_penjual, email, no_hp, alamat, status (optional) + foto (file)
 - change_password: old_password, new_password, confirm_password
 Responses: JSON { success:bool, message:string }
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    // update profile
    if (isset($_POST['update_profile'])) {
        $nama   = trim($_POST['nama'] ?? '');
        $email  = trim($_POST['email'] ?? '');
        $no_hp  = trim($_POST['no_hp'] ?? '');
        $alamat = trim($_POST['alamat'] ?? '');
        $status = in_array($_POST['status'] ?? '', ['online','offline']) ? $_POST['status'] : $penjual['status'];

        // handle foto upload
        $foto_baru = '';
        if (!empty($_FILES['foto']['name'])) {
            $foto_baru = save_uploaded_foto_penjual($_FILES['foto'], $upload_dir, $upload_sub);
        }

        // Begin update: use prepared statement
        if ($foto_baru !== '') {
            $stmt = $conn->prepare("UPDATE penjual SET nama_penjual=?, email=?, no_hp=?, alamat=?, foto=?, status=? WHERE id_penjual=?");
            $stmt->bind_param("ssssssi", $nama, $email, $no_hp, $alamat, $foto_baru, $status, $id_penjual);
        } else {
            $stmt = $conn->prepare("UPDATE penjual SET nama_penjual=?, email=?, no_hp=?, alamat=?, status=? WHERE id_penjual=?");
            $stmt->bind_param("sssssi", $nama, $email, $no_hp, $alamat, $status, $id_penjual);
        }

        $ok = $stmt->execute();
        $err = $stmt->error;
        $stmt->close();

        // if foto_baru set and old foto existed, remove old if no other reference
        if ($foto_baru !== '') {
            $old = $penjual['foto'] ?? '';
            if ($old && strpos($old, $upload_sub . '/') === 0 && $old !== $foto_baru) {
                $s = $conn->prepare("SELECT COUNT(*) AS cnt FROM penjual WHERE foto = ?");
                $s->bind_param("s", $old);
                $s->execute();
                $cnt = $s->get_result()->fetch_assoc()['cnt'] ?? 0;
                $s->close();
                if ((int)$cnt <= 0) {
                    $old_path = $upload_base . '/' . $old;
                    if (file_exists($old_path)) @unlink($old_path);
                }
            }
        }

        if ($ok) {
            // refresh session display data: re-fetch
            $stm = $conn->prepare("SELECT * FROM penjual WHERE id_penjual = ? LIMIT 1");
            $stm->bind_param("i", $id_penjual);
            $stm->execute();
            $penjual = $stm->get_result()->fetch_assoc();
            $stm->close();
            echo json_encode(['success' => true, 'message' => 'Profil berhasil diperbarui']);
            exit;
        } else {
            echo json_encode(['success' => false, 'message' => 'Update gagal: ' . $err]);
            exit;
        }
    }

    // change password
    if (isset($_POST['change_password'])) {
        $old = $_POST['old_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $conf = $_POST['confirm_password'] ?? '';

        if ($new === '' || strlen($new) < 6) {
            echo json_encode(['success' => false, 'message' => 'Password baru minimal 6 karakter']);
            exit;
        }
        if ($new !== $conf) {
            echo json_encode(['success' => false, 'message' => 'Konfirmasi password tidak cocok']);
            exit;
        }

        // verify old password
        $hash = $penjual['password'] ?? '';
        if (!password_verify($old, $hash)) {
            echo json_encode(['success' => false, 'message' => 'Password lama salah']);
            exit;
        }

        $new_hash = password_hash($new, PASSWORD_DEFAULT);
        $s = $conn->prepare("UPDATE penjual SET password = ? WHERE id_penjual = ?");
        $s->bind_param("si", $new_hash, $id_penjual);
        $ok = $s->execute();
        $err = $s->error;
        $s->close();

        if ($ok) {
            echo json_encode(['success' => true, 'message' => 'Password berhasil diubah']);
            exit;
        } else {
            echo json_encode(['success' => false, 'message' => 'Gagal mengubah password: ' . $err]);
            exit;
        }
    }

    // unknown action
    echo json_encode(['success' => false, 'message' => 'Aksi tidak dikenal']);
    exit;
}

/* ============ RENDER PAGE ============ */
?>
<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="utf-8">
<title>Akun Saya</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
body{font-family:Inter,Arial,sans-serif;background:#f5f6fa;padding:24px}
.container{max-width:920px;margin:0 auto;background:#fff;padding:20px;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.06)}
.header-row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}
h2{margin:0}
.back-btn{background:#e0e0e0;color:#333;border:none;padding:8px 12px;border-radius:8px;cursor:pointer;margin-right:10px}
.row{display:flex;gap:20px;align-items:flex-start}
.col{flex:1}
.profile-pic{width:150px;height:150px;border-radius:10px;object-fit:cover;border:1px solid #ddd}
.notice{
    display:none;
    padding:10px 12px;
    border-radius:8px;
    margin-top:12px;
    font-size:14px;
}
.notice.success{display:block;background:#e7f6ec;color:#166534;border:1px solid #b7e4c7;}
.notice.error{display:block;background:#fee2e2;color:#991b1b;border:1px solid #fecaca;}
.form-group{margin:10px 0}
label{display:block;font-weight:600;margin-bottom:6px}
input[type=text],input[type=email],input[type=number],textarea,select,input[type=password]{width:100%;padding:10px;border-radius:8px;border:1px solid #ccc}
button{background:#1e90ff;color:#fff;border:none;padding:10px 14px;border-radius:8px;cursor:pointer}
.small{font-size:13px;color:#666}
.success{color:green}
.error{color:#c00}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>
<div class="container">
    <?php
    $foto_path = $penjual['foto'] ? ('../uploads/' . preg_replace('#^(?:\.\./)?uploads/#', '', $penjual['foto'])) : '../uploads/default.png';
    ?>
    <div class="topbar-account">
        <div class="title">Profil</div>
        <div class="right">
            <?php renderNotifWidget('penjual', (int)$id_penjual); ?>
            <div class="user">
                <span><?= esc($penjual['nama_penjual']) ?></span>
                <img src="<?= esc($foto_path) ?>" alt="Profil">
            </div>
        </div>
    </div>
    <div class="header-row">
        <h2>Akun Saya</h2>
        <div>
            <!-- Tombol Kembali -->
            <button type="button" class="back-btn" onclick="window.history.back()">Kembali</button>
        </div>
        <?php renderNotifWidget('penjual', (int)$id_penjual); ?>
    </div>

    <div class="row">
        <div class="col" style="max-width:190px">
            <img src="<?= esc($foto_path) ?>" alt="Foto" class="profile-pic" id="profilePic">
            <p class="small">Foto saat ini</p>
        </div>

        <div class="col">
            <form id="profileForm" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Nama Penjual</label>
                    <input type="text" name="nama" value="<?= esc($penjual['nama_penjual']) ?>" required>
                </div>

                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" value="<?= esc($penjual['username']) ?>" disabled>
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?= esc($penjual['email']) ?>" required>
                </div>

                <div class="form-group">
                    <label>No. HP</label>
                    <input type="text" name="no_hp" value="<?= esc($penjual['no_hp']) ?>">
                </div>

                <div class="form-group">
                    <label>Alamat</label>
                    <textarea name="alamat" rows="3"><?= esc($penjual['alamat']) ?></textarea>
                </div>

                <div class="form-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="online" <?= $penjual['status']=='online' ? 'selected':'' ?>>online</option>
                        <option value="offline" <?= $penjual['status']=='offline' ? 'selected':'' ?>>offline</option>
                    </select>
                    <div class="small">Mengubah status hanya memengaruhi tampilan; gunakan fitur is_online untuk real-time.</div>
                </div>

                <div class="form-group">
                    <label>Ganti Foto (opsional)</label>
                    <input type="file" name="foto" accept="image/*" id="fotoInput">
                </div>

                <div class="form-group">
                    <button type="submit" id="saveProfileBtn">Simpan Perubahan</button>
                    <div id="profileMsg" class="notice"></div>
                </div>

                <input type="hidden" name="update_profile" value="1">
            </form>
        </div>
    </div>

    <hr style="margin:18px 0">

    <h3>Ganti Password</h3>
    <form id="pwForm">
        <div class="form-group">
            <label>Password Lama</label>
            <input type="password" name="old_password" required>
        </div>
        <div class="form-group">
            <label>Password Baru</label>
            <input type="password" name="new_password" required>
        </div>
        <div class="form-group">
            <label>Konfirmasi Password Baru</label>
            <input type="password" name="confirm_password" required>
        </div>
        <div class="form-group">
            <button type="submit">Ubah Password</button>
            <span id="pwMsg" class="small"></span>
        </div>
        <input type="hidden" name="change_password" value="1">
    </form>
</div>

<script>
$(function(){
    // preview foto saat dipilih
    $("#fotoInput").on("change", function(e){
        const f = this.files[0];
        if (!f) return;
        const url = URL.createObjectURL(f);
        $("#profilePic").attr("src", url);
    });

    $("#profileForm").on("submit", function(e){
        e.preventDefault();
        const form = new FormData(this);
        $("#saveProfileBtn").prop("disabled", true).text("Menyimpan...");
        $("#profileMsg").removeClass('error success').text('');

        $.ajax({
            url: 'akun.php',
            method: 'POST',
            data: form,
            processData: false,
            contentType: false,
            dataType: 'json'
        }).done(function(res){
            if (res.success) {
                $("#profileMsg").addClass('success').text(res.message);
                // reload page to reflect changes (foto path, etc.)
                setTimeout(()=> location.reload(), 800);
            } else {
                $("#profileMsg").addClass('error').text(res.message);
            }
        }).fail(function(){
            $("#profileMsg").addClass('error').text('Permintaan gagal. Coba lagi.');
        }).always(function(){
            $("#saveProfileBtn").prop("disabled", false).text("Simpan Perubahan");
        });
    });

    $("#pwForm").on("submit", function(e){
        e.preventDefault();
        const form = $(this).serialize();
        $("#pwMsg").removeClass('error success').text('');
        $.post('akun.php', form, function(res){
            if (res.success) {
                $("#pwMsg").addClass('success').text(res.message);
                $("#pwForm")[0].reset();
            } else {
                $("#pwMsg").addClass('error').text(res.message);
            }
        }, 'json').fail(function(){
            $("#pwMsg").addClass('error').text('Permintaan gagal. Coba lagi.');
        });
    });
});
</script>

</body>
</html>







