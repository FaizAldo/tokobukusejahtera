<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if(!isset($_SESSION['username'])){
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];

/* ================= DATA PENJUAL ================= */
$penjual = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT * FROM penjual WHERE username='$username'")
);
$id_penjual = $penjual['id_penjual'];

/* ================= UPDATE STATUS ================= */
if(isset($_POST['aksi']) && $_POST['aksi']=='status'){
    $id     = intval($_POST['id']);
    $status = $_POST['status'];

    $allowed = ['diproses','refund'];
    if(!in_array($status,$allowed)) exit;

    $info = mysqli_fetch_assoc(mysqli_query($conn,"
        SELECT id_pembeli, kode_pesanan
        FROM pesanan
        WHERE id_pesanan='$id' AND id_penjual='$id_penjual'
        LIMIT 1
    "));
    $id_pembeli = (int) ($info['id_pembeli'] ?? 0);
    $kode = $info['kode_pesanan'] ?? '-';

    mysqli_query($conn,"
        UPDATE pesanan 
        SET status='$status'
        WHERE id_pesanan='$id'
        AND id_penjual='$id_penjual'
        AND status='menunggu'
    ");

    if($id_pembeli > 0){
        if($status == 'diproses'){
            kirimNotif('pembeli', $id_pembeli, "Pesanan $kode sedang diproses penjual.", 'status.php');
            kirimNotifKeSuperadmin("Pesanan $kode diproses oleh penjual #$id_penjual.");
        } elseif($status == 'refund'){
            kirimNotif('pembeli', $id_pembeli, "Pesanan $kode berstatus refund.", 'status.php');
            kirimNotifKeSuperadmin("Pesanan $kode ditandai refund oleh penjual #$id_penjual.");
        }
    }
    exit;
}

/* ================= SIMPAN RESI ================= */
if(isset($_POST['aksi']) && $_POST['aksi']=='resi'){
    $id   = intval($_POST['id']);
    $resi = mysqli_real_escape_string($conn,$_POST['no_resi']);
    $link = mysqli_real_escape_string($conn,$_POST['link_lacak']);

    $info = mysqli_fetch_assoc(mysqli_query($conn,"
        SELECT id_pembeli, kode_pesanan
        FROM pesanan
        WHERE id_pesanan='$id' AND id_penjual='$id_penjual'
        LIMIT 1
    "));
    $id_pembeli = (int) ($info['id_pembeli'] ?? 0);
    $kode = $info['kode_pesanan'] ?? '-';

    mysqli_query($conn,"
        UPDATE pesanan 
        SET no_resi='$resi',
            link_lacak='$link',
            status='dikirim'
        WHERE id_pesanan='$id'
        AND id_penjual='$id_penjual'
        AND status='diproses'
    ");

    if($id_pembeli > 0){
        $resi_info = $resi ? " Resi: $resi." : '';
        kirimNotif('pembeli', $id_pembeli, "Pesanan $kode telah dikirim.$resi_info", 'status.php');
        kirimNotifKeSuperadmin("Pesanan $kode dikirim oleh penjual #$id_penjual.");
    }
    exit;
}

function renderApproveRows(mysqli $conn, int $id_penjual) {
    $q = mysqli_query($conn,"
        SELECT 
            p.id_pesanan,p.kode_pesanan,p.jumlah,p.total_harga,p.status,
            p.no_resi,p.link_lacak,p.bukti_transfer,p.metode_pembayaran,p.tanggal,
            pr.nama_produk,pr.foto,
            pb.username,pb.alamat
        FROM pesanan p
        JOIN produk pr ON p.id_produk = pr.id_produk
        JOIN pembeli pb ON p.id_pembeli = pb.id_pembeli
        WHERE p.id_penjual='$id_penjual'
        ORDER BY p.id_pesanan DESC
    ");
    while($r=mysqli_fetch_assoc($q)){
        ?>
        <tr>
        <td><?= $r['kode_pesanan'] ?: '-' ?></td>
        <td><?= htmlspecialchars($r['nama_produk']) ?></td>
        <td><?= $r['jumlah'] ?></td>
        <td>
        <?php if($r['bukti_transfer']){ ?>
        <img src="../uploads/<?= $r['bukti_transfer'] ?>" width="50"
             style="cursor:pointer"
             onclick="reviewBukti('../uploads/<?= $r['bukti_transfer'] ?>')">
        <?php } else { echo '-'; } ?>
        </td>
        <td><?= $r['metode_pembayaran'] ?: '-' ?></td>
        <td><b><?= strtoupper($r['status']) ?></b></td>
        <td>
        <?php if($r['no_resi']){ ?>
        <?= $r['no_resi'] ?><br>
        <a href="<?= $r['link_lacak'] ?>" target="_blank">Lacak</a>
        <?php } else { echo '-'; } ?>
        </td>
        <td><?= htmlspecialchars($r['alamat']) ?></td>
        <td><?= htmlspecialchars($r['username']) ?></td>
        <td>
        <?php if($r['status']=='menunggu'){ ?>
        <?php if($r['bukti_transfer']){ ?>
        <button onclick="popupProses(<?= $r['id_pesanan'] ?>)">Verifikasi</button>
        <?php } else { ?>
        <small style="color:red">Belum ada bukti</small>
        <?php } ?>
        <?php } elseif($r['status']=='diproses'){ ?>
        <button onclick="popupResi(<?= $r['id_pesanan'] ?>)">Input Resi</button>
        <?php } elseif($r['status']=='refund'){ ?>
        <span style="color:red;font-weight:bold">REFUND</span>
        <?php } else { ?>
        ✓
        <?php } ?>
        </td>
        </tr>
        <?php
    }
}

/* ================= LOAD DATA ================= */
if(isset($_GET['load'])){
    renderApproveRows($conn, (int)$id_penjual);
    exit;
$q = mysqli_query($conn,"
    SELECT 
        p.id_pesanan,p.kode_pesanan,p.jumlah,p.total_harga,p.status,
        p.no_resi,p.link_lacak,p.bukti_transfer,p.metode_pembayaran,p.tanggal,
        pr.nama_produk,pr.foto,
        pb.username,pb.alamat
    FROM pesanan p
    JOIN produk pr ON p.id_produk = pr.id_produk
    JOIN pembeli pb ON p.id_pembeli = pb.id_pembeli
    WHERE p.id_penjual='$id_penjual'
    ORDER BY p.id_pesanan DESC
");
while($r=mysqli_fetch_assoc($q)){
?>
<tr>
<td><?= $r['kode_pesanan'] ?: '-' ?></td>
<td><?= htmlspecialchars($r['nama_produk']) ?></td>
<td><?= $r['jumlah'] ?></td>
<td>
<?php if($r['bukti_transfer']){ ?>
<img src="../uploads/<?= $r['bukti_transfer'] ?>" width="50"
     style="cursor:pointer"
     onclick="reviewBukti('../uploads/<?= $r['bukti_transfer'] ?>')">
<?php } else { echo '-'; } ?>
</td>
<td><?= $r['metode_pembayaran'] ?: '-' ?></td>
<td><b><?= strtoupper($r['status']) ?></b></td>
<td>
<?php if($r['no_resi']){ ?>
<?= $r['no_resi'] ?><br>
<a href="<?= $r['link_lacak'] ?>" target="_blank">Lacak</a>
<?php } else { echo '-'; } ?>
</td>
<td><?= htmlspecialchars($r['alamat']) ?></td>
<td><?= htmlspecialchars($r['username']) ?></td>
<td>
<?php if($r['status']=='menunggu'){ ?>
<?php if($r['bukti_transfer']){ ?>
<button onclick="popupProses(<?= $r['id_pesanan'] ?>)">Verifikasi</button>
<?php } else { ?>
<small style="color:red">Belum ada bukti</small>
<?php } ?>
<?php } elseif($r['status']=='diproses'){ ?>
<button onclick="popupResi(<?= $r['id_pesanan'] ?>)">Input Resi</button>
<?php } elseif($r['status']=='refund'){ ?>
<span style="color:red;font-weight:bold">REFUND</span>
<?php } else { ?>
✓
<?php } ?>
</td>
</tr>
<?php } exit; } ?>
<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Approve Pesanan</title>

<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins}
body{display:flex;background:#f5f6fa}
.sidebar{width:230px;background:#8d4545;color:#fff;padding:20px;height:100vh}
.sidebar img{width:70px;height:70px;border-radius:50%}
.menu{list-style:none;padding:0;margin:0}
.menu li{list-style:none;margin:6px 0}
.menu a{display:block;color:#fff;padding:10px;text-decoration:none}
.menu a:hover{background:rgba(255,255,255,.2)}
main{flex:1;padding:25px}
.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    background:#fff;
    padding:12px 16px;
    border-radius:10px;
    margin-bottom:16px;
    box-shadow:0 4px 10px rgba(0,0,0,.06);
}
table{width:100%;border-collapse:collapse;background:#fff}
th,td{border:1px solid #ccc;padding:8px;text-align:center}
button{padding:6px 10px;background:#1e90ff;border:none;color:#fff;border-radius:6px}

/* MODAL */
.modal{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.7);
    justify-content:center;
    align-items:center;
    z-index:9999;
}
.modal > div{
    background:#fff;
    padding:15px;
    border-radius:10px;
    min-width:300px;
    max-width:420px;
    max-height:80vh;
    overflow:auto;
}

/* IMG BUKTI */
#imgBukti{
    width:100%;
    max-height:60vh;
    object-fit:contain;
    border-radius:8px;
    touch-action: pinch-zoom;
}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>

<body>

<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
<div class="menu">
<a href="dashboard_penjual.php">Dashboard</a>
<a href="admin.php">Penjual</a>
<a href="produk.php">Produk</a>
<a href="approve.php">Pesanan</a>
<a href="laporan.php">Laporan</a>
<a href="chat.php">Chat</a>
<a href="help.php">Help</a>
<a href="akun.php">My Account</a>
<a href="../auth/logout.php">Logout</a>
</div>
</div>

<main>
<div class="topbar">
    <h2>Pesanan Masuk</h2>
    <div class="right" style="display:flex;align-items:center;gap:12px;margin-left:auto;">
        <?php renderNotifWidget('penjual', (int)$id_penjual); ?>
        <div class="user" style="display:flex;align-items:center;gap:10px;">
            <span><?= htmlspecialchars($penjual['nama_penjual']); ?></span>
            <img src="../uploads/<?= htmlspecialchars($penjual['foto'] ?: 'default.png'); ?>" alt="Profil" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
        </div>
    </div>
</div>
<table>
<thead>
<tr>
<th>Kode</th><th>Produk</th><th>Qty</th><th>Bukti</th>
<th>Metode</th><th>Status</th><th>Resi</th>
<th>Alamat</th><th>Pembeli</th><th>Aksi</th>
</tr>
</thead>
<tbody id="data">
<?php renderApproveRows($conn, (int)$id_penjual); ?>
</tbody>
</table>
</main>

<!-- MODAL PROSES -->
<div class="modal" id="modalProses">
<div>
<h3>Verifikasi</h3>
<button onclick="setStatus('diproses')">Terima</button>
<button onclick="setStatus('refund')" style="background:#ef4444">Refund</button>
<button onclick="closeModal()">Batal</button>
</div>
</div>

<!-- MODAL RESI -->
<div class="modal" id="modalResi">
<div>
<h3>Input Resi</h3>
<input id="resiNo" placeholder="No Resi">
<input id="resiLink" placeholder="Link Lacak">
<button onclick="simpanResi()">Simpan</button>
<button onclick="closeModal()">Batal</button>
</div>
</div>

<!-- MODAL BUKTI -->
<div class="modal" id="modalBukti">
<div>
<h3>Bukti Transfer</h3>
<img id="imgBukti">
<br><br>
<button onclick="closeModal()">Tutup</button>
</div>
</div>

<script>
let currentId=0;

function load(){
    fetch('approve.php?load=1')
    .then(r=>r.text())
    .then(t=>data.innerHTML=t);
}

function reviewBukti(src){
    imgBukti.src = src;
    modalBukti.style.display='flex';
}
function closeModal(){
    modalProses.style.display = 'none';
    modalResi.style.display   = 'none';
    modalBukti.style.display  = 'none';

    // reset gambar biar ringan
    imgBukti.src = '';
}

function popupProses(id){ currentId=id; modalProses.style.display='flex'; }
function popupResi(id){ currentId=id; modalResi.style.display='flex'; }

function setStatus(st){
    let fd=new FormData();
    fd.append('aksi','status');
    fd.append('id',currentId);
    fd.append('status',st);
    fetch('approve.php',{method:'POST',body:fd})
    .then(()=>{closeModal();load();});
}

function simpanResi(){
    let fd=new FormData();
    fd.append('aksi','resi');
    fd.append('id',currentId);
    fd.append('no_resi',resiNo.value);
    fd.append('link_lacak',resiLink.value);
    fetch('approve.php',{method:'POST',body:fd})
    .then(()=>{closeModal();load();});
}

function closeModal(){
    modalProses.style.display='none';
    modalResi.style.display='none';
    modalBukti.style.display='none';
}

// setInterval(load,5000);
</script>

</body>
</html>








