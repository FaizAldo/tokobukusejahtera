<?php
// laporan.php
// Laporan yang mengambil data dari tabel pesanan dan transaksi (fallback).
// Pastikan koneksi mysqli di ../conn/koneksi.php

session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];
$halaman = basename($_SERVER['PHP_SELF']);

// ambil data penjual (untuk sidebar/profile)
$stmtp = $conn->prepare("SELECT * FROM penjual WHERE username = ? LIMIT 1");
$stmtp->bind_param("s", $username);
$stmtp->execute();
$penjual = $stmtp->get_result()->fetch_assoc();
$stmtp->close();
$id_penjual = (int) ($penjual['id_penjual'] ?? 0);

function esc($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

function bindParams(mysqli_stmt $stmt, string $types, array $params) {
    if ($types === '') return;
    $bind_names = [];
    $bind_names[] = $types;
    for ($i = 0; $i < count($params); $i++) {
        $bind_names[] = &$params[$i];
    }
    call_user_func_array([$stmt, 'bind_param'], $bind_names);
}

/* ================= INVOICE PER KODE PESANAN ================= */
if (isset($_GET['invoice'])) {
    $kode = trim((string)($_GET['invoice'] ?? ''));
    if ($kode === '') {
        http_response_code(400);
        echo 'Kode pesanan tidak valid.';
        exit;
    }

    $sql = "
        SELECT
            p.kode_pesanan,
            p.tanggal,
            p.metode_pembayaran,
            COALESCE(p.status, '-') AS status_pesanan,
            COALESCE(p.no_resi, '-') AS no_resi,
            COALESCE(p.link_lacak, '-') AS link_lacak,
            p.bukti_transfer,
            p.jumlah AS qty,
            COALESCE(NULLIF(pr.nama_produk, ''), NULLIF(pr.merek, ''), CONCAT('Produk #', p.id_produk)) AS nama_produk,
            COALESCE(pb.username, '-') AS pembeli,
            COALESCE(pb.no_hp, '-') AS no_hp,
            COALESCE(pb.alamat, '-') AS alamat,
            COALESCE(pn.nama_penjual, '-') AS penjual,
            COALESCE(p.total_modal, (p.harga * p.jumlah)) AS total_modal,
            COALESCE(p.total_harga, t.total) AS total_penjualan,
            (COALESCE(p.total_harga, t.total) - COALESCE(p.total_modal, (p.harga * p.jumlah))) AS total_keuntungan
        FROM pesanan p
        LEFT JOIN produk pr ON p.id_produk = pr.id_produk
        LEFT JOIN pembeli pb ON p.id_pembeli = pb.id_pembeli
        LEFT JOIN penjual pn ON p.id_penjual = pn.id_penjual
        LEFT JOIN transaksi t ON (t.id_produk = p.id_produk AND t.penjual_id = p.id_penjual AND t.pembeli_id = p.id_pembeli)
        WHERE p.id_penjual = ? AND p.kode_pesanan = ?
        ORDER BY p.id_pesanan ASC
    ";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        http_response_code(500);
        echo 'Gagal memuat invoice.';
        exit;
    }
    $stmt->bind_param("is", $id_penjual, $kode);
    $stmt->execute();
    $res = $stmt->get_result();
    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = $row;
    $stmt->close();

    if (!$rows) {
        http_response_code(404);
        echo 'Invoice tidak ditemukan.';
        exit;
    }

    $head = $rows[0];
    $sumQty = 0;
    $sumModal = 0.0;
    $sumJual = 0.0;
    $sumUntung = 0.0;
    foreach ($rows as $r) {
        $sumQty += (int)($r['qty'] ?? 0);
        $sumModal += (float)($r['total_modal'] ?? 0);
        $sumJual += (float)($r['total_penjualan'] ?? 0);
        $sumUntung += (float)($r['total_keuntungan'] ?? 0);
    }

    $buktiRel = !empty($head['bukti_transfer']) ? preg_replace('#^(?:\.\./)?uploads/#', '', $head['bukti_transfer']) : '';
    $buktiSrc = $buktiRel ? ('../uploads/' . $buktiRel) : '';

    header('Content-Type: text/html; charset=utf-8');
    ?>
    <!DOCTYPE html>
    <html>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invoice <?= esc($head['kode_pesanan']) ?></title>
    <style>
    body{font-family:Arial,sans-serif;font-size:12px;color:#111;margin:18px}
    h2{margin:0 0 8px}
    .meta{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px}
    .box{border:1px solid #ccc;border-radius:8px;padding:8px}
    .box p{margin:4px 0}
    .stats{display:grid;grid-template-columns:repeat(4,minmax(120px,1fr));gap:8px;margin:0 0 12px}
    .stats .item{border:1px solid #ccc;border-radius:8px;padding:8px;background:#fafafa}
    .stats .label{font-size:11px;color:#555}
    .stats .val{font-weight:700;margin-top:3px}
    table{width:100%;border-collapse:collapse}
    th,td{border:1px solid #ccc;padding:6px;text-align:center}
    th{background:#f5f5f5}
    .proof{margin-top:10px}
    .proof img{max-width:220px;max-height:150px;border:1px solid #ddd;border-radius:8px}
    .note{margin-top:8px;color:#666}
    @media print {.note{display:none}}
    </style>
    </head>
    <body>
        <h2>Invoice Transaksi</h2>
        <div class="meta">
            <div class="box">
                <p><b>Kode Pesanan:</b> <?= esc($head['kode_pesanan']) ?></p>
                <p><b>Tanggal:</b> <?= esc($head['tanggal']) ?></p>
                <p><b>Penjual:</b> <?= esc($head['penjual']) ?></p>
                <p><b>Pembeli:</b> <?= esc($head['pembeli']) ?></p>
                <p><b>No HP:</b> <?= esc($head['no_hp']) ?></p>
                <p><b>Alamat:</b> <?= esc($head['alamat']) ?></p>
            </div>
            <div class="box">
                <p><b>Metode Pembayaran:</b> <?= esc($head['metode_pembayaran']) ?></p>
                <p><b>Status:</b> <?= esc($head['status_pesanan']) ?></p>
                <p><b>No Resi:</b> <?= esc($head['no_resi']) ?></p>
                <p><b>Link Lacak:</b> <?= esc($head['link_lacak']) ?></p>
                <p><b>Jumlah Item:</b> <?= count($rows) ?></p>
                <p><b>Total QTY:</b> <?= number_format($sumQty, 0, ',', '.') ?></p>
            </div>
        </div>

        <div class="stats">
            <div class="item"><div class="label">Total Modal</div><div class="val">Rp <?= number_format($sumModal,0,',','.') ?></div></div>
            <div class="item"><div class="label">Total Penjualan</div><div class="val">Rp <?= number_format($sumJual,0,',','.') ?></div></div>
            <div class="item"><div class="label">Total Keuntungan</div><div class="val">Rp <?= number_format($sumUntung,0,',','.') ?></div></div>
            <div class="item"><div class="label">Total Baris</div><div class="val"><?= count($rows) ?> transaksi</div></div>
        </div>

        <table>
            <tr>
                <th>No</th>
                <th>Produk</th>
                <th>QTY</th>
                <th>Total Modal</th>
                <th>Total Penjualan</th>
                <th>Total Keuntungan</th>
            </tr>
            <?php $no = 1; foreach ($rows as $r): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= esc($r['nama_produk']) ?></td>
                    <td><?= (int)$r['qty'] ?></td>
                    <td>Rp <?= number_format((float)$r['total_modal'],0,',','.') ?></td>
                    <td>Rp <?= number_format((float)$r['total_penjualan'],0,',','.') ?></td>
                    <td>Rp <?= number_format((float)$r['total_keuntungan'],0,',','.') ?></td>
                </tr>
            <?php endforeach; ?>
        </table>

        <?php if ($buktiSrc): ?>
            <div class="proof">
                <b>Bukti Transfer:</b><br>
                <img src="<?= esc($buktiSrc) ?>" alt="Bukti Transfer">
            </div>
        <?php endif; ?>

        <div class="note">Invoice ini menampilkan semua transaksi yang terkait dengan kode pesanan tersebut.</div>
        <script>window.onload = function(){ window.print(); };</script>
    </body>
    </html>
    <?php
    exit;
}

/* ================= DOWNLOAD (PDF ONLY) ================= */
if (isset($_GET['download']) && ($_GET['download']=='pdf')) {
    $month = (int) ($_GET['month'] ?? 0);
    $year  = (int) ($_GET['year'] ?? 0);

    $sql = "
        SELECT
            p.kode_pesanan,
            COALESCE(NULLIF(pr.nama_produk, ''), NULLIF(pr.merek, ''), p.kode_pesanan) AS judul_buku,
            COALESCE(pb.username, '-') AS pembeli,
            p.jumlah AS qty,
            p.bukti_transfer AS bukti_transfer,
            p.metode_pembayaran AS metode,
            COALESCE(p.status, '-') AS status_pesanan,
            COALESCE(p.no_resi, '-') AS no_resi,
            COALESCE(p.link_lacak, '-') AS link_lacak,
            COALESCE(p.total_modal, (p.harga * p.jumlah)) AS total_modal,
            COALESCE(p.total_harga, t.total) AS total_penjualan,
            (COALESCE(p.total_harga, t.total) - COALESCE(p.total_modal, (p.harga * p.jumlah))) AS total_keuntungan,
            p.tanggal
        FROM pesanan p
        LEFT JOIN produk pr ON p.id_produk = pr.id_produk
        LEFT JOIN pembeli pb ON p.id_pembeli = pb.id_pembeli
        LEFT JOIN transaksi t ON (t.id_produk = p.id_produk AND t.penjual_id = p.id_penjual AND t.pembeli_id = p.id_pembeli)
        WHERE p.id_penjual = ?
    ";

    $types = "i";
    $params = [$id_penjual];
    if ($month) {
        $sql .= " AND MONTH(p.tanggal) = ?";
        $types .= "i";
        $params[] = $month;
    }
    if ($year) {
        $sql .= " AND YEAR(p.tanggal) = ?";
        $types .= "i";
        $params[] = $year;
    }
    $sql .= " ORDER BY p.tanggal DESC";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        if ($types !== '') bindParams($stmt, $types, $params);
        $stmt->execute();
        $res = $stmt->get_result();
    } else {
        $res = $conn->query($sql);
    }

    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $rootPath = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
    $baseUploadUrl = $scheme . '://' . $host . $rootPath . '/uploads/';
    $normBukti = function($val){
        $rel = $val ? preg_replace('#^(?:\.\./)?uploads/#', '', $val) : '';
        return $rel;
    };

    header('Content-Type: text/html; charset=utf-8');

    $imgDataUri = function($path){
        if (!$path || !file_exists($path)) return '';
        $data = @file_get_contents($path);
        if ($data === false) return '';
        $mime = 'image/png';
        if (function_exists('finfo_open')) {
            $f = finfo_open(FILEINFO_MIME_TYPE);
            if ($f) {
                $m = finfo_file($f, $path);
                if ($m) $mime = $m;
                finfo_close($f);
            }
        } else {
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if ($ext === 'jpg' || $ext === 'jpeg') $mime = 'image/jpeg';
            elseif ($ext === 'gif') $mime = 'image/gif';
            elseif ($ext === 'webp') $mime = 'image/webp';
        }
        return 'data:'.$mime.';base64,'.base64_encode($data);
    };

    echo '<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8"><title>Laporan Penjualan</title><style>
        body{font-family:Arial, sans-serif; font-size:11px; margin:20px; color:#111;}
        h2{margin:0 0 10px;}
        .stats{display:grid;grid-template-columns:repeat(5,minmax(120px,1fr));gap:8px;margin:0 0 12px;}
        .stats .box{border:1px solid #ccc;border-radius:6px;padding:6px;background:#fafafa;}
        .stats .label{font-size:10px;color:#666;}
        .stats .val{font-size:13px;font-weight:700;color:#111;margin-top:2px;}
        table{width:100%;border-collapse:collapse;}
        th,td{border:1px solid #ccc;padding:6px;text-align:center;word-break:break-word;}
        th{background:#f1f5f9;}
        td img{width:40px;height:40px;object-fit:cover;border-radius:6px;}
        .note{margin-top:10px;color:#666;font-size:10px;}
        @media print{.note{display:none;}}
    </style></head><body>';
    echo '<h2>Laporan Penjualan</h2>';
    $rows = [];
    $sum_qty = 0;
    $sum_modal = 0.0;
    $sum_penjualan = 0.0;
    $sum_keuntungan = 0.0;
    while ($row = $res->fetch_assoc()) {
        $rows[] = $row;
        $sum_qty += (int)($row['qty'] ?? 0);
        $sum_modal += (float)($row['total_modal'] ?? 0);
        $sum_penjualan += (float)($row['total_penjualan'] ?? 0);
        $sum_keuntungan += (float)($row['total_keuntungan'] ?? 0);
    }
    echo '<div class="stats">
        <div class="box"><div class="label">Total Pesanan</div><div class="val">'.count($rows).'</div></div>
        <div class="box"><div class="label">Total QTY</div><div class="val">'.number_format($sum_qty,0,',','.').'</div></div>
        <div class="box"><div class="label">Total Modal</div><div class="val">Rp '.number_format($sum_modal,0,',','.').'</div></div>
        <div class="box"><div class="label">Total Penjualan</div><div class="val">Rp '.number_format($sum_penjualan,0,',','.').'</div></div>
        <div class="box"><div class="label">Total Keuntungan</div><div class="val">Rp '.number_format($sum_keuntungan,0,',','.').'</div></div>
    </div>';
    echo '<table><tr><th>Kode Pesanan</th><th>Pembeli</th><th>Judul/Merek</th><th>QTY</th><th>Bukti</th><th>Metode Pembayaran</th><th>Status</th><th>No Resi / Lacak</th><th>Total Modal</th><th>Total Penjualan</th><th>Total Keuntungan</th><th>Tanggal</th></tr>';
    foreach ($rows as $row) {
        $bukti_rel = $normBukti($row['bukti_transfer'] ?? '');
        $bukti_path = $bukti_rel ? (__DIR__ . '/../uploads/' . $bukti_rel) : '';
        $bukti_src = $bukti_path ? $imgDataUri($bukti_path) : '';
        echo '<tr>';
        echo '<td>'.esc($row['kode_pesanan']).'</td>';
        echo '<td>'.esc($row['pembeli']).'</td>';
        echo '<td>'.esc($row['judul_buku']).'</td>';
        echo '<td>'.(int)$row['qty'].'</td>';
        echo $bukti_src ? '<td><img src="'.$bukti_src.'"></td>' : '<td>-</td>';
        echo '<td>'.esc($row['metode']).'</td>';
        echo '<td>'.esc($row['status_pesanan']).'</td>';
        $resiLacak = esc($row['no_resi']);
        if (!empty($row['link_lacak']) && $row['link_lacak'] !== '-') {
            $resiLacak .= '<br><small>'.esc($row['link_lacak']).'</small>';
        }
        echo '<td>'.$resiLacak.'</td>';
        echo '<td>'.esc($row['total_modal']).'</td>';
        echo '<td>'.esc($row['total_penjualan']).'</td>';
        echo '<td>'.esc($row['total_keuntungan']).'</td>';
        echo '<td>'.esc($row['tanggal']).'</td>';
        echo '</tr>';
    }
    echo '</table><div class="note">Gunakan Print &gt; Save as PDF untuk menyimpan sebagai PDF.</div>
    <script>window.onload=function(){window.print();};</script></body></html>';
    exit;
}

/* ================= AJAX STATS ================= */
if (isset($_GET['stats'])) {
    $month = (int) ($_GET['month'] ?? 0);
    $year  = (int) ($_GET['year'] ?? 0);

    $sql = "
        SELECT
            COUNT(*) AS total_pesanan,
            COALESCE(SUM(p.jumlah), 0) AS total_qty,
            COALESCE(SUM(COALESCE(p.total_modal, (p.harga * p.jumlah))), 0) AS total_modal,
            COALESCE(SUM(COALESCE(p.total_harga, t.total)), 0) AS total_penjualan,
            COALESCE(SUM(COALESCE(p.total_harga, t.total) - COALESCE(p.total_modal, (p.harga * p.jumlah))), 0) AS total_keuntungan
        FROM pesanan p
        LEFT JOIN transaksi t ON (t.id_produk = p.id_produk AND t.penjual_id = p.id_penjual AND t.pembeli_id = p.id_pembeli)
        WHERE p.id_penjual = ?
    ";

    $types = "i";
    $params = [$id_penjual];
    if ($month) {
        $sql .= " AND MONTH(p.tanggal) = ?";
        $types .= "i";
        $params[] = $month;
    }
    if ($year) {
        $sql .= " AND YEAR(p.tanggal) = ?";
        $types .= "i";
        $params[] = $year;
    }

    $result = [
        'total_pesanan' => 0,
        'total_qty' => 0,
        'total_modal' => 0,
        'total_penjualan' => 0,
        'total_keuntungan' => 0
    ];

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        if ($types !== '') bindParams($stmt, $types, $params);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if ($row) {
            $result = [
                'total_pesanan' => (int)($row['total_pesanan'] ?? 0),
                'total_qty' => (int)($row['total_qty'] ?? 0),
                'total_modal' => (float)($row['total_modal'] ?? 0),
                'total_penjualan' => (float)($row['total_penjualan'] ?? 0),
                'total_keuntungan' => (float)($row['total_keuntungan'] ?? 0)
            ];
        }
        $stmt->close();
    }

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($result);
    exit;
}

/* ================= AJAX LOAD ================= */
if (isset($_GET['load'])) {
    $month = (int) ($_GET['month'] ?? 0);
    $year  = (int) ($_GET['year'] ?? 0);

    $sql = "
        SELECT
            p.kode_pesanan,
            COALESCE(NULLIF(pr.nama_produk, ''), NULLIF(pr.merek, ''), p.kode_pesanan) AS judul_buku,
            COALESCE(pb.username, '-') AS pembeli,
            p.jumlah AS qty,
            p.bukti_transfer AS bukti_transfer,
            p.metode_pembayaran AS metode,
            COALESCE(p.status, '-') AS status_pesanan,
            COALESCE(p.no_resi, '-') AS no_resi,
            COALESCE(p.link_lacak, '-') AS link_lacak,
            COALESCE(p.total_modal, (p.harga * p.jumlah)) AS total_modal,
            COALESCE(p.total_harga, t.total) AS total_penjualan,
            (COALESCE(p.total_harga, t.total) - COALESCE(p.total_modal, (p.harga * p.jumlah))) AS total_keuntungan,
            p.tanggal
        FROM pesanan p
        LEFT JOIN produk pr ON p.id_produk = pr.id_produk
        LEFT JOIN pembeli pb ON p.id_pembeli = pb.id_pembeli
        LEFT JOIN transaksi t ON (t.id_produk = p.id_produk AND t.penjual_id = p.id_penjual AND t.pembeli_id = p.id_pembeli)
        WHERE p.id_penjual = ?
    ";

    $types = "i";
    $params = [$id_penjual];
    if ($month) {
        $sql .= " AND MONTH(p.tanggal) = ?";
        $types .= "i";
        $params[] = $month;
    }
    if ($year) {
        $sql .= " AND YEAR(p.tanggal) = ?";
        $types .= "i";
        $params[] = $year;
    }
    $sql .= " ORDER BY p.tanggal DESC";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        if ($types !== '') bindParams($stmt, $types, $params);
        $stmt->execute();
        $res = $stmt->get_result();
    } else {
        $res = $conn->query($sql);
    }

    while ($r = $res->fetch_assoc()) {
        $bukti_rel = $r['bukti_transfer'] ? preg_replace('#^(?:\.\./)?uploads/#', '', $r['bukti_transfer']) : '';
        $img_src = $bukti_rel ? ('../uploads/' . esc($bukti_rel)) : '../uploads/default.png';
        ?>
        <tr>
            <td><?= esc($r['kode_pesanan']) ?></td>
            <td><?= esc($r['pembeli']) ?></td>
            <td><?= esc($r['judul_buku']) ?></td>
            <td><?= (int)$r['qty'] ?></td>
            <td style="text-align:center;">
                <?php if ($bukti_rel): ?>
                    <img src="<?= esc($img_src) ?>" class="proof-img" alt="bukti" onclick="viewImage('<?= esc($bukti_rel) ?>')">
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
            <td><?= esc($r['metode']) ?></td>
            <td><?= esc($r['status_pesanan']) ?></td>
            <td>
                <?= esc($r['no_resi']) ?>
                <?php if (!empty($r['link_lacak']) && $r['link_lacak'] !== '-'): ?>
                    <br><a href="<?= esc($r['link_lacak']) ?>" target="_blank" rel="noopener">Lacak</a>
                <?php endif; ?>
            </td>
            <td><?= esc($r['total_modal']) ?></td>
            <td><?= esc($r['total_penjualan']) ?></td>
            <td><?= esc($r['total_keuntungan']) ?></td>
            <td><?= esc($r['tanggal']) ?></td>
        </tr>
        <?php
    }

    if (isset($stmt) && $stmt) $stmt->close();
    exit;
}

/* ================= PAGE RENDER ================= */
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<title>Laporan</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
*{box-sizing:border-box}
body{font-family:Inter,Arial,sans-serif;background:#f5f6fa;margin:0;font-size:13px}
:root{
    --sidebar-w: 260px;
    --main-gap: 24px;
}
.sidebar{
    width:var(--sidebar-w);position:fixed;left:0;top:0;bottom:0;background:linear-gradient(180deg,#8d4545,#6b2f2f);
    color:#fff;padding:20px;overflow:auto;box-shadow:none;border-right:none;
}
.sidebar{scrollbar-width:none;-ms-overflow-style:none;}
.sidebar::-webkit-scrollbar{width:0;height:0;}
.sidebar .inner{display:flex;flex-direction:column;gap:12px}
.profile{text-align:center;margin-bottom:12px}
.profile .avatar{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.12)}
.profile h3{margin:6px 0 2px;font-size:14px}
.profile span{font-size:12px;color:#e6f5f3}
.menu{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:8px}
.menu a{display:block;padding:6px 8px;border-radius:6px;color:#fff;text-decoration:none;font-size:13px}
.main{margin-left:calc(var(--sidebar-w) + var(--main-gap));width:calc(100% - var(--sidebar-w) - var(--main-gap));padding:24px 24px 24px 0}
.topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;gap:12px}
.topbar h2{margin:0;font-size:24px}
.topbar .mid{flex:1;display:flex;justify-content:center}
.topbar .controls{justify-content:flex-end}
.controls{display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:flex-end}
.select, .btn {padding:8px 12px;border-radius:8px;border:1px solid #ccc;background:#fff;cursor:pointer}
.btn.primary{background:#1e90ff;color:#fff;border:none}
.btn.download{display:flex;align-items:center;gap:8px;background:#fff;border:2px solid #111;padding:8px 12px;border-radius:20px;cursor:pointer}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin:0 0 14px}
.stat-card{background:#fff;border:1px solid #d1d5db;padding:10px 12px;border-radius:10px}
.stat-label{font-size:12px;color:#555}
.stat-value{font-size:18px;font-weight:700;color:#111;margin-top:4px}
.table-wrap{
    width:100%;
    max-width:100%;
    border:1px solid #e5e7eb;
    border-radius:12px;
    background:#fff;
    overflow:hidden;
}
.table{
    width:100%;
    border-collapse:separate;
    border-spacing:0;
    table-layout:fixed;
    min-width:0;
    font-size:11px;
}
thead th{
    position:sticky;
    top:0;
    background:#f8fafc;
    z-index:3;
    font-weight:700;
}
th,td{
    border-right:1px solid #d1d5db;
    border-bottom:1px solid #d1d5db;
    padding:7px 6px;
    text-align:center;
    vertical-align:middle;
    white-space:normal;
    word-break:break-word;
    overflow-wrap:anywhere;
}
th:first-child, td:first-child{border-left:1px solid #d1d5db;}
thead tr:first-child th{border-top:1px solid #d1d5db;}
tbody tr:nth-child(even){background:#fcfcfc;}
tbody tr:hover{background:#f3f4f6;}
th:nth-child(2), td:nth-child(2),
th:nth-child(3), td:nth-child(3){
    text-align:left;
}
.proof-img{width:40px;height:40px;object-fit:cover;border-radius:6px;cursor:pointer;border:1px solid #ddd}
.footer-note{margin-top:12px;color:#666;font-size:12px;text-align:left}
/* Override widget to sit in topbar center */
.topbar .notif-widget{position:static !important; top:auto !important; right:auto !important; z-index:10;}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="inner">
      <div class="profile">
          <?php
          $avatar = $penjual['foto'] ? ('../uploads/' . preg_replace('#^(?:\.\./)?uploads/#', '', $penjual['foto'])) : '../uploads/default.png';
          ?>
          <img src="<?= esc($avatar) ?>" class="avatar" alt="avatar">
          <h3><?= esc($penjual['nama_penjual'] ?? '') ?></h3>
          <span>@<?= esc($penjual['username'] ?? '') ?></span>
      </div>

    <ul class="menu">
        <li><a href="dashboard_penjual.php">Dashboard</a></li>
        <li><a href="admin.php">Penjual</a></li>
        <li><a href="produk.php">Produk</a></li>
        <li><a href="approve.php">Approve</a></li>
        <li><a href="laporan.php" style="font-weight:700">Laporan</a></li>
        <li><a href="chat.php">Chat</a></li>
        <hr>
        <li><a href="help.php">Help</a></li>
        <li><a href="akun.php">My Account</a></li>
        <li><a href="../auth/logout.php">Sign Out</a></li>
    </ul>
  </div>
</div>

<!-- MAIN -->
<div class="main">
    <div class="topbar">
        <h2>Laporan</h2>
        <div class="controls">
            <?php renderNotifWidget('penjual', (int)($penjual['id_penjual'] ?? 0)); ?>
            <select id="month" class="select" title="Bulan">
                <option value="0" selected>Semua Bulan</option>
                <?php for ($m=1;$m<=12;$m++): ?>
                    <option value="<?= $m ?>"><?= date('F', mktime(0,0,0,$m,1)) ?></option>
                <?php endfor; ?>
            </select>

            <select id="year" class="select" title="Tahun">
                <option value="0" selected>Semua Tahun</option>
                <?php
                $currentYear = (int)date('Y');
                for ($y = $currentYear; $y >= $currentYear-5; $y--): ?>
                    <option value="<?= $y ?>"><?= $y ?></option>
                <?php endfor; ?>
            </select>

            <div style="position:relative;">
                <button id="btnDownload" class="btn download" type="button" title="Download">
                    ⤓ DOWNLOAD
                </button>
                <div id="downloadMenu" style="display:none;position:absolute;right:0;top:40px;background:#fff;border:1px solid #ddd;border-radius:8px;box-shadow:0 8px 20px rgba(0,0,0,.1);padding:6px;min-width:140px;z-index:50;">
                    <a href="#" id="downloadPdf" style="display:block;padding:8px 10px;border-radius:6px;color:#111;text-decoration:none;">Download PDF</a>
                </div>
            </div>
            <div class="user" style="display:flex;align-items:center;gap:10px;margin-left:8px;">
                <span><?= esc($penjual['nama_penjual'] ?? '') ?></span>
                <img src="<?= esc($avatar) ?>" alt="Profil" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
            </div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-label">Total Pesanan</div>
            <div class="stat-value" id="statPesanan">0</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total QTY</div>
            <div class="stat-value" id="statQty">0</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Modal</div>
            <div class="stat-value" id="statModal">Rp 0</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Penjualan</div>
            <div class="stat-value" id="statPenjualan">Rp 0</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Keuntungan</div>
            <div class="stat-value" id="statKeuntungan">Rp 0</div>
        </div>
    </div>

    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Kode Pesanan</th>
                    <th>Pembeli</th>
                    <th>Merek / Judul</th>
                    <th>QTY</th>
                    <th>Bukti</th>
                    <th>Metode Bayar</th>
                    <th>Status</th>
                    <th>No Resi / Lacak</th>
                    <th>Modal</th>
                    <th>Penjualan</th>
                    <th>Keuntungan</th>
                    <th>Tgl</th>
                </tr>
            </thead>
            <tbody id="tbody">
                <!-- rows loaded by AJAX -->
            </tbody>
        </table>
    </div>

    <div class="footer-note">
        <span id="summaryText"></span>
    </div>
</div>

<!-- image modal -->
<div id="modalImage" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);align-items:center;justify-content:center;z-index:9999">
    <div style="background:#fff;padding:12px;border-radius:8px;max-width:90%;max-height:90%;overflow:auto">
        <div style="text-align:right"><button onclick="$('#modalImage').hide()" class="btn">Tutup</button></div>
        <div style="text-align:center"><img id="modalImageImg" src="" style="max-width:100%;height:auto;border-radius:6px;border:1px solid #ddd"></div>
    </div>
</div>

<script>
function formatRupiahClient(num){
    return "Rp " + Number(num || 0).toLocaleString("id-ID", {maximumFractionDigits: 0});
}

function loadStats(){
    var month = $("#month").val();
    var year  = $("#year").val();
    $.getJSON("laporan.php?stats=1&month="+encodeURIComponent(month)+"&year="+encodeURIComponent(year), function(res){
        $("#statPesanan").text((res.total_pesanan || 0).toLocaleString("id-ID"));
        $("#statQty").text((res.total_qty || 0).toLocaleString("id-ID"));
        $("#statModal").text(formatRupiahClient(res.total_modal));
        $("#statPenjualan").text(formatRupiahClient(res.total_penjualan));
        $("#statKeuntungan").text(formatRupiahClient(res.total_keuntungan));
    });
}

function loadData(){
    var month = $("#month").val();
    var year  = $("#year").val();
    $("#tbody").load("laporan.php?load=0&month="+encodeURIComponent(month)+"&year="+encodeURIComponent(year), function(){
        var rows = $("#tbody tr").length;
        $("#summaryText").text(rows + " baris laporan ditampilkan.");
    });
    loadStats();
}

$(function(){
    loadData();

    $("#month, #year").on("change", function(){
        loadData();
    });

    $("#btnDownload").on("click", function(e){
        e.preventDefault();
        $("#downloadMenu").toggle();
    });
    $(document).on("click", function(e){
        if (!$(e.target).closest("#btnDownload, #downloadMenu").length) {
            $("#downloadMenu").hide();
        }
    });
    $("#downloadPdf").on("click", function(e){
        e.preventDefault();
        var month = $("#month").val();
        var year  = $("#year").val();
        window.location = "laporan.php?download=pdf&month="+encodeURIComponent(month)+"&year="+encodeURIComponent(year);
    });
});

// image modal
function viewImage(path){
    $("#modalImageImg").attr("src","../uploads/"+path);
    $("#modalImage").css("display","flex");
}
</script>
</body>
</html>
