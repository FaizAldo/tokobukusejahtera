<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if(!isset($_SESSION['username'])){
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];
$penjual = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT * FROM penjual WHERE username='$username'")
);
if(!$penjual){
    session_destroy();
    header("Location: ../auth/login_users.php");
    exit;
}

$penjuals = mysqli_query($conn,"
    SELECT id_penjual, nama_penjual, username, email, no_hp, foto, created_at
    FROM penjual
    ORDER BY id_penjual DESC
");

$halaman = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<title>Penjual | Penjual</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins}
body{background:#f5f6fa;color:#333}

/* SIDEBAR */
.sidebar{
    width:260px;height:100vh;position:fixed;left:0;top:0;
    background:linear-gradient(180deg,#8d4545,#8a4545);
    color:#fff;padding:20px;overflow-y:auto;
}
.profile{text-align:center;margin-bottom:25px}
.profile .avatar{width:75px;height:75px;border-radius:50%;object-fit:cover;border:3px solid #fff}
.profile h3{margin:8px 0 0;font-size:17px}
.profile span{font-size:13px;opacity:.85}
.menu{list-style:none;padding:0}
.menu li{margin:6px 0}
.menu li a{display:block;padding:11px 14px;border-radius:8px;color:#fff;text-decoration:none;transition:.25s}
.menu li a:hover{background:rgba(255,255,255,0.2)}
.menu li.active a{background:rgba(255,255,255,0.3);font-weight:bold}
.menu hr{border:none;border-top:1px solid rgba(255,255,255,0.3);margin:12px 0}
.logout a{background:#ef4444}

/* MAIN */
main{margin-left:260px;padding:24px}
.page-title{font-size:22px;margin-bottom:12px}
.sub{color:#666;margin-bottom:18px}

.admin-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}
.card{
    background:#fff;border-radius:12px;padding:16px;
    box-shadow:0 4px 12px rgba(0,0,0,.06);
    display:flex;gap:12px;align-items:center;
}
.card img{width:60px;height:60px;border-radius:50%;object-fit:cover;border:2px solid #eee}
.card h4{margin:0 0 4px}
.card .meta{font-size:12px;color:#666}
.card .email{font-size:13px;color:#1e90ff}
.help-box{
    margin-top:20px;background:#fff;border-radius:12px;padding:16px;
    box-shadow:0 4px 12px rgba(0,0,0,.06);
}
.help-box a{
    display:inline-block;margin-top:8px;background:#1e90ff;color:#fff;
    padding:8px 12px;border-radius:8px;text-decoration:none;
}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="profile">
        <img src="../uploads/<?= $penjual['foto']; ?>" class="avatar">
        <h3><?= $penjual['nama_penjual']; ?></h3>
        <span>@<?= $penjual['username']; ?></span>
    </div>
    <?php renderNotifWidget('penjual', (int)$penjual['id_penjual']); ?>

    <ul class="menu">
        <li class="<?= $halaman=='dashboard_penjual.php'?'active':'' ?>">
            <a href="dashboard_penjual.php">Dashboard</a>
        </li>
        <li class="<?= $halaman=='admin.php'?'active':'' ?>">
            <a href="admin.php">Penjual</a>
        </li>
        <li class="<?= $halaman=='produk.php'?'active':'' ?>">
            <a href="produk.php">Produk</a>
        </li>
        <li class="<?= $halaman=='approve.php'?'active':'' ?>">
            <a href="approve.php">Approve</a>
        </li>
        <li class="<?= $halaman=='laporan.php'?'active':'' ?>">
            <a href="laporan.php">Laporan</a>
        </li>
        <li class="<?= $halaman=='chat.php'?'active':'' ?>">
            <a href="chat.php">Chat</a>
        </li>
        <hr>
        <li class="<?= $halaman=='help.php'?'active':'' ?>">
            <a href="help.php">Help</a>
        </li>
        <li class="<?= $halaman=='akun.php'?'active':'' ?>">
            <a href="akun.php">My Account</a>
        </li>
        <li class="logout">
            <a href="../auth/logout.php">Sign Out</a>
        </li>
    </ul>
</div>

<!-- MAIN -->
<main>
    <div class="topbar-account">
        <div class="title">Profil</div>
        <div class="right">
            <?php renderNotifWidget('penjual', (int)$penjual['id_penjual']); ?>
            <div class="user">
                <span><?= htmlspecialchars($penjual['nama_penjual']); ?></span>
                <img src="../uploads/<?= htmlspecialchars($penjual['foto'] ?: 'default.png'); ?>" alt="Profil">
            </div>
        </div>
    </div>
    <div class="page-title">Daftar Penjual</div>
    <div class="sub">Daftar penjual yang terdaftar di sistem.</div>

    <div class="admin-grid">
        <?php if($penjuals && mysqli_num_rows($penjuals) > 0): ?>
            <?php while($p = mysqli_fetch_assoc($penjuals)): ?>
                <div class="card">
                    <img src="../uploads/<?= htmlspecialchars($p['foto'] ?: 'default.png'); ?>" alt="Penjual">
                    <div>
                        <h4><?= htmlspecialchars($p['nama_penjual'] ?: $p['username']); ?></h4>
                        <div class="email"><?= htmlspecialchars($p['email']); ?></div>
                        <div class="meta">@<?= htmlspecialchars($p['username']); ?> · <?= htmlspecialchars($p['no_hp']); ?></div>
                        <div class="meta">Terdaftar: <?= htmlspecialchars($p['created_at']); ?></div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="card">Belum ada penjual.</div>
        <?php endif; ?>
    </div>

    <div class="help-box">
        Butuh bantuan khusus? Gunakan halaman Help untuk mengirim pesan ke tim support.
        <br>
        <a href="help.php">Ke Help</a>
    </div>
</main>

</body>
</html>








