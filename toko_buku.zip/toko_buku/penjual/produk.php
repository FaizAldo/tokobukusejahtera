<?php
// produk.php
// diperbarui: perbaikan bug gambar, koreksi bind_param, normalisasi path foto
// catatan: sesuaikan koneksi $conn (mysqli) di include '../conn/koneksi.php'

session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];

/* ================= UPLOAD CONFIG ================= */
$upload_base = __DIR__ . "/../uploads"; // absolute-ish
$upload_sub  = "buku"; // subfolder di dalam uploads
$upload_dir  = $upload_base . "/" . $upload_sub;

// pastikan folder uploads/buku ada
if (!is_dir($upload_dir)) {
    if (!mkdir($upload_dir, 0755, true) && !is_dir($upload_dir)) {
        error_log("Gagal membuat folder upload: $upload_dir");
    }
}

/* ================= DATA PENJUAL ================= */
$stmt = $conn->prepare("SELECT * FROM penjual WHERE username = ? LIMIT 1");
$stmt->bind_param("s", $username);
$stmt->execute();
$penjual = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$penjual) {
    session_destroy();
    header("Location: ../auth/login_users.php");
    exit;
}

$id_penjual = (int) $penjual['id_penjual'];
$has_total_modal = false;
$colCheck = $conn->query("SHOW COLUMNS FROM produk LIKE 'total_modal'");
if ($colCheck instanceof mysqli_result) {
    $has_total_modal = ($colCheck->num_rows > 0);
    $colCheck->close();
}

/* ================= HELPERS ================= */
function save_uploaded_foto(array $file, string $upload_dir, string $upload_sub, int $maxSize = 5*1024*1024) {
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];

    if (empty($file) || !isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return '';
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return '';
    }

    if ($file['size'] > $maxSize) {
        return '';
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!isset($allowed[$mime])) {
        return '';
    }

    $ext = $allowed[$mime];
    $hash = hash_file('sha256', $file['tmp_name']);
    if ($hash === false) {
        return '';
    }

    $foto_name = $hash . '.' . $ext;
    $target_path = rtrim($upload_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $foto_name;

    if (!file_exists($target_path)) {
        if (!move_uploaded_file($file['tmp_name'], $target_path)) {
            return '';
        }
        @chmod($target_path, 0644);
    }

    return $upload_sub . '/' . $foto_name;
}

function esc($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

function bindParams(mysqli_stmt $stmt, string $types, array $params) {
    if ($types === '') return;
    // bind_param requires references
    $bind_names = [];
    $bind_names[] = $types;
    for ($i = 0; $i < count($params); $i++) {
        $bind_names[] = &$params[$i];
    }
    call_user_func_array([$stmt, 'bind_param'], $bind_names);
}

function renderProdukList(mysqli $conn, int $id_penjual, bool $has_total_modal = false, string $search = '', string $kategori = '') {
    $sql = "
        SELECT p.*, k.nama_kategori
        FROM produk p
        LEFT JOIN kategori k ON p.kategori_id = k.id_kategori
        WHERE p.penjual_id = ?
    ";
    $types = "i";
    $params = [$id_penjual];

    if ($search !== '') {
        $sql .= " AND p.nama_produk LIKE ?";
        $types .= "s";
        $params[] = '%' . $search . '%';
    }
    if ($kategori !== '') {
        $sql .= " AND p.kategori_id = ?";
        $types .= "i";
        $params[] = (int)$kategori;
    }

    $sql .= " ORDER BY p.id_produk DESC";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        bindParams($stmt, $types, $params);
        $stmt->execute();
        $res = $stmt->get_result();
    } else {
        $res = $conn->query("SELECT p.*, k.nama_kategori FROM produk p LEFT JOIN kategori k ON p.kategori_id=k.id_kategori WHERE p.penjual_id='$id_penjual' ORDER BY p.id_produk DESC");
    }

    while ($p = $res->fetch_assoc()) {
        $raw_foto = $p['foto'] ?? '';
        if ($raw_foto) {
            $foto_rel = preg_replace('#^(?:\.\./)?uploads/#', '', $raw_foto);
        } else {
            $foto_rel = '';
        }
        $img_src = $foto_rel ? '../uploads/' . esc($foto_rel) : '../uploads/default.png';
        ?>
        <div class="produk-card" id="produk_<?= (int)$p['id_produk'] ?>" data-foto="<?= esc($foto_rel) ?>">
            <img src="<?= esc($img_src) ?>" alt="<?= esc($p['nama_produk']) ?>">
            <h4><?= esc($p['nama_produk']) ?></h4>
            <small><?= esc($p['nama_kategori']) ?></small>
            <p>Rp <?= number_format($p['harga']) ?></p>
            <p>Stok: <?= (int)$p['stok'] ?></p>
            <?php if ($has_total_modal): ?>
                <p>Total modal: Rp <?= number_format((float)($p['total_modal'] ?? 0)) ?></p>
            <?php endif; ?>

            <div class="aksi">
                <button onclick="editProduk(
                    <?= (int)$p['id_produk'] ?>,
                    '<?= esc($p['nama_produk']) ?>',
                    '<?= esc($p['harga']) ?>',
                    '<?= (int)$p['stok'] ?>',
                    '<?= (int)$p['kategori_id'] ?>',
                    '<?= esc((string)($p['total_modal'] ?? 0)) ?>'
                )">Edit</button>

                <button class="hapus" onclick="hapus(<?= (int)$p['id_produk'] ?>)">Hapus</button>
            </div>
        </div>
        <?php
    }

    if (isset($stmt) && $stmt) $stmt->close();
}

/* ================= LOAD PRODUK (AJAX) ================= */
if (isset($_GET['load'])) { // load=0 atau load=1 keduanya terdeteksi

    $search   = trim($_GET['search'] ?? '');
    $kategori = trim($_GET['kategori'] ?? '');

    renderProdukList($conn, $id_penjual, $has_total_modal, $search, $kategori);
    exit;
}

function parseCurrencyInput($value): float {
    $raw = trim((string)$value);
    if ($raw === '') return 0.0;
    $normalized = str_replace([' ', ','], ['', '.'], $raw);
    return (float)$normalized;
}

/* ================= TAMBAH ================= */
if (isset($_POST['tambah'])) {

    $foto = '';
    if (!empty($_FILES['foto']['name'])) {
        $foto = save_uploaded_foto($_FILES['foto'], $upload_dir, $upload_sub);
    }

    $nama        = $_POST['nama'] ?? '';
    $harga       = (float) ($_POST['harga'] ?? 0);
    $stok        = (int)   ($_POST['stok'] ?? 0);
    $kategori_id = (int)   ($_POST['kategori'] ?? 0);
    $total_modal = parseCurrencyInput($_POST['total_modal'] ?? 0);

    if ($has_total_modal) {
        $stmt = $conn->prepare("INSERT INTO produk (penjual_id, nama_produk, harga, stok, kategori_id, total_modal, foto, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        if ($stmt) {
            $stmt->bind_param("isdiids", $id_penjual, $nama, $harga, $stok, $kategori_id, $total_modal, $foto);
            $stmt->execute();
            $stmt->close();
        }
    } else {
        $stmt = $conn->prepare("INSERT INTO produk (penjual_id, nama_produk, harga, stok, kategori_id, foto, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        if ($stmt) {
            $stmt->bind_param("isdiis", $id_penjual, $nama, $harga, $stok, $kategori_id, $foto);
            $stmt->execute();
            $stmt->close();
        }
    }
    exit;
}

/* ================= UPDATE ================= */
if (isset($_POST['update'])) {

    $id = (int) ($_POST['id'] ?? 0);

    // ambil foto saat ini di DB
    $stmt = $conn->prepare("SELECT foto FROM produk WHERE id_produk = ? AND penjual_id = ? LIMIT 1");
    $stmt->bind_param("ii", $id, $id_penjual);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $current_foto_db = $row ? $row['foto'] : '';

    // handle upload baru
    $foto_baru = '';
    if (!empty($_FILES['foto']['name'])) {
        $foto_baru = save_uploaded_foto($_FILES['foto'], $upload_dir, $upload_sub);
    }

    // jika tidak ada upload baru, tetap gunakan foto DB (tidak diubah)
    $nama        = $_POST['nama'] ?? '';
    $harga       = (float) ($_POST['harga'] ?? 0);
    $stok        = (int)   ($_POST['stok'] ?? 0);
    $kategori_id = (int)   ($_POST['kategori'] ?? 0);
    $total_modal = parseCurrencyInput($_POST['total_modal'] ?? 0);

    if ($foto_baru !== '') {
        if ($has_total_modal) {
            $stmt = $conn->prepare("UPDATE produk SET nama_produk=?, harga=?, stok=?, kategori_id=?, total_modal=?, foto=? WHERE id_produk=? AND penjual_id=?");
            if ($stmt) {
                $stmt->bind_param("sdiidsii", $nama, $harga, $stok, $kategori_id, $total_modal, $foto_baru, $id, $id_penjual);
                $stmt->execute();
                $stmt->close();
            }
        } else {
            // FIX: types string harus cocok dengan parameter (nama s, harga d, stok i, kategori i, foto s, id i, penjual i)
            $stmt = $conn->prepare("UPDATE produk SET nama_produk=?, harga=?, stok=?, kategori_id=?, foto=? WHERE id_produk=? AND penjual_id=?");
            if ($stmt) {
                $stmt->bind_param("sdiisii", $nama, $harga, $stok, $kategori_id, $foto_baru, $id, $id_penjual);
                $stmt->execute();
                $stmt->close();
            }
        }
    } else {
        if ($has_total_modal) {
            $stmt = $conn->prepare("UPDATE produk SET nama_produk=?, harga=?, stok=?, kategori_id=?, total_modal=? WHERE id_produk=? AND penjual_id=?");
            if ($stmt) {
                $stmt->bind_param("sdiidii", $nama, $harga, $stok, $kategori_id, $total_modal, $id, $id_penjual);
                $stmt->execute();
                $stmt->close();
            }
        } else {
            // tidak mengubah kolom foto
            $stmt = $conn->prepare("UPDATE produk SET nama_produk=?, harga=?, stok=?, kategori_id=? WHERE id_produk=? AND penjual_id=?");
            if ($stmt) {
                $stmt->bind_param("sdiiii", $nama, $harga, $stok, $kategori_id, $id, $id_penjual);
                $stmt->execute();
                $stmt->close();
            }
        }
    }

    // jika ada foto baru, dan foto lama berbeda, hapus file lama jika tidak direferensikan
    if ($foto_baru !== '' && $current_foto_db && $current_foto_db !== $foto_baru && strpos($current_foto_db, $upload_sub . '/') === 0) {
        $stmt = $conn->prepare("SELECT COUNT(*) as cnt FROM produk WHERE foto = ?");
        $stmt->bind_param("s", $current_foto_db);
        $stmt->execute();
        $cntRow = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $refs = intval($cntRow['cnt'] ?? 0);
        if ($refs <= 0 || $refs == 1) {
            $old_path = $upload_base . '/' . $current_foto_db;
            if (file_exists($old_path)) {
                @unlink($old_path);
            }
        }
    }

    exit;
}

/* ================= HAPUS ================= */
if (isset($_POST['hapus'])) {
    $id_hapus = (int) ($_POST['hapus'] ?? 0);

    // ambil foto sebelum hapus
    $stmt = $conn->prepare("SELECT foto FROM produk WHERE id_produk = ? AND penjual_id = ? LIMIT 1");
    $stmt->bind_param("ii", $id_hapus, $id_penjual);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $foto_to_delete = $row ? $row['foto'] : '';

    // hapus record
    $stmt = $conn->prepare("DELETE FROM produk WHERE id_produk = ? AND penjual_id = ?");
    $stmt->bind_param("ii", $id_hapus, $id_penjual);
    $stmt->execute();
    $stmt->close();

    // hapus file fisik jika aman (tidak default dan tidak direferensikan produk lain)
    if ($foto_to_delete && strpos($foto_to_delete, $upload_sub . '/') === 0) {
        $stmt = $conn->prepare("SELECT COUNT(*) as cnt FROM produk WHERE foto = ?");
        $stmt->bind_param("s", $foto_to_delete);
        $stmt->execute();
        $cntRow = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $refs = intval($cntRow['cnt'] ?? 0);
        if ($refs <= 0) {
            $path = $upload_base . '/' . $foto_to_delete;
            if (file_exists($path)) {
                @unlink($path);
            }
        }
    }

    exit;
}

/* ================= KATEGORI ================= */
$kategori = $conn->query("SELECT * FROM kategori");

/* ================= PAGE ================= */
$halaman = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<title>Produk Penjual</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins}
body{background:#f5f6fa}

/* SIDEBAR */
.sidebar{
    width:260px;
    height:100vh;
    position:fixed;
    left:0;top:0;
    background:linear-gradient(180deg,#8d4545,#6b2f2f);
    color:#fff;
    padding:20px;
}
/* ================= MENU SIDEBAR ================= */
.menu{
    list-style:none;
    padding:0;
    margin:20px 0 0;
    display:flex;
    flex-direction:column;
    gap:6px;
}

/* ITEM */
.menu li{
    border-radius:12px;
    overflow:hidden;
}

/* LINK */
.menu li a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:12px 16px;
    text-decoration:none;
    color:#fff;
    font-size:14px;
    transition:.25s;
}

/* HOVER */
.menu li:hover{
    background:rgba(255,255,255,.15);
    transform:translateX(6px);
}

/* MENU AKTIF */
.menu li.active{
    background:#8d4545 !important;
}

.menu li.active a{
    color:#fff !important;
    font-weight:700;
}

/* GARIS */
.menu hr{
    border:none;
    height:1px;
    background:rgba(255,255,255,.3);
    margin:12px 0;
}

/* LOGOUT */
.menu .logout{
    margin-top:auto;
    background:#ff4d4d;
}

.menu .logout a{
    color:#fff;
    font-weight:600;
}

.menu .logout:hover{
    background:#ff2f2f;
}
/* ================= TOPBAR ================= */
.topbar{
    position:fixed;
    top:0;
    left:260px;
    right:0;
    height:65px;
    background:#fff;
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 25px;
    box-shadow:0 5px 15px rgba(0,0,0,.08);
    z-index:999;
}

/* kiri */
.topbar .left{
    display:flex;
    align-items:center;
    gap:15px;
}

/* ================= TOP SEARCH ================= */
.top-search{
    position:relative;
    width:320px;
    display:flex;
    align-items:center;
    gap:10px;
}

.top-search input{
    width:100%;
    height:40px;
    padding:0 16px 0 42px;
    border-radius:25px;
    border:1px solid #ddd;
    background:#f7f8fa;
    font-size:14px;
    outline:none;
    transition:.25s;
}
/* tombol cari */
#searchTopBtn{
    height:40px;
    padding:0 14px;
    border:none;
    border-radius:10px;
    background:#8d4545;
    color:#fff;
    font-weight:600;
    cursor:pointer;
    white-space:nowrap;
    transition:background .2s, transform .2s;
}
#searchTopBtn:hover{background:#6b2f2f;}
#searchTopBtn:active{transform:scale(0.98);}

/* ICON SEARCH */
.top-search::before{
    content:"🔍";
    position:absolute;
    left:15px;
    top:9px;
    font-size:16px;
    opacity:.6;
}

/* FOCUS EFFECT */
.top-search input:focus{
    background:#fff;
    border-color:#1e90ff;
    box-shadow:0 0 0 3px rgba(30,144,255,.15);
}

/* top actions */
.top{
    display:flex;
    align-items:center;
    gap:10px;
}
.top .btn-add{
    margin-left:auto;
    height:42px;
    padding:0 14px;
    border:none;border-radius:12px;
    background:#8d4545;color:#fff;
    font-size:14px;font-weight:700;
    display:inline-flex;
    align-items:center;
    gap:8px;
    cursor:pointer;
    box-shadow:0 6px 14px rgba(0,0,0,.12);
}
.top .btn-add:hover{background:#6b2f2f;}

/* RESPONSIVE */
@media(max-width:768px){
    .top-search{
        width:200px;
    }
}

/* kanan */
.topbar .right{
    display:flex;
    align-items:center;
    gap:20px;
    margin-left:auto;
}

.topbar .user{
    display:flex;
    align-items:center;
    gap:10px;
    cursor:pointer;
}

.topbar .user img{
    width:38px;
    height:38px;
    border-radius:50%;
    object-fit:cover;
}

/* notifikasi */
.notif{
    position:relative;
    font-size:20px;
    cursor:pointer;
    color:#111;
}

.notif .badge{
    position:absolute;
    top:-6px;
    right:-6px;
    background:red;
    color:#fff;
    font-size:11px;
    padding:2px 6px;
    border-radius:50%;
}

/* KONTEN */
main{
    margin-left:260px;
    padding:25px;
}

/* FILTER */
.top{
    display:flex;
    gap:10px;
    margin:20px 0;
}
.top input,.top select{
    padding:10px;
    border-radius:10px;
    border:1px solid #ccc;
}
.top button{
    background:#1e90ff;
    color:#fff;
    border:none;
    padding:10px 20px;
    border-radius:10px;
}

/* GRID */
.produk-grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,200px);
    gap:20px;
}

/* CARD */
.produk-card{
    background:#fff;
    padding:15px;
    border-radius:18px;
    box-shadow:0 5px 15px rgba(0,0,0,.08);
    transition:.3s;
}
.produk-card:hover{
    transform:translateY(-5px);
}
.produk-card img{
    width:100%;
    height:150px;
    object-fit:cover;
    border-radius:12px;
}
.produk-card h4{font-size:15px;margin:8px 0}
.produk-card small{color:#888}
.produk-card p{font-weight:600;margin:5px 0}

/* BUTTON */
.aksi{display:flex;gap:6px}
.aksi button{
    flex:1;
    border:none;
    padding:7px;
    border-radius:8px;
    cursor:pointer;
}
.aksi button:first-child{background:#1e90ff;color:#fff}
.aksi .hapus{background:#ff4d4d;color:#fff}

/* MODAL */
#modal{
    display:none;
    position:fixed;
    inset:0;
    background:#0007;
}
#modal form{
    width:380px;
    background:#fff;
    margin:80px auto;
    padding:20px;
    border-radius:18px;
}
#modal input,#modal select{
    width:100%;
    padding:10px;
    margin:7px 0;
    border-radius:10px;
    border:1px solid #ccc;
}
#foto_preview img{width:120px;height:90px;object-fit:cover;border-radius:8px;margin-bottom:8px;}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>

<body>

<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>

    <!-- MENU -->
    <ul class="menu">

        <li class="<?= $halaman=='dashboard_penjual.php'?'active':'' ?>">
            <a href="dashboard_penjual.php">Dashboard</a>
        </li>

        <li class="<?= $halaman=='admin.php'?'active':'' ?>">
            <a href="admin.php">Penjual</a>
        </li>

        <li class="<?= $halaman=='produk.php'?'active':'' ?>">
            <a href="produk.php">Produk</a>
        </li>

        <li class="<?= $halaman=='approve.php'?'active':'' ?>">
            <a href="approve.php">Approve</a>
        </li>

        <li class="<?= $halaman=='laporan.php'?'active':'' ?>">
            <a href="laporan.php">Laporan</a>
        </li>

        <li class="<?= $halaman=='chat.php'?'active':'' ?>">
            <a href="chat.php">Chat</a>
        </li>

        <hr>

        <li class="<?= $halaman=='help.php'?'active':'' ?>">
            <a href="help.php">Help</a>
        </li>

        <li class="<?= $halaman=='akun.php'?'active':'' ?>">
            <a href="akun.php">My Account</a>
        </li>

        <li class="logout">
            <a href="../auth/logout.php">Sign Out</a>
        </li>

    </ul>
</div>
<!-- TOPBAR -->
<div class="topbar">


<div class="top-search">
    <input type="text" id="searchTop" placeholder="Cari produk...">
    <button type="button" id="searchTopBtn">Cari</button>
</div>

    <div class="right">
        <?php renderNotifWidget('penjual', (int)$id_penjual); ?>
        <div class="user">
            <img src="../uploads/<?= esc($penjual['foto'] ?: 'default.png') ?>">
            <span><?= esc($penjual['nama_penjual']) ?></span>
        </div>
    </div>

</div>

<main>
<h2>Produk</h2>

<div class="top">
    <input type="hidden" id="search" value="">
    <select id="kategori">
        <option value="">Semua Kategori</option>
        <?php
        if ($kategori && $kategori instanceof mysqli_result) {
            $kategori->data_seek(0);
            while($k = $kategori->fetch_assoc()){ ?>
                <option value="<?= (int)$k['id_kategori'] ?>"><?= esc($k['nama_kategori']) ?></option>
        <?php }
        }
        ?>
    </select>
    <button class="btn-add" onclick="openTambah()">+ Tambah Produk</button>
</div>

<div id="data" class="produk-grid">
<?php renderProdukList($conn, $id_penjual, $has_total_modal, '', ''); ?>
</div>
</main>

<!-- MODAL -->
<div id="modal" style="display:none;">
<form id="form" enctype="multipart/form-data">
<input type="hidden" name="id" id="id">
<input type="hidden" name="current_foto" id="current_foto">

<div id="foto_preview" style="display:none;">
    <img id="foto_preview_img" src="" alt="Preview">
</div>

<input type="text" name="nama" id="nama" placeholder="Nama produk" required>
<input type="number" name="harga" id="harga" placeholder="Harga" required>
<input type="number" name="total_modal" id="total_modal" placeholder="Total modal" min="0" step="0.01" required>
<input type="number" name="stok" id="stok" placeholder="Stok" required>

<select name="kategori" id="kategori_form" required>
<?php
if ($kategori && $kategori instanceof mysqli_result) {
    $kategori->data_seek(0);
    while($k = $kategori->fetch_assoc()){ ?>
        <option value="<?= (int)$k['id_kategori'] ?>"><?= esc($k['nama_kategori']) ?></option>
<?php }
}
?>
</select>

<input type="file" name="foto" id="foto_input" accept="image/*">

<button type="submit" id="btn">Simpan</button>
<button type="button" onclick="closeModal()">Batal</button>
</form>
</div>

<script>
let loadToken = 0;
function loadData(){
    const token = ++loadToken;
    const url = "produk.php?load=0&search=" + encodeURIComponent($("#search").val()) +
        "&kategori=" + encodeURIComponent($("#kategori").val()) + "&_t=" + Date.now();
    fetch(url, { credentials: 'same-origin', cache: 'no-store' })
        .then(r => r.text())
        .then(html => {
            if (token !== loadToken) return;
            $("#data").html(html);
        })
        .catch(() => {});
}

$("#kategori").on("change", loadData);

function openTambah(){
    $("#form")[0].reset();
    $("#btn").attr("name","tambah");
    $("#current_foto").val('');
    $("#foto_preview").hide();
    $("#modal").show();
}

function closeModal(){
    $("#modal").hide();
}

function editProduk(id,nama,harga,stok,kategori,total_modal){
    $("#id").val(id);
    $("#nama").val(nama);
    $("#harga").val(harga);
    $("#total_modal").val(total_modal);
    $("#stok").val(stok);
    $("#kategori_form").val(kategori);
    $("#btn").attr("name","update");

    // ambil foto dari data attribute card
    var fotoPath = $("#produk_" + id).data("foto") || "";
    $("#current_foto").val(fotoPath);

    if (fotoPath) {
        $("#foto_preview_img").attr("src", "../uploads/" + fotoPath);
        $("#foto_preview").show();
    } else {
        $("#foto_preview").hide();
    }

    $("#foto_input").val('');
    $("#modal").show();
}

$("#form").submit(function(e){
    e.preventDefault();
    var form = new FormData(this);
    var btnName = $("#btn").attr("name") || "tambah";
    form.append(btnName, "1");

    var fileInput = document.getElementById('foto_input');
    if (btnName === 'update' && fileInput.files.length === 0) {
        // pastikan current_foto tetap dikirim (hidden input sudah ada)
        form.set('current_foto', $("#current_foto").val() || '');
    }

    $.ajax({
        url:'produk.php',
        type:'POST',
        data: form,
        processData:false,
        contentType:false,
        success:function(){
            loadData();
            $("#modal").hide();
        }
    });
});

function hapus(id){
    if(confirm("Hapus produk?")){
        $.post("produk.php",{hapus:id}, loadData);
    }
}

let delay;
$("#searchTop").on("keyup", function (e) {
    if (e.key === 'Enter') {
        $("#kategori").val('');
        $("#search").val(this.value);
        loadData();
        return;
    }
    clearTimeout(delay);
    var self = this;
    delay = setTimeout(() => {
        $("#kategori").val('');
        $("#search").val(self.value);
        loadData();
    }, 300);
});
$("#searchTopBtn").on("click", function () {
    $("#kategori").val('');
    $("#search").val($("#searchTop").val());
    loadData();
});

// optional polling tiap 5s
// setInterval(loadData, 5000);
</script>

</body>
</html>








