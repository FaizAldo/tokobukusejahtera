<?php
session_start();
include '../conn/koneksi.php';

if(!isset($_SESSION['username'])){
    echo json_encode(['total'=>0,'html'=>'']);
    exit;
}

$username = $_SESSION['username'];
$user = mysqli_fetch_assoc(mysqli_query($conn,"SELECT id_penjual FROM penjual WHERE username='$username'"));
$id_penjual = $user['id_penjual'] ?? 0;

/* HITUNG NOTIF BARU */
$q = mysqli_query($conn,"
    SELECT COUNT(*) AS total
    FROM notifikasi
    WHERE id_penjual='$id_penjual'
    AND status='baru'
");

$data = mysqli_fetch_assoc($q);

/* AMBIL DATA */
$list = mysqli_query($conn,"
    SELECT * FROM notifikasi
    WHERE id_penjual='$id_penjual'
    ORDER BY id_notif DESC
    LIMIT 5
");

$html = '';
while($n = mysqli_fetch_assoc($list)){
    $html .= "
        <div class='notif-item ".($n['status']=='baru'?'new':'')."'>
            {$n['pesan']}
        </div>
    ";
}

echo json_encode([
    'total'=>$data['total'],
    'html'=>$html
]);

