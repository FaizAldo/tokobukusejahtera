<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if(!isset($_SESSION['username'])){
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];

// Ambil id_penjual
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_penjual FROM penjual WHERE username='$username'"));
$id_penjual = $user['id_penjual'] ?? 0;


// Ambil data penjual
$penjual = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM penjual WHERE username='$username'"));

date_default_timezone_set('Asia/Jakarta');
$today = date('Y-m-d');
$today_readable = date('l, d F Y');

// Pesanan pending
$pesanan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM pesanan WHERE id_penjual='$id_penjual' AND status='pending'"));

// Daftar pesanan untuk tabel
$pesanan_list = mysqli_query($conn, "
    SELECT p.kode_pesanan, pr.nama_produk, pb.username, pb.alamat, pb.no_hp, pb.email,
           p.status, p.total_harga, p.tanggal
    FROM pesanan p
    JOIN produk pr ON p.id_produk = pr.id_produk
    JOIN pembeli pb ON p.id_pembeli = pb.id_pembeli
    WHERE p.id_penjual='$id_penjual'
    ORDER BY p.id_pesanan DESC
    LIMIT 10
");

// Semua kategori
$kategori_result = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama_kategori ASC");

// Ambil 5 pesan terbaru dari pembeli
$latestMessages = [];
$msgQuery = mysqli_query($conn, "
    SELECT id_message, pembeli_id, message, created_at 
    FROM messages 
    WHERE penjual_id='$id_penjual' AND sender='pembeli'
    ORDER BY created_at DESC 
    LIMIT 5
");
while($row = mysqli_fetch_assoc($msgQuery)){
    $latestMessages[] = $row;
}

// AJAX untuk update realtime (card + popup)
if(isset($_GET['ajax']) && $_GET['ajax']=='1'){
    echo json_encode([
        'pesanan' => $pesanan['total'],
        'latestMessages' => $latestMessages
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<script src="../assets/responsive.js" defer></script>
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Penjual Realtime</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;}
body{display:flex;background:#f5f6fa;color:#333;overflow-y:auto;}
.sidebar{width:260px;height:100vh;background:linear-gradient(180deg,#8d4545,#8a4545);position:fixed;left:0;top:0;color:#fff;padding:20px;overflow-y:auto;}
.profile{text-align:center;margin-bottom:25px;}
.profile .avatar{width:75px;height:75px;border-radius:50%;object-fit:cover;border:3px solid #fff;}
.profile h3{margin:8px 0 0;font-size:17px;}
.profile span{font-size:13px;opacity:0.85;}
.menu{list-style:none;padding:0;}
.menu li{margin:6px 0;}
.menu li a{display:block;padding:11px 14px;border-radius:8px;color:#fff;text-decoration:none;transition:0.25s;}
.menu li a:hover{background: rgba(255,255,255,0.2);}
.logout a{background:#ef4444;}
main{flex:1;padding:20px;margin-left:260px;overflow-y:visible;}
header{background:#743e3e;color:#fff;padding:15px 30px;display:flex;justify-content:space-between;align-items:center;border-radius:10px;margin-bottom:20px;}
header .search-box input{padding:7px 15px;border-radius:25px;border:none;width:250px;transition:0.3s;}
header .actions{display:flex;align-items:center;gap:20px;margin-left:auto;}
header .actions .user-info{display:flex;align-items:center;gap:10px;}
header .actions .notif{position:relative;cursor:pointer;font-size:20px;color:#111;}
header .actions .notif span{position:absolute;top:-8px;right:-8px;background:#ff4757;color:#fff;border-radius:50%;font-size:12px;padding:2px 6px;font-weight:600;}
header .actions .notif .notif-box{
    display:none;
    position:absolute;
    right:0;top:28px;
    background:#fff !important;
    border:1px solid #eee;
    width:260px;
    border-radius:10px;
    box-shadow:0 6px 16px rgba(0,0,0,.08);
    padding:8px;
    z-index:10;
    color:#111;
}
header .actions .notif .notif-box,
header .actions .notif .notif-box *{
    color:#111 !important;
    text-shadow:none !important;
}
header .actions .notif .notif-item{
    padding:8px;
    border-bottom:1px solid #f1f5f9;
    font-size:13px;
    color:#111 !important;
    background:#fff !important;
}
header .actions .notif .notif-item *{
    color:#111 !important;
}
header .actions .notif .notif-item:last-child{border-bottom:none;}
header .actions .notif .notif-item.new{background:#fff !important;}

/* Force widget notif text to black in header */
header .actions .notif-widget,
header .actions .notif-widget *{
    color:#111 !important;
}
header .actions .notif-widget .notif-list,
header .actions .notif-widget .notif-item{
    background:#fff !important;
}
header .actions .profile img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #fff;}
.hero{display:flex;gap:20px;align-items:flex-start;flex-wrap:wrap;}
.below{display:flex;gap:20px;align-items:flex-start;flex-wrap:wrap;margin-top:24px;}
.banner{flex:2;display:flex;gap:20px;background:linear-gradient(135deg,#8d4545,#6b2f2f);padding:25px;border-radius:15px;box-shadow:0 4px 15px rgba(0,0,0,0.05);flex-wrap:wrap;min-width:320px;}
.table-wrap{flex:1;min-width:320px;}
.banner-left{flex:2;display:flex;flex-direction:column;justify-content:center;gap:15px;}
.banner-left h1{font-size:32px;color:#35ff1e;}
.banner-left p{font-size:16px;color:#fff;}
.banner-right{flex:1;display:flex;flex-direction:column;gap:15px;}
.banner-right .card{background:#f7f9fc;padding:15px;border-radius:10px;text-align:left;box-shadow:0 2px 8px rgba(0,0,0,0.05);}
.banner-right .card h3{font-size:16px;color:#1e90ff;margin-bottom:10px;}
.banner-right .card p{font-size:14px;color:#555;margin-bottom:5px;}
.kategori-section{text-align:center;margin-top:40px;}
.kategori-section h1{font-size:36px;color:#1e90ff;font-weight:700;margin-bottom:10px;}
.kategori-section a{font-size:13px;color:#f30909;text-decoration:none;transition:0.3s;}
.kategori-section a:hover{color:#00c93a;text-decoration:underline;}
.kategori{display:flex;flex-direction:column;gap:20px;max-width:500px;margin:0 auto;}
.kategori .item{background:#fff;padding:22px;border-radius:15px;box-shadow:0 4px 12px rgba(0,0,0,0.06);cursor:pointer;transition:0.3s;}
.kategori .item:hover{transform:translateY(-3px);box-shadow:0 8px 20px rgba(0,0,0,0.12);}
.kategori .item h4{font-size:18px;color:#1e90ff;margin-bottom:6px;}
.kategori .item p{font-size:14px;color:#666;}
.table-wrap{background:#fff;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,.06);padding:16px;overflow:auto;flex:1;min-width:320px;}
.table-wrap h3{margin:0 0 12px;font-size:18px;color:#1e90ff;}
table{width:100%;border-collapse:collapse;min-width:860px;}
th,td{padding:10px;border-bottom:1px solid #eee;text-align:left;font-size:13px;}
th{background:#f8fafc;font-weight:700;}
td .small{font-size:12px;color:#666;}
.popup{position:fixed;top:20px;right:20px;background:#1e90ff;color:#fff;padding:15px 20px;border-radius:10px;box-shadow:0 5px 15px rgba(0,0,0,0.2);opacity:0;pointer-events:none;transition:0.5s;max-width:300px;word-wrap:break-word;}
.popup.show{opacity:1;pointer-events:auto;}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="profile">
        <img src="../uploads/<?= $penjual['foto']; ?>" class="avatar">
        <h3><?= $penjual['nama_penjual']; ?></h3>
        <span>@<?= $penjual['username']; ?></span>
    </div>
    <ul class="menu">
        <li><a href="dashboard_penjual.php">Dashboard</a></li>
        <li><a href="admin.php">Penjual</a></li>
        <li><a href="produk.php">Produk</a></li>
        <li><a href="approve.php">Approve</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="chat.php">Chat</a></li>
        <hr>
        <li><a href="help.php">Help</a></li>
        <li><a href="akun.php">My Account</a></li>
        <li class="logout"><a href="../auth/logout.php">Sign Out</a></li>
    </ul>
</div>

<main>
<header>
    <div class="logo">Toko Buku Sejahtera</div>
    <div class="search-box"><input type="text" placeholder="Search..."></div>
    <div class="actions">
        <?php renderNotifWidget('penjual', (int)$id_penjual); ?>
        <div class="user-info">
            <span><?= htmlspecialchars($penjual['nama_penjual']); ?></span>
            <div class="profile"><img src="../uploads/<?= $penjual['foto']; ?>" class="avatar"></div>
        </div>
    </div>
</header>

<div class="hero">
    <div class="banner">
        <div class="banner-left">
            <h1>Selamat Datang, <?= $penjual['nama_penjual']; ?>!</h1>
            <p>Kelola toko buku Anda, pantau penjualan, dan chat dengan pembeli realtime.</p>
        </div>
        <div class="banner-right">
            <div class="card">
                <h3>Pesan Pembeli Terbaru</h3>
                <div id="pesanCard">
                    <?php foreach($latestMessages as $msg): ?>
                        <p><strong>Pembeli #<?= $msg['pembeli_id']; ?>:</strong> <?= htmlspecialchars($msg['message']); ?></p>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="below">
    <div class="kategori-section">
        <div class="kategori">
            <h1>You're Book</h1>
            <a href="produk.php">See All</a>
            <?php while($row = mysqli_fetch_assoc($kategori_result)): ?>
                <div class="item">
                    <h4><?= htmlspecialchars($row['nama_kategori']); ?></h4>
                    <p><?= htmlspecialchars($row['status']); ?></p>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

    <div class="table-wrap">
        <h3>Pesanan Terbaru</h3>
        <table>
            <thead>
                <tr>
                    <th>Kode Pesanan</th>
                    <th>Produk</th>
                    <th>Pembeli</th>
                    <th>Status</th>
                    <th>Total</th>
                    <th>Tanggal</th>
                    <th>Rincian Pembeli</th>
                </tr>
            </thead>
            <tbody>
            <?php if($pesanan_list && mysqli_num_rows($pesanan_list) > 0): ?>
                <?php while($ps = mysqli_fetch_assoc($pesanan_list)): ?>
                    <tr>
                        <td><?= htmlspecialchars($ps['kode_pesanan']); ?></td>
                        <td><?= htmlspecialchars($ps['nama_produk']); ?></td>
                        <td><?= htmlspecialchars($ps['username']); ?></td>
                        <td><?= htmlspecialchars($ps['status']); ?></td>
                        <td>Rp <?= number_format($ps['total_harga']); ?></td>
                        <td><?= htmlspecialchars($ps['tanggal']); ?></td>
                        <td>
                            <div class="small"><?= htmlspecialchars($ps['alamat']); ?></div>
                            <div class="small"><?= htmlspecialchars($ps['no_hp']); ?></div>
                            <div class="small"><?= htmlspecialchars($ps['email']); ?></div>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="7">Belum ada pesanan.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</main>

<div class="popup" id="popupNotif"></div>

<script>
let lastMessages = <?= json_encode($latestMessages); ?>;

async function updateDashboard(){
    try{
        const res = await fetch('?ajax=1');
        const data = await res.json();

        const pesananEl = document.getElementById('pesananCount');
        if (pesananEl) pesananEl.textContent = data.pesanan + ' Pesanan';

        // Update card pesan
        const pesanCard = document.getElementById('pesanCard');
        pesanCard.innerHTML = '';
        data.latestMessages.forEach(msg=>{
            const p = document.createElement('p');
            p.innerHTML = `<strong>Pembeli #${msg.pembeli_id}:</strong> ${msg.message}`;
            pesanCard.appendChild(p);
        });

        // Popup jika ada pesan baru
        if(data.latestMessages.length > lastMessages.length){
            const newMessages = data.latestMessages.slice(0, data.latestMessages.length - lastMessages.length);
            newMessages.forEach(msg=>{
                showPopup(`Dari Pembeli #${msg.pembeli_id}: ${msg.message}`);
            });
        }
        lastMessages = data.latestMessages;

    }catch(err){
        console.error('Error:', err);
    }
}

function showPopup(message){
    const popup = document.getElementById('popupNotif');
    popup.textContent = message;
    popup.classList.add('show');
    setTimeout(()=> popup.classList.remove('show'),4000);
}

// Update realtime setiap 3 detik
updateDashboard();
setInterval(updateDashboard,3000);
</script>
</body>
</html>







