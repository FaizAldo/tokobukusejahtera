<?php
// help.php
// Halaman Help untuk Penjual -- menampilkan FAQ, panduan singkat, dan form kontak ke tim support.
// Sidebar mengikuti struktur yang Anda kirimkan (tetap).
// Pastikan koneksi mysqli di ../conn/koneksi.php

session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];
$halaman = basename($_SERVER['PHP_SELF']);

// ambil data penjual untuk sidebar/profile
$stmtp = $conn->prepare("SELECT * FROM penjual WHERE username = ? LIMIT 1");
$stmtp->bind_param("s", $username);
$stmtp->execute();
$penjual = $stmtp->get_result()->fetch_assoc();
$stmtp->close();

function esc($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

/* ================= Handle AJAX contact form (penjual -> messages) ================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_help'])) {
    header('Content-Type: application/json; charset=utf-8');

    $id_penjual = (int) ($penjual['id_penjual'] ?? 0);
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($id_penjual <= 0) {
        echo json_encode(['success' => false, 'message' => 'Akun tidak terdeteksi. Silakan login ulang.']);
        exit;
    }
    if ($message === '') {
        echo json_encode(['success' => false, 'message' => 'Pesan tidak boleh kosong.']);
        exit;
    }

    // Gabungkan subject ke message jika ada
    $full = $subject ? ("[Subject: " . $subject . "]\n\n" . $message) : $message;

    // Simpan ke tabel messages (sender = 'penjual')
    $stmt = $conn->prepare("INSERT INTO messages (penjual_id, sender, message, is_read) VALUES (?, 'penjual', ?, 0)");
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Kesalahan sistem (prepare).']);
        exit;
    }
    $stmt->bind_param("is", $id_penjual, $full);
    $ok = $stmt->execute();
    $err = $stmt->error;
    $stmt->close();

    if ($ok) {
        kirimNotifKeSuperadmin("Pesan bantuan dari penjual @{$penjual['username']}");
        echo json_encode(['success' => true, 'message' => 'Pesan terkirim. Tim support akan menindaklanjuti.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal mengirim: ' . $err]);
    }
    exit;
}

/* ================= Help topics (data statis) ================= */
/* Anda bisa menambah / ubah teks di sini. */
$topics = [
    [
        'id' => 'started',
        'q' => 'Cara memulai sebagai penjual?',
        'a' => 'Login dengan akun penjual Anda. Lengkapi profil (nama, email, foto, alamat) di My Account. Tambah produk melalui menu Produk dengan mengisi nama, harga, stok, kategori, dan foto.'
    ],
    [
        'id' => 'upload-produk',
        'q' => 'Bagaimana cara upload produk dan foto yang benar?',
        'a' => 'Di menu Produk klik Tambah. Untuk foto: gunakan file JPG/PNG/WebP, ukuran maksimum 5MB. Sistem menyimpan hanya path relatif (mis. buku/abcd.jpg). Pastikan folder uploads/buku memiliki permission dapat ditulis oleh webserver (cari chmod 755 untuk folder dan 644 untuk file).'
    ],
    [
        'id' => 'gambar-not-show',
        'q' => 'Gambar tidak tampil di daftar produk — bagaimana memperbaikinya?',
        'a' => 'Periksa di database tabel produk kolom foto berisi path relatif (contoh: buku/xxx.jpg). Di front-end pastikan <code>src</code> ditunjuk ke <code>../uploads/{$foto}</code>. Periksa juga permission folder uploads dan file, serta cek DevTools → Network untuk status 404.'
    ],
    [
        'id' => 'order-flow',
        'q' => 'Bagaimana alur pesanan & approval?',
        'a' => 'Pembeli melakukan checkout → pesanan masuk di menu Approve. Di Approve Anda bisa melihat bukti pembayaran, menandai approve/disetujui, dan menginput nomor resi saat barang dikirim. Setelah selesai, status pesanan berubah menjadi selesai.'
    ],
    [
        'id' => 'refund',
        'q' => 'Bagaimana proses refund?',
        'a' => 'Jika pembayaran dikembalikan, admin akan menandai pesanan sebagai refund. Pastikan komunikasi dengan pembeli (via Chat) dan tim support bila perlu data transfer bank untuk pengembalian.'
    ],
    [
        'id' => 'laporan',
        'q' => 'Bagaimana membuat laporan dan mengunduh CSV?',
        'a' => 'Buka menu Laporan, pilih bulan dan tahun lalu klik Download. CSV berisi kolom: kode pesanan, judul, qty, bukti (path), metode pembayaran, total modal, total penjualan, total keuntungan, tanggal.'
    ],
    [
        'id' => 'akun',
        'q' => 'Bagaimana mengubah password atau foto profil?',
        'a' => 'Buka My Account → Ganti Password atau Ganti Foto. Untuk keamanan, password lama harus diverifikasi saat mengganti password. Foto akan diproses dan disimpan di folder uploads/penjual.'
    ],
    [
        'id' => 'contact',
        'q' => 'Saya butuh bantuan lain — bagaimana menghubungi support?',
        'a' => 'Gunakan form Kontak di bawah untuk mengirim pesan ke tim support. Isi subject (opsional) dan pesan. Pesan akan tersimpan dan tim support akan merespon melalui sistem pesan di dashboard.'
    ],
];

/* ================= PAGE RENDER ================= */
?>
<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="utf-8">
<title>Help Penjual</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
/* Basic app styles (match existing look) */
*{box-sizing:border-box}
body{font-family:Inter,Arial,sans-serif;background:#f5f6fa;margin:0;color:#222}
.sidebar{
    width:300px;position:fixed;left:0;top:0;bottom:0;background:linear-gradient(180deg,#8d4545,#6b2f2f);
    color:#fff;padding:20px;overflow:auto;box-shadow:4px 0 12px rgba(0,0,0,0.06);border-right:1px solid rgba(255,255,255,0.03);
}
.sidebar .inner{display:flex;flex-direction:column;gap:12px}
.profile{text-align:center;margin-bottom:12px}
.profile .avatar{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.12)}
.profile h3{margin:6px 0 2px;font-size:14px}
.profile span{font-size:12px;color:#e6f5f3}
.menu{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:8px}
.menu a{display:block;padding:6px 8px;border-radius:6px;color:#fff;text-decoration:none;font-size:13px}
.menu a.active{background:rgba(255,255,255,0.08);font-weight:700}
.menu a:hover{background:rgba(255,255,255,0.04)}
.menu hr{border:none;height:1px;background:rgba(255,255,255,.06);margin:8px 0}

.main{margin-left:340px;padding:28px}

/* Help content */
.header{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px}
.header h2{margin:0;font-size:24px}
.search-wrap{display:flex;gap:8px;align-items:center}
.search-wrap input{padding:8px 12px;border-radius:10px;border:1px solid #ccc;width:320px}

/* topics */
.topics{display:flex;flex-direction:column;gap:12px;max-width:980px}
.topic{background:#fff;border-radius:10px;padding:12px;border:1px solid #e6e6e6}
.topic .q{font-weight:700;cursor:pointer;display:flex;justify-content:space-between;align-items:center}
.topic .a{margin-top:8px;display:none;color:#333;line-height:1.5}
.topic .tag{background:#f1f3f3;padding:4px 8px;border-radius:12px;font-size:12px;color:#666}

/* contact card */
.contact{margin-top:18px;background:#fff;padding:14px;border-radius:10px;border:1px solid #e6e6e6;max-width:700px}
.contact input[type=text], .contact textarea{width:100%;padding:8px;border-radius:8px;border:1px solid #ccc}
.contact textarea{min-height:120px;resize:vertical}
.contact .row{display:flex;gap:8px;margin-top:8px}
.contact .btn{background:#1e90ff;color:#fff;border:none;padding:10px 14px;border-radius:8px;cursor:pointer}
.contact .msg{margin-top:8px;font-size:13px}

/* small helper */
.helper{background:#fff;padding:10px;border-radius:8px;border:1px solid #eee;max-width:700px;margin-top:12px;color:#444}

/* responsive */
@media(max-width:900px){
    .main{margin-left:0;padding:12px}
    .search-wrap input{width:100%}
}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR (sama seperti yang Anda gunakan) -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="inner">
    <!-- PROFIL -->
    <div class="profile">
        <?php
        $avatar = $penjual['foto'] ? ('../uploads/' . preg_replace('#^(?:\.\./)?uploads/#', '', $penjual['foto'])) : '../uploads/default.png';
        ?>
        <img src="<?= esc($avatar) ?>" class="avatar" alt="avatar">
        <h3><?= esc($penjual['nama_penjual'] ?? '') ?></h3>
        <span>@<?= esc($penjual['username'] ?? '') ?></span>
    </div>

    <!-- MENU -->
    <ul class="menu">
        <li><a href="dashboard_penjual.php">Dashboard</a></li>
        <li><a href="admin.php">Penjual</a></li>
        <li><a href="produk.php">Produk</a></li>
        <li><a href="approve.php">Approve</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="help.php" class="active">Help</a></li>
        <li><a href="chat.php">Chat</a></li>

        <hr>

        <li><a href="akun.php">My Account</a></li>
        <li><a href="../auth/logout.php">Sign Out</a></li>
    </ul>
  </div>
</div>

<!-- MAIN CONTENT -->
<div class="main">
    <div class="header">
        <h2>Help Penjual</h2>
        <div class="search-wrap">
            <input type="text" id="search" placeholder="Cari topik bantuan (contoh: gambar, upload, resi)">
            <button id="clear" class="btn" style="background:#eee;color:#333;border:1px solid #ccc">Clear</button>
        </div>
        <div class="right" style="display:flex;align-items:center;gap:12px;margin-left:auto;">
            <div class="user" style="display:flex;align-items:center;gap:10px;">
                <span><?= esc($penjual['nama_penjual'] ?? '') ?></span>
                <img src="<?= esc($avatar) ?>" alt="Profil" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
            </div>
        </div>
    </div>

    <div class="helper">
        <strong>Butuh bantuan khusus?</strong> Gunakan formulir Kontak di bawah untuk mengirim pertanyaan langsung ke tim support. Jika topik Anda ada di FAQ, klik untuk melihat solusi cepat.
    </div>

    <div class="topics" id="topics">
        <?php foreach ($topics as $t): ?>
            <div class="topic" data-id="<?= esc($t['id']) ?>" data-key="<?= esc(strtolower($t['q'] . ' ' . $t['a'])) ?>">
                <div class="q">
                    <div><?= esc($t['q']) ?></div>
                    <div class="tag">Lihat</div>
                </div>
                <div class="a"><?= nl2br(esc($t['a'])) ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="contact">
        <h3>Kontak Support</h3>
        <form id="contactForm">
            <label for="subject">Subject (opsional)</label>
            <input type="text" name="subject" id="subject" placeholder="Ringkasan singkat (mis. 'Gagal upload gambar')">

            <label for="message" style="margin-top:8px">Pesan</label>
            <textarea name="message" id="message" placeholder="Jelaskan masalah Anda secara detail..."></textarea>

            <div class="row" style="margin-top:8px">
                <button type="submit" class="btn">Kirim</button>
                <div id="contactStatus" style="align-self:center;margin-left:8px;color:#333"></div>
            </div>
            <input type="hidden" name="send_help" value="1">
        </form>
        <div class="msg small" id="contactNote">Kami akan membalas melalui sistem pesan di dashboard Anda.</div>
    </div>
</div>

<script>
$(function(){
    // Toggle topic answers
    $(document).on('click', '.topic .q', function(){
        var a = $(this).closest('.topic').find('.a');
        $('.topic .a').not(a).slideUp(120);
        a.slideToggle(120);
    });

    // Search filter
    $("#search").on('input', function(){
        var q = $(this).val().trim().toLowerCase();
        if (!q) {
            $(".topic").show();
            return;
        }
        $(".topic").each(function(){
            var key = $(this).data('key') || '';
            if (key.indexOf(q) !== -1) $(this).show();
            else $(this).hide();
        });
    });
    $("#clear").on('click', function(){
        $("#search").val('').trigger('input');
    });

    // Contact form submit via AJAX
    $("#contactForm").on("submit", function(e){
        e.preventDefault();
        var form = $(this);
        var btn = form.find("button[type=submit]");
        var status = $("#contactStatus");
        status.text('');
        btn.prop('disabled', true).text('Mengirim...');

        $.ajax({
            url: 'help.php',
            method: 'POST',
            data: form.serialize(),
            dataType: 'json'
        }).done(function(res){
            if (res.success) {
                status.css('color','green').text(res.message);
                form[0].reset();
            } else {
                status.css('color','red').text(res.message || 'Gagal mengirim pesan.');
            }
        }).fail(function(){
            status.css('color','red').text('Permintaan gagal. Coba lagi.');
        }).always(function(){
            btn.prop('disabled', false).text('Kirim');
        });
    });
});
</script>

</body>
</html>








