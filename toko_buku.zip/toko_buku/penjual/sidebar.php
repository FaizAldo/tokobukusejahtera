<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include '../conn/koneksi.php';

$id_penjual = $_SESSION['user_id'];

$penjual = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM penjual WHERE id_penjual='$id_penjual'")
);

$halaman = basename($_SERVER['PHP_SELF']);
?>

<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
.sidebar {
    width: 260px;
    height: 100vh;
    background: linear-gradient(180deg, #8d4545, #6b2f2f);
    position: fixed;
    left: 0;
    top: 0;
    color: #fff;
    padding: 20px;
    overflow-y: auto;
}

.profile {
    text-align: center;
    margin-bottom: 25px;
}

.avatar {
    width: 75px;
    height: 75px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #fff;
}

.profile h3 {
    margin: 8px 0 0;
    font-size: 17px;
}

.profile span {
    font-size: 13px;
    opacity: .85;
}

.menu {
    list-style: none;
    padding: 0;
}

.menu li {
    margin: 6px 0;
}

.menu li a {
    display: block;
    padding: 11px 14px;
    border-radius: 8px;
    color: #fff;
    text-decoration: none;
    transition: 0.25s;
}

.menu li a:hover {
    background: rgba(255,255,255,0.2);
}

.menu li.active a {
    background: rgba(255,255,255,0.3);
    font-weight: bold;
}

.menu hr {
    border: none;
    border-top: 1px solid rgba(255,255,255,0.3);
    margin: 12px 0;
}

.logout a {
    background: #ef4444;
}

/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>

    <!-- PROFIL -->
    <div class="profile">
        <img src="../uploads/<?= $penjual['foto']; ?>" class="avatar">
        <h3><?= $penjual['nama_penjual']; ?></h3>
        <span>@<?= $penjual['username']; ?></span>
    </div>

    <!-- MENU -->
    <ul class="menu">

        <li class="<?= $halaman=='dashboard.php'?'active':'' ?>">
            <a href="dashboard_penjual.php">Dashboard</a>
        </li>

        <li class="<?= $halaman=='admin.php'?'active':'' ?>">
            <a href="admin.php">Penjual</a>
        </li>

        <li class="<?= $halaman=='produk.php'?'active':'' ?>">
            <a href="produk.php">Produk</a>
        </li>

        <li class="<?= $halaman=='approve.php'?'active':'' ?>">
            <a href="approve.php">Approve</a>
        </li>

        <li class="<?= $halaman=='laporan.php'?'active':'' ?>">
            <a href="laporan.php">Laporan</a>
        </li>

        <li class="<?= $halaman=='chat.php'?'active':'' ?>">
            <a href="chat.php">Chat</a>
        </li>

        <hr>

        <li class="<?= $halaman=='help.php'?'active':'' ?>">
            <a href="help.php">Help</a>
        </li>

        <li class="<?= $halaman=='akun.php'?'active':'' ?>">
            <a href="akun.php">My Account</a>
        </li>

        <li class="logout">
            <a href="../auth/logout.php">Sign Out</a>
        </li>

    </ul>
</div>




