<!DOCTYPE html>
<html lang="id">
<head>
<script src="../assets/responsive.js" defer></script>
<link rel="stylesheet" href="../assets/responsive.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help | Toko Buku Sejahtera</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: #f2f0ed;
            display: flex;
            color: #333;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width: 260px;
            background: #813838;
            color: #fff;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
        }

        .sidebar h1 {
            text-align: center;
            margin-bottom: 40px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 14px 16px;
            border-radius: 10px;
            margin-bottom: 10px;
            font-weight: 500;
            display: block;
        }

        .sidebar a:hover {
            background: rgba(255,255,255,0.2);
        }

        /* ===== CONTENT ===== */
        .content {
            margin-left: 260px;
            padding: 60px 40px;
            width: calc(100% - 260px);
        }

        .content h2 {
            margin-bottom: 30px;
            color: #1e3a8a;
        }

        .help-card {
            background: #fff;
            padding: 30px;
            border-radius: 18px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }

        .help-card h3 {
            color: #ef9001;
            margin-bottom: 10px;
        }

        .help-card p {
            line-height: 1.7;
        }

        footer {
            text-align: center;
            margin-top: 40px;
            color: #777;
            font-size: 14px;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .content {
                margin-left: 200px;
                width: calc(100% - 200px);
            }
        }
    </style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h1>Toko Buku Sejahtera</h1>
  
    <a href="../auth/registrasi_akun.php">📝 Daftar Akun</a>
    <a href="../auth/login_users.php">🔐 Login</a>

    <div style="margin-top:auto;">
        <a href="help.php">❓ Help</a>
    </div>
</div>

<!-- CONTENT -->
<main class="content">

    <h2>Pusat Bantuan</h2>

    <div class="help-card">
        <h3>📌 Cara Daftar Akun</h3>
        <p>
            Klik menu <b>Daftar Akun</b> pada sidebar, isi data dengan benar,
            lalu simpan. Setelah berhasil, silakan login menggunakan akun tersebut.
        </p>
    </div>

    <div class="help-card">
        <h3>🔐 Cara Login</h3>
        <p>
            Pilih menu <b>Login</b>, masukkan username dan password yang sudah terdaftar,
            kemudian tekan tombol login.
        </p>
    </div>

    <div class="help-card">
        <h3>📚 Tentang Toko Buku Sejahtera</h3>
        <p>
            Toko Buku Sejahtera menyediakan berbagai buku pelajaran, novel,
            dan bacaan umum dengan harga terjangkau.
        </p>
    </div>

    <div class="help-card">
        <h3>☎️ Kontak Kami</h3>
        <p>
            Alamat: Jl. Kp. Pulo Jahe, Gang Taruna No. 39B, Jakarta Timur<br>
            Email: tokobukusejahtera@gmail.com<br>
            Telepon: 08xx-xxxx-xxxx
        </p>
    </div>

    <footer>
        &copy; 2026 Toko Buku Sejahtera
    </footer>

</main>

</body>
</html>


