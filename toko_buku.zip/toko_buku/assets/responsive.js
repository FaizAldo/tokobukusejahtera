document.addEventListener('DOMContentLoaded', function() {
    var sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'hamburger-btn';
    btn.setAttribute('aria-label', 'Toggle Menu');
    btn.innerHTML = '&#9776;';

    var backdrop = document.createElement('div');
    backdrop.className = 'sidebar-backdrop';

    function openMenu() {
        document.body.classList.add('sidebar-open');
    }

    function closeMenu() {
        document.body.classList.remove('sidebar-open');
    }

    function toggleMenu() {
        document.body.classList.toggle('sidebar-open');
    }

    btn.addEventListener('click', function(e) {
        e.preventDefault();
        toggleMenu();
    });
    backdrop.addEventListener('click', function() {
        closeMenu();
    });

    // Close on link click
    sidebar.addEventListener('click', function(e) {
        var t = e.target;
        if (t && t.tagName === 'A') closeMenu();
    });

    document.body.appendChild(btn);
    document.body.appendChild(backdrop);

    function getAccountLink() {
        var path = (window.location.pathname || '').toLowerCase();
        if (path.indexOf('/admin/') !== -1) return 'akun_admin.php';
        if (path.indexOf('/penjual/') !== -1) return 'akun.php';
        if (path.indexOf('/pembeli/') !== -1) return 'akun.php';
        return null;
    }

    function getProfileInfoUrl() {
        var path = (window.location.pathname || '').toLowerCase();
        if (path.indexOf('/admin/') !== -1 || path.indexOf('/penjual/') !== -1 || path.indexOf('/pembeli/') !== -1) {
            return '../notifikasi/profile_info.php';
        }
        return 'notifikasi/profile_info.php';
    }

    function ensureProfileModal() {
        var existing = document.querySelector('.profile-modal-backdrop');
        if (existing) return existing;

        var backdropEl = document.createElement('div');
        backdropEl.className = 'profile-modal-backdrop';
        backdropEl.innerHTML = [
            '<div class="profile-modal" role="dialog" aria-modal="true">',
            '  <button type="button" class="profile-modal-close" aria-label="Close">&times;</button>',
            '  <div class="profile-modal-body">',
            '    <img class="profile-modal-avatar" alt="Profil" />',
            '    <div class="profile-modal-info">',
            '      <h3 class="profile-modal-name">Profil</h3>',
            '      <p class="profile-modal-role"></p>',
            '    </div>',
            '  </div>',
            '  <div class="profile-modal-details">',
            '    <div class="profile-row profile-row-name"><span class="label">Nama</span><span class="value profile-fullname">-</span></div>',
            '    <div class="profile-row profile-row-role"><span class="label">Role</span><span class="value profile-roletext">-</span></div>',
            '    <div class="profile-row profile-row-username"><span class="label">Username</span><span class="value profile-username">-</span></div>',
            '    <div class="profile-row profile-row-email"><span class="label">Email</span><span class="value profile-email">-</span></div>',
            '    <div class="profile-row profile-row-phone"><span class="label">No HP</span><span class="value profile-phone">-</span></div>',
            '    <div class="profile-row profile-row-address"><span class="label">Alamat</span><span class="value profile-address">-</span></div>',
            '    <div class="profile-row profile-row-nik"><span class="label">NIK</span><span class="value profile-nik">-</span></div>',
            '  </div>',
            '  <div class="profile-modal-actions">',
            '    <a class="profile-modal-edit" href="#">Edit Profil</a>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(backdropEl);

        var closeBtn = backdropEl.querySelector('.profile-modal-close');
        closeBtn.addEventListener('click', function() {
            backdropEl.classList.remove('show');
        });
        backdropEl.addEventListener('click', function(e) {
            if (e.target === backdropEl) backdropEl.classList.remove('show');
        });
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') backdropEl.classList.remove('show');
        });

        return backdropEl;
    }

    function openProfileModal(info) {
        var backdropEl = ensureProfileModal();
        var avatar = backdropEl.querySelector('.profile-modal-avatar');
        var nameEl = backdropEl.querySelector('.profile-modal-name');
        var roleEl = backdropEl.querySelector('.profile-modal-role');
        var editBtn = backdropEl.querySelector('.profile-modal-edit');
        var fullnameEl = backdropEl.querySelector('.profile-fullname');
        var roleTextEl = backdropEl.querySelector('.profile-roletext');
        var usernameEl = backdropEl.querySelector('.profile-username');
        var emailEl = backdropEl.querySelector('.profile-email');
        var phoneEl = backdropEl.querySelector('.profile-phone');
        var addressEl = backdropEl.querySelector('.profile-address');
        var nikEl = backdropEl.querySelector('.profile-nik');
        var nikRow = backdropEl.querySelector('.profile-row-nik');
        var rowName = backdropEl.querySelector('.profile-row-name');
        var rowRole = backdropEl.querySelector('.profile-row-role');
        var rowUsername = backdropEl.querySelector('.profile-row-username');
        var rowEmail = backdropEl.querySelector('.profile-row-email');
        var rowPhone = backdropEl.querySelector('.profile-row-phone');
        var rowAddress = backdropEl.querySelector('.profile-row-address');

        if (info.photo) avatar.src = info.photo;
        if (info.name) nameEl.textContent = info.name;
        roleEl.textContent = info.role || '';
        var accountLink = getAccountLink();
        if (accountLink) editBtn.href = accountLink;
        var vName = info.fullname || info.name || '';
        var vRole = info.role || '';
        var vUsername = info.username || '';
        var vEmail = info.email || '';
        var vPhone = info.phone || '';
        var vAddress = info.address || '';
        fullnameEl.textContent = vName || '-';
        roleTextEl.textContent = vRole || '-';
        usernameEl.textContent = vUsername || '-';
        emailEl.textContent = vEmail || '-';
        phoneEl.textContent = vPhone || '-';
        addressEl.textContent = vAddress || '-';

        toggleRow(rowName, vName);
        toggleRow(rowRole, vRole);
        toggleRow(rowUsername, vUsername);
        toggleRow(rowEmail, vEmail);
        toggleRow(rowPhone, vPhone);
        toggleRow(rowAddress, vAddress);
        if (nikRow && (info.role || '') !== 'pembeli') {
            nikRow.style.display = 'none';
        } else if (nikRow) {
            nikRow.style.display = '';
        }
        if (nikEl && (info.role || '') === 'pembeli') {
            nikEl.textContent = maskNik(info.nik || '');
        } else if (nikEl) {
            nikEl.textContent = '-';
        }

        backdropEl.classList.add('show');
    }

    function toggleRow(rowEl, value) {
        if (!rowEl) return;
        if (!value) rowEl.style.display = 'none';
        else rowEl.style.display = '';
    }

    function maskNik(nik) {
        var s = (nik || '').toString().replace(/\s+/g, '');
        if (!s) return '-';
        if (s.length <= 6) return s;
        var head = s.slice(0, 4);
        var tail = s.slice(-3);
        return head + '****' + tail;
    }

    var cachedProfileInfo = null;

    function updateProfileModal(info) {
        var backdropEl = ensureProfileModal();
        var avatar = backdropEl.querySelector('.profile-modal-avatar');
        var nameEl = backdropEl.querySelector('.profile-modal-name');
        var roleEl = backdropEl.querySelector('.profile-modal-role');
        var editBtn = backdropEl.querySelector('.profile-modal-edit');
        var fullnameEl = backdropEl.querySelector('.profile-fullname');
        var roleTextEl = backdropEl.querySelector('.profile-roletext');
        var usernameEl = backdropEl.querySelector('.profile-username');
        var emailEl = backdropEl.querySelector('.profile-email');
        var phoneEl = backdropEl.querySelector('.profile-phone');
        var addressEl = backdropEl.querySelector('.profile-address');
        var nikEl = backdropEl.querySelector('.profile-nik');
        var nikRow = backdropEl.querySelector('.profile-row-nik');
        var rowName = backdropEl.querySelector('.profile-row-name');
        var rowRole = backdropEl.querySelector('.profile-row-role');
        var rowUsername = backdropEl.querySelector('.profile-row-username');
        var rowEmail = backdropEl.querySelector('.profile-row-email');
        var rowPhone = backdropEl.querySelector('.profile-row-phone');
        var rowAddress = backdropEl.querySelector('.profile-row-address');

        if (info.photo) avatar.src = info.photo;
        if (info.name) nameEl.textContent = info.name;
        roleEl.textContent = info.role || '';
        var accountLink = getAccountLink();
        if (accountLink) editBtn.href = accountLink;

        var vName = info.fullname || info.name || '';
        var vRole = info.role || '';
        var vUsername = info.username || '';
        var vEmail = info.email || '';
        var vPhone = info.phone || '';
        var vAddress = info.address || '';
        fullnameEl.textContent = vName || '-';
        roleTextEl.textContent = vRole || '-';
        usernameEl.textContent = vUsername || '-';
        emailEl.textContent = vEmail || '-';
        phoneEl.textContent = vPhone || '-';
        addressEl.textContent = vAddress || '-';

        toggleRow(rowName, vName);
        toggleRow(rowRole, vRole);
        toggleRow(rowUsername, vUsername);
        toggleRow(rowEmail, vEmail);
        toggleRow(rowPhone, vPhone);
        toggleRow(rowAddress, vAddress);

        if (nikRow && (info.role || '') !== 'pembeli') {
            nikRow.style.display = 'none';
        } else if (nikRow) {
            nikRow.style.display = '';
        }
        if (nikEl && (info.role || '') === 'pembeli') {
            nikEl.textContent = maskNik(info.nik || '');
        } else if (nikEl) {
            nikEl.textContent = '-';
        }
    }

    document.addEventListener('click', function(e) {
        var target = e.target;
        if (!target || (target.tagName && target.tagName.toLowerCase() === 'a')) return;
        if (target.closest && target.closest('a')) return;
        var clickable = target.closest && target.closest('.user, .user-info, .profile-section, .profile');
        if (!clickable) return;
        var root = clickable;
        var imgEl = root.querySelector && root.querySelector('img');
        if (!imgEl && root.closest) {
            var host = root.closest('.user, .user-info, .profile-section, .profile');
            if (host && host.querySelector) imgEl = host.querySelector('img');
        }
        if (!imgEl) imgEl = document.querySelector('.user img, .profile img, .profile-section img');

        var nameEl = root.querySelector && root.querySelector('strong, h3, span');
        if (!nameEl && root.closest) {
            var host2 = root.closest('.user, .user-info, .profile-section, .profile');
            if (host2 && host2.querySelector) nameEl = host2.querySelector('strong, h3, span');
        }
        var roleEl = root.querySelector && root.querySelector('small');
        if (!roleEl && root.closest) {
            var host3 = root.closest('.profile-section');
            if (host3 && host3.querySelector) roleEl = host3.querySelector('small');
        }

        var uNode = document.querySelector('[data-profile-username]');
        var eNode = document.querySelector('[data-profile-email]');
        var pNode = document.querySelector('[data-profile-phone]');
        var aNode = document.querySelector('[data-profile-address]');
        var rNode = document.querySelector('[data-profile-role]');
        var nNode = document.querySelector('[data-profile-name]');
        var kNode = document.querySelector('[data-profile-nik]');
        var usernameVal = uNode && uNode.dataset ? uNode.dataset.profileUsername : '';
        var emailVal = eNode && eNode.dataset ? eNode.dataset.profileEmail : '';
        var phoneVal = pNode && pNode.dataset ? pNode.dataset.profilePhone : '';
        var addressVal = aNode && aNode.dataset ? aNode.dataset.profileAddress : '';
        var roleVal = rNode && rNode.dataset ? rNode.dataset.profileRole : '';
        var nameVal = nNode && nNode.dataset ? nNode.dataset.profileName : '';
        var nikVal = kNode && kNode.dataset ? kNode.dataset.profileNik : '';

        var initialInfo = {
            photo: imgEl ? imgEl.getAttribute('src') : '',
            name: nameEl ? nameEl.textContent.trim() : 'Profil',
            role: roleVal || (roleEl ? roleEl.textContent.trim() : ''),
            fullname: nameVal,
            username: usernameVal,
            email: emailVal,
            phone: phoneVal,
            address: addressVal,
            nik: nikVal
        };

        openProfileModal(initialInfo);

        if (cachedProfileInfo) {
            updateProfileModal(cachedProfileInfo);
            return;
        }

        var infoUrl = getProfileInfoUrl();
        fetch(infoUrl, { credentials: 'same-origin' })
            .then(function(res) { return res.json(); })
            .then(function(res) {
                if (!res || !res.success) return;
                cachedProfileInfo = res;
                updateProfileModal(res);
            })
            .catch(function() {});
    });
});