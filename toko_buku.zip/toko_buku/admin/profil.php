<?php
// Wrapper to keep a consistent filename for all roles
require __DIR__ . '/profil_admin.php';
