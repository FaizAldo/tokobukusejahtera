<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

// ================= CEK LOGIN & ROLE =================
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login_users.php');
    exit;
}

// ================= AMBIL DATA ADMIN =================
$username = $_SESSION['username'];
$query = "SELECT * FROM admin WHERE username='$username' LIMIT 1";
$result = mysqli_query($conn, $query);
$admin = mysqli_fetch_assoc($result);

$admin_id = $admin['id_admin'] ?? 0;

// Jika admin tidak ditemukan, logout
if (!$admin) {
    session_destroy();
    header('Location: ../auth/login_users.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<script src="../assets/responsive.js" defer></script>
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Admin - Toko Buku Sejahtera</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* admin-theme */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.sidebar-header{background:#6b2f2f !important;}
.sidebar a{color:#fff !important;}
.sidebar a:hover,.sidebar a.active{background:rgba(255,255,255,0.2) !important;border-left:4px solid #f5d08a !important;}
.bottom-links a{color:#fff !important;}
.main,.main-content{background:#f5f6fa !important;}

/* admin-notif-force */
.notif-widget, .notif-widget *{color:#111 !important;}
.notif-widget .notif-list, .notif-widget .notif-item{background:#fff !important;}

body { display: flex; margin:0; font-family: Arial, sans-serif; }

/* Notif dropdown force black text on white */
.sidebar .notif-widget,
.sidebar .notif-widget *{
    color:#111 !important;
}
.sidebar .notif-widget .notif-list,
.sidebar .notif-widget .notif-item{
    background:#fff !important;
}

/* SIDEBAR */
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    height: 100vh;
    background: #8B4513; /* cokelat */
    color: white;
    padding: 20px 0;
    z-index: 3000;
    pointer-events: auto;
}
.sidebar .logo { display:flex; align-items:center; gap:10px; margin-bottom: 30px; padding:0 20px; }
.sidebar .logo img{width:50px;height:50px;border-radius:50%;object-fit:cover;}
.sidebar .logo h2 { font-size: 18px; line-height: 1.2; margin:0; }
.sidebar a { color: white; text-decoration: none; padding: 15px 20px; display: block; transition: 0.3s; position:relative; z-index:1; }
.sidebar a:hover, .sidebar a.active { background: #A0522D; border-left: 4px solid #FFD700; }

/* MAIN CONTENT */
.main-content {
    margin-left: 250px; /* supaya tidak tertimpa sidebar */
    flex: 1;
    background:#f5f6fa;
    min-height:100vh;
    position:relative;
    z-index:1;
}

/* TOPBAR */
.topbar { 
    background: white; 
    padding: 15px 30px; 
    box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
}
.topbar .notif{position:relative;cursor:pointer;font-size:20px;color:#111;}
.topbar .notif .badge{position:absolute;top:-8px;right:-8px;background:#ff4757;color:#fff;border-radius:50%;font-size:12px;padding:2px 6px;font-weight:600;}
.topbar .notif .notif-box{
    display:none;
    position:absolute;
    right:0;top:28px;
    background:#fff !important;
    border:1px solid #eee;
    width:260px;
    border-radius:10px;
    box-shadow:0 6px 16px rgba(0,0,0,.08);
    padding:8px;
    z-index:10;
    color:#111 !important;
}
.topbar .notif .notif-box,
.topbar .notif .notif-box *{
    color:#111 !important;
    text-shadow:none !important;
}
.topbar .notif .notif-item{
    padding:8px;
    border-bottom:1px solid #f1f5f9;
    font-size:13px;
    color:#111 !important;
    background:#fff !important;
}
.topbar .notif .notif-item:last-child{border-bottom:none;}
.topbar .notif .notif-item.new{background:#fff !important;}
.profile-section { display: flex; align-items: center; gap: 15px; margin-left:auto; }
.topbar .right{display:flex;align-items:center;gap:12px;}
.profile-img { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; }

/* BANNER */
.banner { 
    background: linear-gradient(135deg, #8d4545 0%, #6b2f2f 100%); 
    color: white; 
    padding: 100px 20px; 
    text-align: center; 
    margin-bottom: 30px;
}
.banner h1 { font-size: 48px; margin-bottom: 20px; font-weight: bold; }
.banner p { font-size: 18px; margin-bottom: 30px; }
.btn-banner { background: white; color: #8B4513; margin: 10px; padding: 12px 30px; border: none; border-radius: 25px; cursor: pointer; font-weight: bold; }

/* ADMIN BOX */
.admin-box { 
    background: white; 
    margin: -50px 30px 30px; 
    padding: 30px; 
    border-radius: 10px; 
    box-shadow: 0 4px 6px rgba(0,0,0,0.1); 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
    gap: 20px; 
}
.admin-info { display: flex; gap: 20px; align-items: center; }
.admin-photo { width: 100px; height: 100px; border-radius: 10px; object-fit: cover; }

/* ADMIN DETAIL */
.admin-detail{
    background:#fff;
    margin: -20px 30px 30px;
    padding: 20px 24px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.08);
}
.admin-detail h5{margin:0 0 12px;font-weight:700;}
.admin-detail-grid{
    display:grid;
    grid-template-columns: repeat(2, minmax(0,1fr));
    gap: 12px 24px;
}
.admin-detail-item{display:flex;gap:8px;}
.admin-detail-label{min-width:110px;color:#6b7280;}
.admin-detail-value{font-weight:600;color:#111;}

/* CONTENT AREA */
.content-area { padding: 30px; }
.row { display: flex; flex-wrap: wrap; gap: 20px; }
.card { border-radius:10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); padding: 20px; background:white; text-align:center; flex: 1 1 calc(25% - 20px); min-width: 220px; margin-bottom: 20px; }
.card i { margin-bottom:10px; }
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="logo">
        <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
        <h2>TOKO BUKU SEJAHTERA</h2>
    </div>
    <?php renderNotifWidget('admin', (int)$admin_id); ?>
    <a href="dashboard_admin.php" class="active">Dashboard</a>
    <a href="admin_penjual.php">Admin</a>
    <a href="pembeli.php">Pembeli</a>
    <a href="kategori.php">Kategori</a>
    <a href="akun_admin.php">My Account</a>
    <a href="../auth/logout.php">Sign Out</a>
    <a href="help_admin.php">Help</a>
</div>
<div data-profile-username="<?php echo htmlspecialchars($admin['username']); ?>" data-profile-email="<?php echo htmlspecialchars($admin['email']); ?>" data-profile-phone="" data-profile-address=""></div>

<!-- MAIN CONTENT -->
<div class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">
        <h3>Dashboard Admin</h3>
        <div class="right">
            <?php renderNotifWidget('admin', (int)$admin_id); ?>
            <div class="profile-section">
                <img src="<?php echo !empty($admin['foto']) ? '../uploads/'.$admin['foto'] : 'https://via.placeholder.com/50'; ?>" alt="Profile" class="profile-img">
                <div>
                    <strong><?php echo htmlspecialchars($admin['nama'] ?? $admin['username']); ?></strong><br>
                    <small><?php echo ucfirst($admin['role']); ?></small>
                </div>
            </div>
        </div>
    </div>

    <!-- BANNER -->
    <div class="banner">
        <h1>Toko Buku Sejahtera</h1>
        <p>Selamat datang di dashboard admin. Kelola toko buku Anda dengan mudah dan efisien.</p>
        <button class="btn-banner">Get Started</button>
        <button class="btn-banner">Learn More</button>
    </div>

    <!-- ADMIN DETAIL -->
    <div class="admin-detail">
        <h5>Informasi Admin</h5>
        <div class="admin-detail-grid">
            <div class="admin-detail-item">
                <div class="admin-detail-label">Nama</div>
                <div class="admin-detail-value"><?php echo htmlspecialchars($admin['nama'] ?? $admin['username']); ?></div>
            </div>
            <div class="admin-detail-item">
                <div class="admin-detail-label">Username</div>
                <div class="admin-detail-value"><?php echo htmlspecialchars($admin['username']); ?></div>
            </div>
            <div class="admin-detail-item">
                <div class="admin-detail-label">Email</div>
                <div class="admin-detail-value"><?php echo htmlspecialchars($admin['email']); ?></div>
            </div>
            <div class="admin-detail-item">
                <div class="admin-detail-label">Role</div>
                <div class="admin-detail-value"><?php echo ucfirst($admin['role']); ?></div>
            </div>
        </div>
    </div>

    <!-- ADMIN BOX -->
    <div class="admin-box">
        <div class="admin-info">
            <img src="<?php echo !empty($admin['foto']) ? '../uploads/'.$admin['foto'] : 'https://via.placeholder.com/100'; ?>" alt="Admin" class="admin-photo">
            <div>
                <h5><?php echo htmlspecialchars($admin['nama'] ?? $admin['username']); ?></h5>
                <p><strong>Username:</strong> <?php echo htmlspecialchars($admin['username']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($admin['email']); ?></p>
                <p><strong>Role:</strong> <span class="badge bg-primary"><?php echo ucfirst($admin['role']); ?></span></p>
            </div>
        </div>
        <a class="btn btn-primary" href="akun_admin.php">
            <i class="fas fa-edit"></i> Edit Profil
        </a>
    </div>

    <!-- CONTENT AREA -->
    <div class="content-area">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <i class="fas fa-users fa-3x text-primary"></i>
                    <h5 class="card-title">Akun Penjual</h5>
                    <p class="card-text">Kelola data penjual</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <i class="fas fa-user-tie fa-3x text-success"></i>
                    <h5 class="card-title">Akun Pembeli</h5>
                    <p class="card-text">Kelola data pembeli</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <i class="fas fa-list fa-3x text-warning"></i>
                    <h5 class="card-title">Kategori</h5>
                    <p class="card-text">Kelola kategori buku</p>
                </div>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Force navigation if any overlay interferes with default link behavior
document.querySelectorAll('.sidebar a').forEach(function(a){
    a.addEventListener('click', function(e){
        e.preventDefault();
        window.location.href = a.getAttribute('href');
    });
});
</script>
</body>
</html>








