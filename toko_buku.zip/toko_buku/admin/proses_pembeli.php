<?php
session_start();
require '../conn/koneksi.php';
header('Content-Type: application/json');

$role = $_SESSION['role'] ?? ($_SESSION['user_role'] ?? '');
if (!isset($_SESSION['username']) || $role !== 'admin') {
    http_response_code(401);
    echo json_encode(['success'=>false,'message'=>'Unauthorized']);
    exit;
}

$response = ['success'=>false,'message'=>''];
/* ================= DETAIL PEMBELI ================= */
if(isset($_GET['detail'])){
    $id = intval($_GET['detail']);

    $stmt = $conn->prepare("SELECT * FROM pembeli WHERE id_pembeli=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $data = $stmt->get_result()->fetch_assoc();

    echo json_encode($data);
    exit;
}

/* ================= LOAD DATA UNTUK CARDS ================= */
if(isset($_GET['ajax']) && $_GET['ajax']=='pembeli'){
    $result = mysqli_query($conn,"SELECT * FROM pembeli ORDER BY id_pembeli DESC");
    $data=[];
    while($row=mysqli_fetch_assoc($result)){
        $data[]=[
            'id_pembeli'=>$row['id_pembeli'],
            'nik'=>$row['nik'],
            'username'=>$row['username'],
            'email'=>$row['email'],
            'no_hp'=>$row['no_hp'],
            'alamat'=>$row['alamat'],
            'foto'=>$row['foto'],
            'status'=>$row['status'],
        ];
    }
    echo json_encode($data);
    exit;
}

/* ================= TAMBAH / EDIT ================= */
if($_SERVER['REQUEST_METHOD']=='POST'){
    $id = $_POST['id'] ?? '';
    $nik = $_POST['nik'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'] ?? '';
    $no_hp = $_POST['no_hp'] ?? '';
    $alamat = $_POST['alamat'] ?? '';
    $oldfoto = $_POST['oldfoto'] ?? '';
    
    // Upload foto jika ada
    $foto = $oldfoto;
    if(isset($_FILES['foto']) && $_FILES['foto']['tmp_name']){
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $foto = uniqid().'.'.$ext;
        move_uploaded_file($_FILES['foto']['tmp_name'], '../uploads/'.$foto);
    }

    if($id){ // EDIT
        $sql = "UPDATE pembeli SET nik=?, username=?, email=?, no_hp=?, alamat=?, foto=?";
        $params = [$nik,$username,$email,$no_hp,$alamat,$foto];
        if($password){ 
            $sql.=", password=?";
            $params[] = password_hash($password,PASSWORD_DEFAULT);
        }
        $sql.=" WHERE id_pembeli=?";
        $params[]=$id;

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(str_repeat('s',count($params)-1).'i', ...$params);
        $stmt->execute();
        $response['success']=true;
        $response['message']='Pembeli berhasil diupdate';
    }else{ // TAMBAH
        $stmt = $conn->prepare("INSERT INTO pembeli (nik,username,email,password,no_hp,alamat,foto,status) VALUES (?,?,?,?,?,?,?,?)");
        $hashed = password_hash($password,PASSWORD_DEFAULT);
        $status = 'offline';
        $stmt->bind_param("ssssssss",$nik,$username,$email,$hashed,$no_hp,$alamat,$foto,$status);
        $stmt->execute();
        $response['success']=true;
        $response['message']='Pembeli berhasil ditambahkan';
    }
    echo json_encode($response);
    exit;
}

/* ================= HAPUS ================= */
if(isset($_GET['hapus'])){
    $id = $_GET['hapus'];
    $stmt = $conn->prepare("DELETE FROM pembeli WHERE id_pembeli=?");
    $stmt->bind_param("i",$id);
    $stmt->execute();
    $response['success']=true;
    $response['message']='Pembeli berhasil dihapus';
    echo json_encode($response);
    exit;
}

echo json_encode($response);
