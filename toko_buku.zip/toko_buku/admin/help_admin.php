<?php
session_start();
require '../conn/koneksi.php';

// ====== CEK ROLE SUPERADMIN ======
if(!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../auth/login_users.php");
    exit;
}

// Ambil data superadmin dari tabel admin berdasarkan username session
$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT id_admin, username, foto, role FROM admin WHERE username=? LIMIT 1");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

// Jika superadmin tidak ditemukan, logout
if (!$admin) {
    session_destroy();
    header("Location: ../auth/login_users.php");
    exit;
}

// Set variabel untuk digunakan di sidebar / dashboard
$superadmin_name = $admin['username'];
$superadmin_role = $admin['role']; // 'superadmin'
$superadmin_photo = !empty($admin['foto']) ? $admin['foto'] : 'default.png';
$admin_id = $admin['id_admin'] ?? 0;

?>

<!DOCTYPE html>
<html lang="id">
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<title>Help - Superadmin</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* admin-theme */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.sidebar-header{background:#6b2f2f !important;}
.sidebar a{color:#fff !important;}
.sidebar a:hover,.sidebar a.active{background:rgba(255,255,255,0.2) !important;border-left:4px solid #f5d08a !important;}
.bottom-links a{color:#fff !important;}
.main,.main-content{background:#f5f6fa !important;}

*{margin:0;padding:0;box-sizing:border-box;font-family:Segoe UI,sans-serif;}
body{display:flex;background:#f2f2f2;}

/* SIDEBAR */
.sidebar{
    width:250px;height:100vh;background:#c17159;color:#fff;
    display:flex;flex-direction:column;
}
.sidebar-header{
    display:flex;align-items:center;gap:10px;padding:20px;background:brown;
}
.sidebar-header .logo{
    width:50px;height:50px;border-radius:50%;overflow:hidden;
}
.sidebar-header .logo img{width:100%;height:100%;object-fit:cover;}
.sidebar-header h1{font-size:16px;line-height:1.2;white-space:normal;}
.sidebar a{
    color:#fff;text-decoration:none;padding:10px 15px;margin:5px 10px;border-radius:5px;display:block;
}
.sidebar a:hover,.sidebar a.active{background:#00acc1;}
.bottom-links{margin-top:auto;padding-bottom:15px;}

/* TOPBAR */
.topbar{
    flex:1;padding:15px;background:#fff;display:flex;justify-content:space-between;align-items:center;
    box-shadow:0 2px 5px rgba(0,0,0,.1);
}
.topbar .account{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar .account .user-info{display:flex;align-items:center;gap:10px;}
.topbar .account img{width:40px;height:40px;border-radius:50%;}

/* MAIN CONTENT */
.main{flex:1;padding:20px;}
.main h2{margin-bottom:20px;color:#333;}
.main p{margin-bottom:15px;line-height:1.5;color:#555;}
.main ul{margin-left:20px;list-style-type:disc;color:#555;}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="sidebar-header">
        <div class="logo"><img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg"></div>
        <h1>TOKO BUKU<br>SEJAHTERA</h1>
    </div>
    <a href="dashboard_admin.php">Dashboard</a>
    <a href="admin_penjual.php">Admin</a>
    <a href="admin_pembeli.php">Pembeli</a>
         <a href="kategori.php"><i class="fa fa-list"></i>Kategori</a>
    <a href="akun_admin.php">My Account</a>
    <div class="bottom-links">
        <a href="../auth/logout.php">Sign Out</a>
           <a href="help_admin.php">Help</a>
    </div>
</div>
<div data-profile-username="<?= htmlspecialchars($superadmin_name ?? '') ?>" data-profile-email="<?= htmlspecialchars($admin['email'] ?? '') ?>" data-profile-phone="" data-profile-address="" data-profile-role="<?= htmlspecialchars($superadmin_role ?? '') ?>"></div>

<!-- MAIN -->
<div class="main">
    <div class="topbar">
        <div></div>
        <div class="account">
            <div class="user-info">
                <span><?= htmlspecialchars($superadmin_name)?> - <?= $superadmin_role ?></span>
                <img src="../uploads/<?= htmlspecialchars($superadmin_photo) ?>">
            </div>
        </div>
    </div>

    <h2>Help - Superadmin</h2>
    <p>Selamat datang di halaman Help untuk Superadmin. Halaman ini berisi panduan penggunaan dashboard dan fitur-fitur penting.</p>
    
    <h3>Fitur Utama:</h3>
    <ul>
        <li><b>Dashboard:</b> Menampilkan semua informasi penjual dan pembeli secara realtime.</li>
        <li><b>Admin:</b> Kelola admin lain, termasuk menambah, mengedit, dan menghapus admin.</li>
        <li><b>Pembeli:</b> Kelola akun pembeli, termasuk status online/offline, detail profil, dan penghapusan akun.</li>
        <li><b>Sign Out:</b> Keluar dari dashboard dengan aman.</li>
    </ul>

    <h3>Cara Menggunakan Dashboard:</h3>
    <ol>
        <li>Gunakan sidebar untuk navigasi antar halaman.</li>
        <li>Gunakan tombol "+" untuk menambah data baru.</li>
        <li>Klik tombol "Edit" pada card untuk memperbarui data.</li>
        <li>Klik tombol "Delete" untuk menghapus data dengan konfirmasi.</li>
        <li>Klik tombol "Detail" untuk melihat informasi lengkap pengguna.</li>
        <li>Gunakan filter dan search di bagian atas untuk mencari data dengan cepat.</li>
    </ol>

    <h3>Kontak Support:</h3>
    <p>Jika ada kendala teknis, hubungi tim IT melalui email: <b>support@tokobukusejahtera.com</b></p>
</div>

</body>
</html>








