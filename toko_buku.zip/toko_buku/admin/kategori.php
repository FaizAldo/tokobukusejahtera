<?php
session_start();    
require '../conn/koneksi.php';
require '../notifikasi/notif_system.php';
require '../notifikasi/widget.php';

// ====== CEK ROLE SUPERADMIN ======
if(!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../auth/login_users.php");
    exit;
}

// Ambil data superadmin dari tabel admin berdasarkan username session
$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT id_admin, username, email, foto, role FROM admin WHERE username=? LIMIT 1");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

// Jika superadmin tidak ditemukan, logout
if (!$admin) {
    session_destroy();
    header("Location: ../auth/login_users.php");
    exit;
}

$superadmin_name  = $admin['username'];
$superadmin_email = $admin['email'];
$superadmin_level = 'Super Admin';
$superadmin_photo = $admin['foto'] ?: 'default.png';
$admin_id         = $admin['id_admin'] ?? 0;

/* ================= TAMBAH KATEGORI ================= */
if (isset($_POST['tambah'])) {
    $nama = trim($_POST['nama_kategori']);

    if ($nama != '') {
        $cek = $conn->query("SELECT * FROM kategori WHERE nama_kategori='$nama'");
        if ($cek->num_rows == 0) {
            $conn->query("INSERT INTO kategori (nama_kategori,status) VALUES ('$nama','aktif')");
            $info = "Kategori berhasil ditambahkan";
        } else {
            $info = "Kategori sudah ada";
        }
    }
}

/* ================= TOGGLE STATUS ================= */
if (isset($_GET['toggle'])) {
    $id = $_GET['toggle'];

    $data = $conn->query("SELECT status FROM kategori WHERE id_kategori='$id'")->fetch_assoc();
    $status = ($data['status'] == 'aktif') ? 'nonaktif' : 'aktif';

    $conn->query("UPDATE kategori SET status='$status' WHERE id_kategori='$id'");
    $_SESSION['success'] = "Status kategori diperbarui";
    header("Location: kategori.php");
    exit;
}

/* ================= HAPUS ================= */
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    $cek = $conn->query("SELECT * FROM produk WHERE kategori_id='$id'");
    if ($cek->num_rows == 0) {
        $conn->query("DELETE FROM kategori WHERE id_kategori='$id'");
        $_SESSION['success'] = "Kategori dihapus";
    } else {
        $_SESSION['error'] = "Kategori masih dipakai oleh produk";
    }
    header("Location: kategori.php");
    exit;
}

/* ================= DATA KATEGORI ================= */
$kategori = $conn->query("SELECT * FROM kategori ORDER BY nama_kategori ASC");

/* ================= UPDATE KATEGORI ================= */
if (isset($_POST['update'])) {
    $id = $_POST['id_kategori'];
    $nama = trim($_POST['nama_kategori']);

    if ($nama != '') {
        $conn->query("UPDATE kategori SET nama_kategori='$nama' WHERE id_kategori='$id'");
        $_SESSION['success'] = "Kategori diperbarui";
    }
    header("Location: kategori.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
    <meta charset="UTF-8">
    <title>Kategori | Superadmin</title>
    <link rel="stylesheet" href="../assets/fontawesome/css/all.min.css">
    <style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* admin-theme */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.sidebar-header{background:#6b2f2f !important;}
.sidebar a{color:#fff !important;}
.sidebar a:hover,.sidebar a.active{background:rgba(255,255,255,0.2) !important;border-left:4px solid #f5d08a !important;}
.bottom-links a{color:#fff !important;}
.main,.main-content{background:#f5f6fa !important;}

/* admin-notif-force */
.notif-widget, .notif-widget *{color:#111 !important;}
.notif-widget .notif-list, .notif-widget .notif-item{background:#fff !important;}
.sidebar .notif-widget a,
.sidebar .notif-widget .notif-item,
.sidebar .notif-widget .notif-item *{
    color:#111 !important;
}
.sidebar .notif-widget .notif-list{
    background:#fff !important;
}

        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:Arial;background:#f4f6f9}

        /* ===== SIDEBAR ===== */
        .sidebar{
            width:250px;
            height:100vh;
            background:#c17159;
            color:#fff;
            position:fixed;
            left:0;
            top:0;
            padding:20px;
        }
        .sidebar-header{display:flex;align-items:center;gap:10px;text-align:left;margin-bottom:25px}
        .sidebar-header img{width:50px;height:50px;border-radius:50%;object-fit:cover}
        .sidebar-header h2{margin:0;font-size:16px;line-height:1.2;}
        .sidebar a{
            display:block;
            color:#fff;
            padding:12px;
            text-decoration:none;
            margin-bottom:6px;
            border-radius:6px;
        }
        .sidebar a:hover,
        .sidebar a.active{
            background:#3498db;
        }

        .bottom-links{
            position:absolute;
            bottom:20px;
            width:210px;
        }

        /* ===== MAIN ===== */
        .main{
            margin-left:270px;
            padding:25px;
        }

        .header{
            background:#fff;
            padding:15px 20px;
            border-radius:10px;
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:20px;
        }
        .header img{
            width:45px;
            height:45px;
            border-radius:50%;
            object-fit:cover;
        }

        .box{
            background:#fff;
            padding:20px;
            border-radius:10px;
            margin-bottom:20px; /* jarak antar box */
        }

        table{
            width:100%;
            border-collapse:collapse;
            margin-top:15px;
        }
        th,td{
            padding:12px;
            border-bottom:1px solid #ddd;
            text-align:left;
        }

        input{
            padding:10px;
            width:70%;
            border:1px solid #ccc;
            border-radius:6px;
        }

        button{
            padding:10px 15px;
            border:none;
            border-radius:6px;
            cursor:pointer;
        }

        .btn{background:#3498db;color:#fff}
        .hapus{background:#e74c3c;color:#fff}
        .toggle{background:#f39c12;color:#fff}

        .info{
            margin-bottom:10px;
            color:green;
        }

        /* modal edit */
        .modal{
            display:none;
            position:fixed;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.5);
            justify-content:center;
            align-items:center;
        }
        .modal-content{
            background:#fff;
            padding:20px;
            border-radius:10px;
            width:300px;
        }
        .modal-content h3{
            margin-bottom:15px;
        }
        .modal-content input{
            width:100%;
            padding:8px;
            margin-bottom:10px;
        }
        .modal-content button{
            padding:8px 12px;
            border:none;
            border-radius:6px;
            cursor:pointer;
        }
    /* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>

<body>

<!-- ================= SIDEBAR ================= -->
<div class="sidebar">
    <div class="sidebar-header">
        <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg">
        <h2>TOKO BUKU<br>SEJAHTERA</h2>
    </div>
    <?php renderNotifWidget('admin', (int)$admin_id); ?>

    <a href="dashboard_admin.php">Dashboard</a>
    <a href="admin_penjual.php">Admin</a>
    <a href="pembeli.php">Pembeli</a>
    <a href="kategori.php" class="active">Kategori</a>
    <a href="akun_admin.php">My Account</a>

    <div class="bottom-links">
        <a href="../auth/logout.php">Sign Out</a>
        <a href="help_admin.php">Help</a>
    </div>
</div>
<div data-profile-username="<?= htmlspecialchars($superadmin_name ?? '') ?>" data-profile-email="<?= htmlspecialchars($superadmin_email ?? '') ?>" data-profile-phone="" data-profile-address=""></div>

<!-- ================= MAIN ================= -->
<div class="main">

    <div class="header">
        <div></div>
        <div style="display:flex;align-items:center;gap:12px;margin-left:auto;">
            <?php renderNotifWidget('admin', (int)$admin_id); ?>
            <div style="display:flex;align-items:center;gap:10px;">
                <div><?= htmlspecialchars($superadmin_name) ?> - <?= $superadmin_level ?></div>
                <img src="../uploads/<?= htmlspecialchars($superadmin_photo) ?>">
            </div>
        </div>
    </div>

    <div class="box">
        <h3>📚 Kelola Kategori</h3>
        <?php if(isset($info)) echo "<div class='info'>$info</div>"; ?>
        <form method="post">
            <input type="text" name="nama_kategori" placeholder="Nama kategori baru" required>
            <button class="btn" name="tambah">Tambah</button>
        </form>

        <table>
            <tr>
                <th>No</th>
                <th>Nama Kategori</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>

            <?php $no=1; while($k=$kategori->fetch_assoc()): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($k['nama_kategori']) ?></td>
                <td><?= $k['status'] ?></td>
                <td>
                    <a href="?toggle=<?= $k['id_kategori'] ?>">
                        <button class="toggle">
                            <?= $k['status']=='aktif'?'Nonaktif':'Aktifkan' ?>
                        </button>
                    </a>
                    <a href="#" onclick="openEditModal(<?= $k['id_kategori'] ?>, '<?= htmlspecialchars($k['nama_kategori']) ?>')">
                        <button class="btn">Edit</button>
                    </a>
                    <a href="?hapus=<?= $k['id_kategori'] ?>" onclick="return confirm('Hapus kategori ini?')">
                        <button class="hapus">Hapus</button>
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<!-- Modal Edit -->
<div class="modal" id="modalEdit">
    <div class="modal-content">
        <h3>Edit Kategori</h3>
        <form method="post">
            <input type="hidden" name="id_kategori" id="edit_id_kategori">
            <input type="text" name="nama_kategori" id="edit_nama_kategori" required>
            <button type="submit" name="update">Update</button>
        </form>
    </div>
</div>

<script>
function openEditModal(id, nama) {
    document.getElementById('edit_id_kategori').value = id;
    document.getElementById('edit_nama_kategori').value = nama;
    document.getElementById('modalEdit').style.display = 'flex';
}
window.onclick = function(event) {
    var modal = document.getElementById('modalEdit');
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

<?php if(isset($info)): ?>
<script>alert("<?= htmlspecialchars($info, ENT_QUOTES, 'UTF-8') ?>");</script>
<?php endif; ?>
<?php if(isset($_SESSION['success'])): ?>
<script>alert("<?= htmlspecialchars($_SESSION['success'], ENT_QUOTES, 'UTF-8') ?>");</script>
<?php unset($_SESSION['success']); endif; ?>
<?php if(isset($_SESSION['error'])): ?>
<script>alert("<?= htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') ?>");</script>
<?php unset($_SESSION['error']); endif; ?>

</body>
</html>








