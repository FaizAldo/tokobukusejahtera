<?php
session_start();
require '../conn/koneksi.php';
header('Content-Type: application/json');

$role = $_SESSION['role'] ?? ($_SESSION['user_role'] ?? '');
if (!isset($_SESSION['username']) || $role !== 'admin') {
    http_response_code(401);
    echo json_encode(['success'=>false,'message'=>'Unauthorized']);
    exit;
}

$response = ['success'=>false,'message'=>'Terjadi kesalahan'];


// =====================
// AJAX DATA PENJUAL
// =====================
if(isset($_GET['ajax']) && $_GET['ajax']=='penjual'){
    $data = [];
    $res = $conn->query("SELECT * FROM penjual ORDER BY id_penjual DESC");
    while($row = $res->fetch_assoc()){
        $data[] = $row;
    }
    echo json_encode($data);
    exit;
}


// =====================
// HAPUS PENJUAL
// =====================
if(isset($_GET['hapus'])){
    $id = intval($_GET['hapus']);
    if($conn->query("DELETE FROM penjual WHERE id_penjual=$id")){
        echo json_encode(['success'=>true,'message'=>'Berhasil dihapus']);
    } else {
        echo json_encode(['success'=>false,'message'=>'Gagal menghapus']);
    }
    exit;
}


// =====================
// INSERT / UPDATE
// =====================
if($_SERVER['REQUEST_METHOD']=='POST'){

    $id       = $_POST['id'] ?? '';
    $nama     = $_POST['nama'] ?? '';
    $username = $_POST['username'] ?? '';
    $email    = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $no_hp    = $_POST['no_hp'] ?? '';
    $alamat   = $_POST['alamat'] ?? '';
    $oldfoto  = $_POST['oldfoto'] ?? '';

    // =====================
    // FOTO
    // =====================
    $foto = $oldfoto;
    if(!empty($_FILES['foto']['tmp_name'])){
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $foto = 'penjual_'.time().'.'.$ext;
        move_uploaded_file($_FILES['foto']['tmp_name'], '../uploads/'.$foto);
    }

    // =====================
    // UPDATE
    // =====================
    if($id){

        if($password != ''){
            $hash = password_hash($password, PASSWORD_DEFAULT);

            $sql = "UPDATE penjual SET 
                    nama_penjual=?, username=?, email=?, no_hp=?, alamat=?, foto=?, password=?
                    WHERE id_penjual=?";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "sssssssi",
                $nama,$username,$email,$no_hp,$alamat,$foto,$hash,$id
            );

        } else {

            $sql = "UPDATE penjual SET 
                    nama_penjual=?, username=?, email=?, no_hp=?, alamat=?, foto=?
                    WHERE id_penjual=?";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssi",
                $nama,$username,$email,$no_hp,$alamat,$foto,$id
            );
        }

        $stmt->execute();
        echo json_encode(['success'=>true,'message'=>'Berhasil diupdate']);
        exit;
    }


    // =====================
    // INSERT
    // =====================
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO penjual
            (nama_penjual, username, email, password, no_hp, alamat, foto, status)
            VALUES (?,?,?,?,?,?,?, 'offline')";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssssss",
        $nama,$username,$email,$hash,$no_hp,$alamat,$foto
    );

    $stmt->execute();
    echo json_encode(['success'=>true,'message'=>'Berhasil ditambahkan']);
    exit;
}
