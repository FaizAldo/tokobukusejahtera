<div class="popup" id="popupEdit">
    <div class="popup-content">
        <h3>Edit Akun</h3>

        <form action="proses_edit_admin.php" method="post" enctype="multipart/form-data">

            <input type="text" name="username" placeholder="Username" required>

            <input type="email" name="email" placeholder="Email" required>

            <input type="password" name="password" placeholder="Password baru (opsional)">

            <input type="file" name="foto">

            <button type="submit">Simpan</button>
            <button type="button" onclick="closePopup()">Batal</button>

        </form>
    </div>
</div>
