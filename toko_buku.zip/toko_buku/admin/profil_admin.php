<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login_users.php');
    exit;
}

$username = $_SESSION['username'];
$query = "SELECT * FROM admin WHERE username='$username' LIMIT 1";
$result = mysqli_query($conn, $query);
$admin = mysqli_fetch_assoc($result);
$admin_id = $admin['id_admin'] ?? 0;

if (!$admin) {
    session_destroy();
    header('Location: ../auth/login_users.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<script src="../assets/responsive.js" defer></script>
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profil Admin - Toko Buku Sejahtera</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* admin-theme */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.sidebar-header{background:#6b2f2f !important;}
.sidebar a{color:#fff !important;}
.sidebar a:hover,.sidebar a.active{background:rgba(255,255,255,0.2) !important;border-left:4px solid #f5d08a !important;}
.bottom-links a{color:#fff !important;}
.main,.main-content{background:#f5f6fa !important;}

body { display: flex; margin:0; font-family: Arial, sans-serif; }
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    height: 100vh;
    background: #8B4513;
    color: white;
    padding: 20px 0;
    z-index: 3000;
}
.sidebar .logo { display:flex; align-items:center; gap:10px; margin-bottom: 30px; padding:0 20px; }
.sidebar .logo img{width:50px;height:50px;border-radius:50%;object-fit:cover;}
.sidebar .logo h2 { font-size: 18px; line-height: 1.2; margin:0; }
.sidebar a { color: white; text-decoration: none; padding: 15px 20px; display: block; transition: 0.3s; }
.sidebar a:hover, .sidebar a.active { background: #A0522D; border-left: 4px solid #FFD700; }

.main-content {
    margin-left: 250px;
    flex: 1;
    background:#f5f6fa;
    min-height:100vh;
}
.topbar { 
    background: white; 
    padding: 15px 30px; 
    box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
}
.topbar .right{display:flex;align-items:center;gap:12px;}
.profile-section { display: flex; align-items: center; gap: 15px; margin-left:auto; }
.profile-img { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; }

.content-area { padding: 30px; }
.profile-card{
    background:#fff;border-radius:12px;padding:24px;
    box-shadow:0 4px 10px rgba(0,0,0,.06);max-width:900px;
}
.profile-card .row{gap:24px}
.profile-photo{width:120px;height:120px;border-radius:12px;object-fit:cover;border:1px solid #e5e7eb}
.profile-meta h4{margin:0 0 6px}
.profile-meta p{margin:0 0 6px;color:#555}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="logo">
        <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
        <h2>TOKO BUKU SEJAHTERA</h2>
    </div>
    <?php renderNotifWidget('admin', (int)$admin_id); ?>
    <a href="dashboard_admin.php">Dashboard</a>
    <a href="admin_penjual.php">Admin</a>
    <a href="pembeli.php">Pembeli</a>
    <a href="kategori.php">Kategori</a>
    <a href="akun_admin.php">My Account</a>
    <a href="../auth/logout.php">Sign Out</a>
    <a href="help_admin.php">Help</a>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">
    <div class="topbar">
        <h3>Profil Admin</h3>
        <div class="right">
            <?php renderNotifWidget('admin', (int)$admin_id); ?>
            <div class="profile-section">
                <img src="<?php echo !empty($admin['foto']) ? '../uploads/'.$admin['foto'] : 'https://via.placeholder.com/50'; ?>" alt="Profile" class="profile-img">
                <div>
                    <strong><?php echo htmlspecialchars($admin['username']); ?></strong><br>
                    <small><?php echo ucfirst($admin['role']); ?></small>
                </div>
            </div>
        </div>
    </div>

    <div class="content-area">
        <div class="profile-card">
            <div class="row align-items-center">
                <div class="col-md-3 text-center">
                    <img class="profile-photo" src="<?php echo !empty($admin['foto']) ? '../uploads/'.$admin['foto'] : 'https://via.placeholder.com/120'; ?>" alt="Admin">
                </div>
                <div class="col-md-9 profile-meta">
                    <h4><?php echo htmlspecialchars($admin['username']); ?></h4>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($admin['email']); ?></p>
                    <p><strong>Role:</strong> <?php echo ucfirst($admin['role']); ?></p>
                    <a class="btn btn-primary" href="akun_admin.php">Edit Profil</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
