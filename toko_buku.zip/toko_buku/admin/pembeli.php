<?php
session_start();
require '../conn/koneksi.php';
require '../notifikasi/notif_system.php';
require '../notifikasi/widget.php';

// ================= CEK LOGIN ADMIN =================
$role = $_SESSION['role'] ?? ($_SESSION['user_role'] ?? '');
if (!isset($_SESSION['username']) || $role !== 'admin') {
    header("Location: ../auth/login_users.php");
    exit;
}

// ================= AMBIL DATA SUPERADMIN BERDASARKAN USERNAME =================
$username = $_SESSION['username'];

$stmt = $conn->prepare("SELECT id_admin, username, email, foto, role FROM admin WHERE username=? LIMIT 1");
$stmt->bind_param("s", $username);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

// Jika superadmin tidak ditemukan, logout
if (!$admin) {
    session_destroy();
    header("Location: ../auth/login_users.php");
    exit;
}

$superadmin_name  = $admin['username'];
$superadmin_email = $admin['email'] ?? '';
$superadmin_role  = $admin['role'];
$superadmin_photo = $admin['foto'] ?: 'default.png';
$admin_id         = $admin['id_admin'] ?? 0;

function esc_js($s) {
    return htmlspecialchars(addslashes($s ?? ''), ENT_QUOTES, 'UTF-8');
}

$pembeli_list = mysqli_query($conn, "SELECT * FROM pembeli ORDER BY id_pembeli DESC");
?>


<!DOCTYPE html>
<html lang="id">
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<title>Dashboard Pembeli</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* admin-theme */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.sidebar-header{background:#6b2f2f !important;}
.sidebar a{color:#fff !important;}
.sidebar a:hover,.sidebar a.active{background:rgba(255,255,255,0.2) !important;border-left:4px solid #f5d08a !important;}
.bottom-links a{color:#fff !important;}
.main,.main-content{background:#f5f6fa !important;}

/* admin-notif-force */
.notif-widget, .notif-widget *{color:#111 !important;}
.notif-widget .notif-list, .notif-widget .notif-item{background:#fff !important;}
.sidebar .notif-widget a,
.sidebar .notif-widget .notif-item,
.sidebar .notif-widget .notif-item *{
    color:#111 !important;
}
.sidebar .notif-widget .notif-list{
    background:#fff !important;
}

/* ===== GLOBAL ===== */
*{margin:0;padding:0;box-sizing:border-box;font-family:Segoe UI,sans-serif;}
body{display:flex;background:#f2f2f2;}

/* ===== SIDEBAR ===== */
.sidebar{
    width:250px;height:100vh;background:#c17159;color:#fff;
    display:flex;flex-direction:column;
}
.sidebar-header{
    display:flex;align-items:center;gap:10px;padding:20px;background:brown;
}
.sidebar-header .logo{width:50px;height:50px;border-radius:50%;overflow:hidden;}
.sidebar-header .logo img{width:100%;height:100%;object-fit:cover;}
.sidebar-header h1{font-size:16px;line-height:1.2;white-space:normal;}
.sidebar a{
    color:#fff;text-decoration:none;padding:10px 15px;margin:5px 10px;border-radius:5px;display:block;
}
.sidebar a:hover,.sidebar a.active{background:#00acc1;}
.bottom-links{margin-top:auto;padding-bottom:15px;}

/* ===== MAIN ===== */
.main{flex:1;padding:20px;position:relative;margin-left:250px;}
.topbar{
    padding:15px;background:#fff;display:flex;justify-content:space-between;align-items:center;
    box-shadow:0 2px 5px rgba(0,0,0,.1);border-radius:10px;margin-bottom:20px;
}
.topbar input[type=text]{padding:8px 12px;width:300px;border-radius:5px;border:1px solid #ccc;}
.topbar .filter{margin-left:10px;padding:8px 12px;border-radius:5px;border:1px solid #ccc;}
.topbar .account{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar .account .user-info{display:flex;align-items:center;gap:10px;}
.topbar .account img{width:40px;height:40px;border-radius:50%;object-fit:cover;}

/* ===== CARDS ===== */
.cards{display:flex;flex-wrap:wrap;gap:20px;justify-content:flex-start;}
.card{
    width:250px;padding:20px;border-radius:15px;box-shadow:0 2px 10px rgba(0,0,0,.1);
    text-align:center;color:#fff;transition:background 0.3s;position:relative;
}
.card.online{background:#4caf50;}
.card.offline{background:#e74c3c;}
.card img{width:80px;height:80px;border-radius:50%;margin-bottom:10px;object-fit:cover;}
.card p{margin:5px 0;font-size:14px;}
.card button{
    padding:5px 10px;margin:3px;border:none;border-radius:5px;cursor:pointer;
}
.card .edit{background:#00acc1;color:#fff;}
.card .delete{background:#e53935;color:#fff;}
.card .detail{background:#2fc6bf;color:#fff;}

/* ===== TAMBAH BUTTON ===== */
.add-btn{
    position:fixed;right:50px;bottom:50px;width:60px;height:60px;background:#00acc1;color:#fff;
    font-size:36px;border-radius:50%;border:none;cursor:pointer;
    display:flex;justify-content:center;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.3);
}

/* ===== MODAL ===== */
.modal{
    display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);justify-content:center;align-items:center;
}
.modal-content{
    background:#fff;padding:25px;width:350px;border-radius:15px;display:flex;flex-direction:column;gap:10px;
}
.modal-content input, .modal-content textarea{padding:8px;border:1px solid #ccc;border-radius:5px;width:100%;}
.modal-content button{padding:8px;background:#00acc1;color:#fff;border:none;border-radius:5px;cursor:pointer;}
.modal-content button.cancel{background:#e53935;}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="sidebar-header">
        <div class="logo"><img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg"></div>
        <h1>TOKO BUKU<br>SEJAHTERA</h1>
    </div>
    <?php renderNotifWidget('admin', (int)$admin_id); ?>
    <a href="dashboard_admin.php">Dashboard</a>
    <a href="admin_penjual.php">Admin</a>
    <a href="pembeli.php" class="active">Pembeli</a>
    <a href="kategori.php">Kategori</a>
    <a href="akun_admin.php">My Account</a>
    <div class="bottom-links">
        <a href="../auth/logout.php">Sign Out</a>
        <a href="help_admin.php">Help</a>
    </div>
</div>
<div data-profile-username="<?= htmlspecialchars($superadmin_name ?? '') ?>" data-profile-email="<?= htmlspecialchars($admin['email'] ?? '') ?>" data-profile-phone="" data-profile-address=""></div>

<!-- MAIN -->
<div class="main">
    <div class="topbar">
        <div>
            <input type="text" id="search" placeholder="Cari pembeli...">
            <select class="filter" id="filterStatus">
                <option value="">Semua</option>
                <option value="online">Online</option>
                <option value="offline">Offline</option>
            </select>
        </div>
        <div class="account">
            <?php renderNotifWidget('admin', (int)$admin_id); ?>
            <div class="user-info">
                <span><?= htmlspecialchars($superadmin_name) ?></span>
                <img src="../uploads/<?= htmlspecialchars($superadmin_photo) ?>">
            </div>
        </div>
    </div>

    <!-- CARDS -->
    <div class="cards" id="pembeliData">
        <?php if ($pembeli_list): ?>
            <?php while($p = mysqli_fetch_assoc($pembeli_list)): 
                $nik = $p['nik'] ?? '';
                $username_p = $p['username'] ?? '';
                $email = $p['email'] ?? '';
                $no_hp = $p['no_hp'] ?? '';
                $alamat = $p['alamat'] ?? '';
                $foto = $p['foto'] ?: 'default.png';
                $status = $p['status'] ?? 'offline';
            ?>
            <div class="card <?= htmlspecialchars($status) ?>" data-nik="<?= esc_js($nik) ?>" data-username="<?= esc_js($username_p) ?>" data-email="<?= esc_js($email) ?>" data-nohp="<?= esc_js($no_hp) ?>" data-alamat="<?= esc_js($alamat) ?>" data-status="<?= esc_js($status) ?>" data-foto="../uploads/<?= esc_js($foto) ?>">
                <img src="../uploads/<?= esc_js($foto) ?>">
                <p><b><?= htmlspecialchars($nik) ?></b></p>
                <p><?= htmlspecialchars($username_p) ?></p>
                <p><?= htmlspecialchars($email) ?></p>
                <p>No HP: <?= htmlspecialchars($no_hp) ?></p>
                <p>Status: <?= htmlspecialchars($status) ?></p>
                <button class="edit" onclick="openEditModal(<?= (int)$p['id_pembeli'] ?>,'<?= esc_js($nik) ?>','<?= esc_js($username_p) ?>','<?= esc_js($email) ?>','<?= esc_js($no_hp) ?>','<?= esc_js($alamat) ?>','<?= esc_js($foto) ?>')">Edit</button>
                <button class="delete" onclick="hapus(<?= (int)$p['id_pembeli'] ?>)">Delete</button>
                <button class="detail" onclick="detail(<?= (int)$p['id_pembeli'] ?>)">Detail</button>
            </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>

    <!-- TAMBAH BUTTON -->
    <button class="add-btn" onclick="openTambah()">+</button>
</div>

<!-- MODAL TAMBAH -->
<div class="modal" id="modalTambah">
    <div class="modal-content">
        <h3>Tambah Pembeli</h3>
        <form id="formTambah">
            <input name="nik" id="nik" placeholder="NIK" required>
            <input name="username" id="username" placeholder="Username" required>
            <input name="email" id="email" placeholder="Email" required>
            <input name="password" id="password" placeholder="Password">
            <input name="no_hp" id="no_hp" placeholder="No HP">
            <textarea name="alamat" id="alamat" placeholder="Alamat"></textarea>
            <input type="file" name="foto" id="foto">
            <button type="submit">Simpan</button>
        </form>
        <button class="cancel" onclick="closeModal('modalTambah')">Batal</button>
    </div>
</div>

<!-- MODAL EDIT -->
<div class="modal" id="modalEdit">
    <div class="modal-content">
        <h3>Edit Pembeli</h3>
        <form id="formEdit">
            <input type="hidden" name="id" id="edit_id">
            <input type="hidden" name="oldfoto" id="edit_oldfoto">
            <input name="edit_nik" id="edit_nik" placeholder="NIK" required>
            <input name="edit_username" id="edit_username" placeholder="Username" required>
            <input name="edit_email" id="edit_email" placeholder="Email" required>
            <input name="edit_password" id="edit_password" placeholder="Password">
            <input name="edit_no_hp" id="edit_no_hp" placeholder="No HP">
            <textarea name="edit_alamat" id="edit_alamat" placeholder="Alamat"></textarea>
            <input type="file" name="edit_foto" id="edit_foto">
            <button type="submit">Update</button>
        </form>
        <button class="cancel" onclick="closeModal('modalEdit')">Batal</button>
    </div>
</div>

<!-- MODAL DETAIL -->
<div class="modal" id="modalDetail">
    <div class="modal-content">
        <h3>Detail Pembeli</h3>
        <img id="detailFoto" src="" style="width:100px;height:100px;border-radius:50%;margin-bottom:10px;">
        <p><b>NIK:</b> <span id="detailNik"></span></p>
        <p><b>Username:</b> <span id="detailUsername"></span></p>
        <p><b>Email:</b> <span id="detailEmail"></span></p>
        <p><b>No HP:</b> <span id="detailNoHp"></span></p>
        <p><b>Alamat:</b> <span id="detailAlamat"></span></p>
        <p><b>Status:</b> <span id="detailStatus"></span></p>
        <button onclick="closeModal('modalDetail')" style="margin-top:10px;background:#e53935;">Tutup</button>
    </div>
</div>

<script>
function escapeHtml(str){return str?str.replace(/'/g,"\\'").replace(/"/g,'\\"'):"";}
function closeModal(id){document.getElementById(id).style.display='none';}

/* ===== LOAD DATA REALTIME ===== */
function loadPembeli(){
    let keyword=document.getElementById('search').value.toLowerCase();
    let filterStatus=document.getElementById('filterStatus').value;
    fetch('proses_pembeli.php?ajax=pembeli')
    .then(r=>r.json())
    .then(data=>{
        let html='';
        data.forEach(p=>{
            let nik=escapeHtml(p.nik);
            let username=escapeHtml(p.username);
            let email=escapeHtml(p.email);
            let no_hp=escapeHtml(p.no_hp);
            let alamat=escapeHtml(p.alamat);
            let foto=p.foto||'default.png';
            let status=p.status||'offline';
            if((!filterStatus||status===filterStatus)&&(!keyword||nik.toLowerCase().includes(keyword)||username.toLowerCase().includes(keyword))){
                html+=`
                <div class="card ${status}">
                    <img src="../uploads/${foto}">
                    <p><b>${nik}</b></p>
                    <p>${username}</p>
                    <p>${email}</p>
                    <p>No HP: ${no_hp}</p>
                    <p>Status: ${status}</p>
                    <button class="edit" onclick="openEditModal(${p.id_pembeli},'${nik}','${username}','${email}','${no_hp}','${alamat}','${foto}')">Edit</button>
                    <button class="delete" onclick="hapus(${p.id_pembeli})">Delete</button>
                    <button class="detail" onclick="detail(${p.id_pembeli})">Detail</button>
                </div>`;
            }
        });
        document.getElementById('pembeliData').innerHTML=html;
    });
}
// setInterval(loadPembeli,3000);

/* ===== MODAL TAMBAH ===== */
function openTambah(){document.getElementById('modalTambah').style.display='flex';document.getElementById('formTambah').reset();}

/* ===== MODAL EDIT ===== */
function openEditModal(id,nik,username,email,no_hp,alamat,foto){
    document.getElementById('modalEdit').style.display='flex';
    document.getElementById('edit_id').value=id;
    document.getElementById('edit_nik').value=nik;
    document.getElementById('edit_username').value=username;
    document.getElementById('edit_email').value=email;
    document.getElementById('edit_no_hp').value=no_hp;
    document.getElementById('edit_alamat').value=alamat;
    document.getElementById('edit_oldfoto').value=foto;
    document.getElementById('edit_password').value='';
}

/* ===== HAPUS ===== */
function hapus(id){
    if(confirm('Hapus pembeli?')){
        fetch('proses_pembeli.php?hapus='+id)
        .then(r=>r.json())
        .then(res=>{alert(res.message);if(res.success) loadPembeli();});
    }
}

/* ===== DETAIL ===== */
function detail(id){
    fetch('proses_pembeli.php?detail=' + id)
    .then(res=>res.json())
    .then(p=>{
        document.getElementById('detailFoto').src='../uploads/'+(p.foto?p.foto:'default.png');
        document.getElementById('detailNik').innerText=p.nik;
        document.getElementById('detailUsername').innerText=p.username;
        document.getElementById('detailEmail').innerText=p.email;
        document.getElementById('detailNoHp').innerText=p.no_hp||'-';
        document.getElementById('detailAlamat').innerText=p.alamat||'-';
        document.getElementById('detailStatus').innerText=p.status;
        document.getElementById('modalDetail').style.display='flex';
    });
}

/* ===== FILTER & SEARCH ===== */
document.getElementById('search').addEventListener('input',loadPembeli);
document.getElementById('filterStatus').addEventListener('change',loadPembeli);

/* ===== SUBMIT TAMBAH / EDIT ===== */
document.getElementById('formTambah').addEventListener('submit', function(e){
    e.preventDefault();
    const form = e.target;
    const fd = new FormData(form);
    fetch('proses_pembeli.php', { method:'POST', body: fd })
    .then(r=>r.json())
    .then(res=>{
        alert(res.message || 'Selesai');
        if(res.success){
            closeModal('modalTambah');
            form.reset();
            loadPembeli();
        }
    });
});

document.getElementById('formEdit').addEventListener('submit', function(e){
    e.preventDefault();
    const fd = new FormData();
    fd.append('id', document.getElementById('edit_id').value);
    fd.append('nik', document.getElementById('edit_nik').value);
    fd.append('username', document.getElementById('edit_username').value);
    fd.append('email', document.getElementById('edit_email').value);
    fd.append('password', document.getElementById('edit_password').value);
    fd.append('no_hp', document.getElementById('edit_no_hp').value);
    fd.append('alamat', document.getElementById('edit_alamat').value);
    fd.append('oldfoto', document.getElementById('edit_oldfoto').value);
    const foto = document.getElementById('edit_foto').files[0];
    if (foto) fd.append('foto', foto);
    fetch('proses_pembeli.php', { method:'POST', body: fd })
    .then(r=>r.json())
    .then(res=>{
        alert(res.message || 'Selesai');
        if(res.success){
            closeModal('modalEdit');
            loadPembeli();
        }
    });
});
</script>
</body>
</html>








