<?php
session_start();
require '../conn/koneksi.php';

/* ================= CEK SESSION ================= */
$role = $_SESSION['role'] ?? ($_SESSION['user_role'] ?? '');
if (!isset($_SESSION['username']) || $role !== 'admin') {
    header("Location: ../auth/login_users.php");
    exit;
}

/* ================= ID AMAN ================= */
$username_sess = $_SESSION['username'];
$row_admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_admin FROM admin WHERE username='$username_sess' LIMIT 1"));
$id_admin = $row_admin['id_admin'] ?? 0;
if (!$id_admin) {
    header("Location: ../auth/login_users.php");
    exit;
}

$username = trim($_POST['username'] ?? '');
$username_new = trim($_POST['username_new'] ?? '');
$email    = trim($_POST['email'] ?? '');
$nama     = trim($_POST['nama'] ?? '');
$password = trim($_POST['password']);

/* ================= VALIDASI ================= */
if ($nama === '' || ($username_new === '' && $username === '') || $email === '') {
    $_SESSION['error'] = "Nama, Username, dan Email wajib diisi";
    $redirect = $_POST['redirect'] ?? 'dashboard_admin.php';
    if (!in_array($redirect, ['dashboard_admin.php', 'akun_admin.php'], true)) {
        $redirect = 'dashboard_admin.php';
    }
    header("Location: " . $redirect);
    exit;
}

/* ================= DATA LAMA ================= */
$q = mysqli_query($conn, "SELECT foto FROM admin WHERE id_admin='$id_admin'");
$old = mysqli_fetch_assoc($q);
$foto_lama = $old['foto'];

$foto_baru = $foto_lama;

/* ================= UPLOAD FOTO ================= */
if (!empty($_FILES['foto']['name'])) {

    $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
    $nama_foto = 'admin_' . time() . '.' . $ext;
    $folder = "../uploads/";

    if (move_uploaded_file($_FILES['foto']['tmp_name'], $folder . $nama_foto)) {

        if ($foto_lama && $foto_lama !== 'default.png') {
            @unlink($folder . $foto_lama);
        }

        $foto_baru = $nama_foto;
    }
}

/* ================= UPDATE ================= */
$final_username = $username_new !== '' ? $username_new : $username;

if ($password != '') {

    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("
        UPDATE admin 
        SET nama=?, username=?, email=?, password=?, foto=?
        WHERE id_admin=?
    ");

    $stmt->bind_param(
        "sssssi",
        $nama,
        $final_username,
        $email,
        $password_hash,
        $foto_baru,
        $id_admin
    );

} else {

    $stmt = $conn->prepare("
        UPDATE admin 
        SET nama=?, username=?, email=?, foto=?
        WHERE id_admin=?
    ");

    $stmt->bind_param(
        "ssssi",
        $nama,
        $final_username,
        $email,
        $foto_baru,
        $id_admin
    );
}

/* ================= EKSEKUSI ================= */
if ($stmt->execute()) {

    $_SESSION['username'] = $final_username;
    $_SESSION['foto']     = $foto_baru;

    $_SESSION['success'] = "Profil berhasil diperbarui";
} else {
    $_SESSION['error'] = "Gagal memperbarui profil";
}

$redirect = $_POST['redirect'] ?? 'dashboard_admin.php';
if (!in_array($redirect, ['dashboard_admin.php', 'akun_admin.php'], true)) {
    $redirect = 'dashboard_admin.php';
}
header("Location: " . $redirect);
exit;
