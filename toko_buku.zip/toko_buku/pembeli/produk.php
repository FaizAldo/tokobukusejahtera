<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

// ================= CEK LOGIN =================
if(!isset($_SESSION['username'])){
    header("Location: ../auth/login_users.php");
    exit;
}

// Ambil data pembeli
$username = $_SESSION['username'];
$pembeli = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pembeli WHERE username='$username'"));
$pembeli_id = $pembeli['id_pembeli'] ?? 0;

// ================= AMBIL SEMUA PRODUK =================
$produk_result = mysqli_query($conn, "
    SELECT p.*, pen.nama_penjual 
    FROM produk p
    JOIN penjual pen ON p.penjual_id = pen.id_penjual
    WHERE p.status='aktif' AND p.stok > 0
    ORDER BY p.nama_produk ASC
");

// ================= DETAIL PRODUK =================
$detail_id = (int)($_GET['id'] ?? 0);
$detail = null;
if ($detail_id > 0) {
    $detail = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT p.*, pen.nama_penjual 
        FROM produk p
        JOIN penjual pen ON p.penjual_id = pen.id_penjual
        WHERE p.id_produk='$detail_id' AND p.status='aktif'
        LIMIT 1
    "));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<script src="../assets/responsive.js" defer></script>
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Produk</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
body{margin:0;font-family:'Poppins',sans-serif;background:#f5f6fa;color:#333;}
*{box-sizing:border-box;}
a{text-decoration:none;color:inherit;}
.sidebar{width:260px;height:100vh;background:linear-gradient(180deg,#8d4545,#6b2f2f);position:fixed;left:0;top:0;color:#fff;padding:20px;overflow-y:auto;}
.sidebar .profile{text-align:center;margin-bottom:25px;}
.sidebar .profile img{width:75px;height:75px;border-radius:50%;border:3px solid #fff;object-fit:cover;}
.sidebar .profile h3{margin:8px 0 0;font-size:17px;}
.sidebar .menu{list-style:none;padding:0;margin:0;}
.sidebar .menu li{margin:6px 0;list-style:none;}
.sidebar .menu li a{display:block;padding:11px 14px;border-radius:8px;color:#fff;transition:0.25s;}
.sidebar .menu li a:hover{background:rgba(255,255,255,0.2);}
.sidebar .menu li a.active{background:rgba(255,255,255,0.3);font-weight:700;}
.sidebar .menu li.logout a{background:#ef4444;}
main{margin-left:260px;padding:20px 25px;}
header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;}
header input{padding:7px 15px;border-radius:25px;border:none;width:300px;transition:0.3s;}
header input:focus{outline:none;box-shadow:0 0 8px rgba(30,144,255,0.5);}
.produk-container{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:20px;}
.produk-card{background:#fff;padding:15px;border-radius:10px;box-shadow:0 4px 12px rgba(0,0,0,0.08);display:flex;flex-direction:column;align-items:center;text-align:center;transition:0.3s;width:100%;height:380px;cursor:pointer;}
.produk-card:hover{transform:translateY(-5px);box-shadow:0 8px 20px rgba(0,0,0,0.12);}
.produk-card img{width:150px;height:150px;object-fit:cover;border-radius:8px;margin-bottom:10px;}
.produk-card h3{font-size:16px;color:#1e90ff;margin-bottom:5px;height:40px;overflow:hidden;}
.produk-card p{font-size:14px;color:#555;margin:2px 0;height:18px;overflow:hidden;text-align:center;}
.produk-card .btn{margin-top:auto;padding:8px 10px;border:none;border-radius:5px;background:#1e90ff;color:#fff;font-weight:600;width:100%;cursor:pointer;transition:0.3s;font-size:14px;display:inline-block;text-align:center;}
.produk-card .btn:hover{background:#187bcd;}
.detail-card{background:#fff;padding:20px;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,0.08);max-width:900px;margin-bottom:20px;}
.detail-grid{display:grid;grid-template-columns:220px 1fr;gap:20px;align-items:start;}
.detail-img{width:220px;height:220px;object-fit:cover;border-radius:10px;border:1px solid #eee;}
.detail-title{font-size:20px;margin:0 0 6px;color:#1e90ff;}
.detail-meta{color:#555;margin:4px 0;}
.detail-actions{margin-top:12px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;}
.detail-actions .btn{width:auto;}
.popup{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);display:flex;justify-content:center;align-items:center;opacity:0;pointer-events:none;transition:0.3s;z-index:3000;}
.popup.show{opacity:1;pointer-events:auto;}
.popup-content{background:#fff;padding:20px 25px;border-radius:10px;width:420px;max-width:92%;text-align:left;position:relative;max-height:90%;overflow-y:auto;display:flex;flex-direction:column;gap:10px;}
.popup-content img{width:100%;height:240px;object-fit:cover;border-radius:8px;margin-bottom:10px;}
.popup-content h3{color:#1e90ff;margin:0;}
.popup-content p{color:#555;margin:2px 0;}
.popup-content .close{position:absolute;top:10px;right:10px;font-size:20px;font-weight:bold;color:#333;cursor:pointer;}
.popup-content .actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:6px;}
.popup-content .actions .btn{width:auto;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="profile">
        <img src="../uploads/<?= $pembeli['foto']; ?>">
        <h3><?= $pembeli['username']; ?></h3>
    </div>
    <?php renderNotifWidget('pembeli', (int)$pembeli_id); ?>

    <ul class="menu">
        <li><a href="dashboard_pembeli.php">Dashboard</a></li>
        <li><a class="active" href="produk.php">Produk</a></li>
        <li><a href="pesanan.php">Pesanan</a></li>
        <li><a href="status.php">Status</a></li>
        <li><a href="chat.php">Chat</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="akun.php">My Account</a></li>
        <li><a href="help.php">Help</a></li>
        <li class="logout"><a href="../auth/logout.php">Sign Out</a></li>
    </ul>
</div>

<main>
<header>
    <input type="text" placeholder="Cari buku...">
    <div class="right" style="display:flex;align-items:center;gap:12px;margin-left:auto;">
        <?php renderNotifWidget('pembeli', (int)$pembeli_id); ?>
        <div class="user" style="display:flex;align-items:center;gap:10px;">
            <span><?= htmlspecialchars($pembeli['username']); ?></span>
            <img src="../uploads/<?= htmlspecialchars($pembeli['foto'] ?: 'default.png'); ?>" alt="Profil" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
        </div>
    </div>
</header>

<h2>Daftar Produk</h2>
<div class="produk-container">
<?php while($row = mysqli_fetch_assoc($produk_result)): ?>
    <div class="produk-card">
        <img src="../uploads/<?= $row['foto']; ?>" alt="<?= htmlspecialchars($row['nama_produk']); ?>">
        <h3><?= htmlspecialchars($row['nama_produk']); ?></h3>
        <p>Penjual: <?= htmlspecialchars($row['nama_penjual']); ?></p>
        <p>Harga: Rp <?= number_format($row['harga']); ?></p>
        <p>Stok: <?= $row['stok']; ?></p>
        <button class="btn btn-detail"
            data-id="<?= (int)$row['id_produk']; ?>"
            data-nama="<?= htmlspecialchars($row['nama_produk']); ?>"
            data-penjual="<?= htmlspecialchars($row['nama_penjual']); ?>"
            data-harga="<?= number_format($row['harga']); ?>"
            data-stok="<?= (int)$row['stok']; ?>"
            data-status="<?= htmlspecialchars($row['status']); ?>"
            data-foto="<?= htmlspecialchars($row['foto']); ?>"
        >Lihat Detail</button>
    </div>
<?php endwhile; ?>
</div>
</main>

<!-- POPUP DETAIL -->
<div class="popup" id="popupDetail">
    <div class="popup-content">
        <span class="close" id="closeDetail">&times;</span>
        <img id="detailFoto" src="" alt="produk">
        <h3 id="detailNama"></h3>
        <p><strong>Penjual:</strong> <span id="detailPenjual"></span></p>
        <p><strong>Harga:</strong> <span id="detailHarga"></span></p>
        <p><strong>Stok:</strong> <span id="detailStok"></span></p>
        <p><strong>Status:</strong> <span id="detailStatus"></span></p>
        <div class="actions">
            <a class="btn" id="detailPesan" href="#">Lanjut ke Pesanan</a>
        </div>
    </div>
</div>

<script>
const popup = document.getElementById('popupDetail');
const closeBtn = document.getElementById('closeDetail');
const detailFoto = document.getElementById('detailFoto');
const detailNama = document.getElementById('detailNama');
const detailPenjual = document.getElementById('detailPenjual');
const detailHarga = document.getElementById('detailHarga');
const detailStok = document.getElementById('detailStok');
const detailStatus = document.getElementById('detailStatus');
const detailPesan = document.getElementById('detailPesan');

document.querySelectorAll('.btn-detail').forEach(btn => {
    btn.addEventListener('click', () => {
        detailFoto.src = '../uploads/' + btn.dataset.foto;
        detailNama.textContent = btn.dataset.nama;
        detailPenjual.textContent = btn.dataset.penjual;
        detailHarga.textContent = 'Rp ' + btn.dataset.harga;
        detailStok.textContent = btn.dataset.stok;
        detailStatus.textContent = btn.dataset.status;
        detailPesan.href = 'pesanan.php?produk=' + btn.dataset.id;
        popup.classList.add('show');
    });
});

closeBtn.addEventListener('click', () => popup.classList.remove('show'));
popup.addEventListener('click', (e) => { if (e.target === popup) popup.classList.remove('show'); });
</script>

</body>
</html>







