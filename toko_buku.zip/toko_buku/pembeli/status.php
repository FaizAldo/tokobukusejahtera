<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if(!isset($_SESSION['username'])){
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];

// Ambil data pembeli
$pembeli = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT * FROM pembeli WHERE username='$username'")
);
$id_pembeli = $pembeli['id_pembeli'];

/* ================= TERIMA BARANG ================= */
if(isset($_POST['aksi']) && $_POST['aksi']=='terima'){
    $id = intval($_POST['id']);
    $info = mysqli_fetch_assoc(mysqli_query($conn,"
        SELECT id_penjual, kode_pesanan
        FROM pesanan
        WHERE id_pesanan='$id'
        LIMIT 1
    "));
    $id_penjual = (int) ($info['id_penjual'] ?? 0);
    $kode = $info['kode_pesanan'] ?? '-';

    mysqli_query($conn,"UPDATE pesanan SET status='selesai' WHERE id_pesanan='$id'");

    if($id_penjual > 0){
        kirimNotif('penjual', $id_penjual, "Pesanan $kode telah diterima pembeli.", 'approve.php');
        kirimNotifKeSuperadmin("Pesanan $kode selesai oleh pembeli #$id_pembeli.");
    }
    kirimNotif('pembeli', $id_pembeli, "Terima kasih! Pesanan $kode telah selesai.", 'status.php');
    exit;
}

/* ================= LOAD DATA ================= */
if(isset($_GET['load'])){
    $q = mysqli_query($conn,"
        SELECT p.*, pr.nama_produk
        FROM pesanan p
        JOIN produk pr ON p.id_produk = pr.id_produk
        WHERE p.id_pembeli='$id_pembeli'
        ORDER BY p.id_pesanan DESC
    ");

    while($r=mysqli_fetch_assoc($q)){
        echo "<tr>
            <td>{$r['kode_pesanan']}</td>
            <td>{$r['nama_produk']}</td>
            <td>{$r['jumlah']}</td>
            <td>Rp ".number_format($r['total_harga'])."</td>
            <td>{$r['status']}</td>
            <td>".($r['no_resi'] ?: '-')."</td>
            <td>";

        if($r['bukti_transfer']){
            echo "<img 
                    src='../uploads/{$r['bukti_transfer']}'
                    width='50'
                    style='cursor:pointer'
                    onclick=\"openBukti('../uploads/{$r['bukti_transfer']}')\"
                  >";
        }else{
            echo "-";
        }

        echo "</td><td>";

        if($r['status']=='dikirim'){
            echo "<button onclick=\"terima({$r['id_pesanan']})\">Terima</button>";
        }else{
            echo "-";
        }

        echo "</td></tr>";
    }
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<title>Status Pesanan</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins}
body{display:flex;background:#f5f6fa;height:100vh}

/* Notifikasi (hitam di atas putih) */
.notif-widget{
    --notif-accent: #111111;
    --notif-accent-2: #111111;
    --notif-bg: #ffffff;
    --notif-text: #111111;
    --notif-muted: #5f5f5f;
    --notif-new: #f7f7f7;
    --notif-border: #e5e7eb;
}
.sidebar .notif-widget,
.sidebar .notif-widget *{
    color:#111111 !important;
}
.sidebar .notif-widget .notif-list{
    background:#ffffff !important;
    border-color:#e5e7eb !important;
}

/* SIDEBAR */
.sidebar{
    width:230px;
    background:#8d4545;
    color:#fff;
    padding:20px;
}
.sidebar img{
    width:70px;height:70px;border-radius:50%;
}
.menu a{
    display:block;
    padding:10px;
    color:#fff;
    text-decoration:none;
    border-radius:8px;
}
.menu{list-style:none;padding:0;margin:0}
.menu li{list-style:none;margin:6px 0}
.menu a:hover{background:rgba(255,255,255,.25)}

/* CONTENT */
main{flex:1;padding:25px}
h2{margin-bottom:20px}
table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
}
th,td{
    border:1px solid #ccc;
    padding:10px;
    text-align:center;
}
td img{
    border-radius:4px;
    object-fit:cover;
}
button{
    padding:6px 10px;
    background:#16a34a;
    border:none;
    color:#fff;
    border-radius:6px;
    cursor:pointer;
}
button:hover{opacity:.9}

/* MODAL BUKTI */
.modal{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.7);
    justify-content:center;
    align-items:center;
    z-index:999;
}
.modal-box{
    background:#fff;
    padding:20px;
    border-radius:12px;
    max-width:420px;
    width:90%;
    text-align:center;
}
.modal-box img{
    width:100%;
    max-height:60vh;
    object-fit:contain;
    border-radius:8px;
    margin:10px 0;
}
.modal-action{
    display:flex;
    gap:10px;
    justify-content:center;
}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="profile">
        <img src="../uploads/<?= $pembeli['foto']; ?>">
        <h3><?= $pembeli['username']; ?></h3>
    </div>
    <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>

    <ul class="menu">
        <li><a href="dashboard_pembeli.php">Dashboard</a></li>
                <li><a href="produk.php">Produk</a></li>
        <li><a href="pesanan.php">Pesanan</a></li>
        <li><a href="status.php">Status</a></li>
        <li><a href="chat.php">Chat</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="akun.php">My Account</a></li>
        <li><a href="help.php">Help</a></li>
        <li><a class="logout" href="../auth/logout.php">Sign Out</a></li>
    </ul>
</div>

<!-- CONTENT -->
<main>
    <div class="topbar-account">
        <div class="title">Profil</div>
        <div class="right">
            <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>
            <div class="user">
                <span><?= htmlspecialchars($pembeli['username']); ?></span>
                <img src="../uploads/<?= htmlspecialchars($pembeli['foto'] ?: 'default.png'); ?>" alt="Profil">
            </div>
        </div>
    </div>
    <h2>Status Pesanan</h2>
    <table>
        <thead>
            <tr>
                <th>Kode</th>
                <th>Produk</th>
                <th>Qty</th>
                <th>Total</th>
                <th>Status</th>
                <th>No Resi</th>
                <th>Bukti</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody id="data"></tbody>
    </table>
</main>

<!-- MODAL BUKTI -->
<div class="modal" id="modalBukti" onclick="closeModal()">
    <div class="modal-box" onclick="event.stopPropagation()">
        <h3>Bukti Transaksi</h3>
        <img id="imgBukti">
        <div class="modal-action">
            <a id="downloadBukti" download>
                <button style="background:#2563eb">⬇ Download</button>
            </a>
            <button onclick="closeModal()" style="background:#ef4444">Tutup</button>
        </div>
    </div>
</div>

<script>
function load(){
    fetch("status.php?load=1")
    .then(r=>r.text())
    .then(t=>data.innerHTML=t);
}

function terima(id){
    if(!confirm("Yakin barang sudah diterima?")) return;
    let fd=new FormData();
    fd.append("aksi","terima");
    fd.append("id",id);
    fetch("status.php",{method:"POST",body:fd})
    .then(()=>{ alert("Pesanan selesai 🙏"); load(); });
}

function openBukti(src){
    imgBukti.src = src;
    downloadBukti.href = src;
    modalBukti.style.display = "flex";
}
function closeModal(){
    modalBukti.style.display = "none";
    imgBukti.src = "";
}
document.addEventListener("keydown",e=>{
    if(e.key==="Escape") closeModal();
});

load();
setInterval(load,3000);
</script>

</body>
</html>










