<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if(!isset($_SESSION['username'])){
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];

/* ================= DATA PEMBELI ================= */
$pembeli = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT * FROM pembeli WHERE username='$username'")
);

$id_pembeli = $pembeli['id_pembeli'];

/* ================= VALIDASI DATA ================= */
$data_lengkap = true;
$wajib = ['username','alamat','no_hp'];

foreach($wajib as $f){
    if(empty($pembeli[$f])){
        $data_lengkap = false;
        break;
    }
}

/* ================= KODE PESANAN ================= */
function buatKodePesanan($conn){
    $tgl = date('Ymd');

    $q = mysqli_query($conn,"
        SELECT kode_pesanan FROM pesanan
        WHERE kode_pesanan LIKE 'INV-$tgl-%'
        ORDER BY id_pesanan DESC
        LIMIT 1
    ");

    if(mysqli_num_rows($q)){
        $d = mysqli_fetch_assoc($q);
        $no = intval(substr($d['kode_pesanan'], -4)) + 1;
    } else {
        $no = 1;
    }

    return "INV-$tgl-" . str_pad($no,4,'0',STR_PAD_LEFT);
}

/* ================= LOAD KERANJANG ================= */
if(isset($_GET['aksi']) && $_GET['aksi']=='load'){

    $q = mysqli_query($conn,"
        SELECT ps.*, pr.nama_produk, pr.foto, pn.nama_penjual
        FROM pesanan ps
        JOIN produk pr ON ps.id_produk = pr.id_produk
        JOIN penjual pn ON ps.id_penjual = pn.id_penjual
        WHERE ps.id_pembeli='$id_pembeli'
        AND ps.status='menunggu'
        AND (ps.bukti_transfer IS NULL OR ps.bukti_transfer='')
        ORDER BY ps.id_pesanan DESC
    ");

    $items = [];
    $total = 0;

    while($r = mysqli_fetch_assoc($q)){
        $items[] = $r;
        $total += $r['total_harga'];
    }

    echo json_encode([
        'items'   => $items,
        'total'   => $total,
        'lengkap' => $data_lengkap
    ]);
    exit;
}

/* ================= HAPUS ITEM ================= */
if(isset($_POST['aksi']) && $_POST['aksi']=='hapus'){
    mysqli_query($conn,"DELETE FROM pesanan WHERE id_pesanan='$_POST[id]'");
    exit;
}

/* ================= INVOICE ================= */
if(isset($_GET['aksi']) && $_GET['aksi']=='invoice'){

    if(!$data_lengkap){
        echo "<div style='color:red;text-align:center'>
            ⚠ Lengkapi data akun terlebih dahulu
        </div>";
        exit;
    }

    $kode = buatKodePesanan($conn);

    $q = mysqli_query($conn,"
        SELECT ps.*, pr.nama_produk
        FROM pesanan ps
        JOIN produk pr ON ps.id_produk=pr.id_produk
        WHERE ps.id_pembeli='$id_pembeli'
        AND ps.status='menunggu'
        AND (ps.bukti_transfer IS NULL OR ps.bukti_transfer='')
    ");

    $no=1;
    $total=0;

    echo "<b>Kode Pesanan:</b> $kode <br><br>";

    echo "
    <table width='100%' border='1' style='border-collapse:collapse;text-align:center'>
        <tr>
            <th>No</th>
            <th>Produk</th>
            <th>Qty</th>
            <th>Total</th>
        </tr>
    ";

    while($r=mysqli_fetch_assoc($q)){
        $total += $r['total_harga'];

        echo "
        <tr>
            <td>$no</td>
            <td>{$r['nama_produk']}</td>
            <td>{$r['jumlah']}</td>
            <td>Rp {$r['total_harga']}</td>
        </tr>";
        $no++;
    }

    echo "
        <tr>
            <td colspan='3'><b>Total</b></td>
            <td><b>Rp $total</b></td>
        </tr>
    </table>
    ";

    exit;
}

/* ================= UPLOAD BUKTI ================= */
if(isset($_POST['aksi']) && $_POST['aksi']=='upload'){

    if(!$data_lengkap) exit;

    $kode = buatKodePesanan($conn);

    $nama = time().'_'.$_FILES['bukti']['name'];
    move_uploaded_file($_FILES['bukti']['tmp_name'], "../uploads/$nama");

    $penjual_ids = [];
    $qPenjual = mysqli_query($conn,"
        SELECT DISTINCT id_penjual
        FROM pesanan
        WHERE id_pembeli='$id_pembeli'
        AND status='menunggu'
        AND (bukti_transfer IS NULL OR bukti_transfer='')
    ");
    while($r = mysqli_fetch_assoc($qPenjual)){
        $penjual_ids[] = (int) $r['id_penjual'];
    }

    mysqli_query($conn,"
        UPDATE pesanan
        SET
            kode_pesanan = '$kode',
            metode_pembayaran = 'transfer',
            bukti_transfer = '$nama'
        WHERE id_pembeli='$id_pembeli'
        AND status='menunggu'
        AND (bukti_transfer IS NULL OR bukti_transfer='')
    ");

    foreach($penjual_ids as $pid){
        if($pid > 0){
            kirimNotif('penjual', $pid, "Pesanan baru $kode dari pembeli @{$pembeli['username']}", 'approve.php');
        }
    }
    kirimNotif('pembeli', $id_pembeli, "Pesanan $kode berhasil dibuat, menunggu verifikasi penjual.", 'status.php');
    kirimNotifKeSuperadmin("Pesanan baru $kode dari pembeli @{$pembeli['username']}.");

    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<title>Keranjang</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins}
body{display:flex;background:#f5f6fa;height:100vh}

.sidebar{width:230px;background:#8d4545;color:#fff;padding:20px}
.profile{text-align:center;margin-bottom:20px}
.profile img{width:70px;height:70px;border-radius:50%}
.menu{list-style:none;padding:0;margin:0}
.menu li{list-style:none;margin:6px 0}
.menu li a{display:block;padding:12px;color:#fff;text-decoration:none}
.menu .active a{background:rgba(255,255,255,.3)}

main{flex:1;padding:25px}

.card{background:#fff;padding:15px;border-radius:10px;display:flex;gap:15px;margin-bottom:10px}
.card img{width:90px;height:90px;border-radius:8px}
.card button{background:#ef4444;color:#fff;border:none;padding:6px 10px}

.total{margin-top:10px;background:#e0f2ff;padding:12px;border-radius:8px}
.checkout{margin-top:10px;width:100%;padding:12px;background:#1e90ff;color:#fff;border:none;border-radius:8px}

.popup{position:fixed;inset:0;background:rgba(0,0,0,.6);display:none;justify-content:center;align-items:center}
.popup.show{display:flex}
.popup-box{background:#fff;width:450px;padding:20px;border-radius:10px}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>

<body>
<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="profile">
        <img src="../uploads/<?= $pembeli['foto']; ?>">
        <h3><?= $pembeli['username']; ?></h3>
    </div>
    <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>

    <ul class="menu">
        <li><a href="dashboard_pembeli.php">Dashboard</a></li>
                <li><a href="produk.php">Produk</a></li>
        <li><a href="pesanan.php">Pesanan</a></li>
        <li><a href="status.php">Status</a></li>
        <li><a href="chat.php">Chat</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="akun.php">My Account</a></li>
        <li><a href="help.php">Help</a></li>
        <li><a class="logout" href="../auth/logout.php">Sign Out</a></li>
    </ul>
</div>

<main>
    <div class="topbar-account">
        <div class="title">Profil</div>
        <div class="right">
            <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>
            <div class="user">
                <span><?= htmlspecialchars($pembeli['username']); ?></span>
                <img src="../uploads/<?= htmlspecialchars($pembeli['foto'] ?: 'default.png'); ?>" alt="Profil">
            </div>
        </div>
    </div>
    <h2>Keranjang Belanja</h2>

    <?php if(!$data_lengkap): ?>
    <div style="background:#fee2e2;padding:15px;border-radius:8px;color:#b91c1c;margin-bottom:15px">
        ⚠ Lengkapi data akun sebelum checkout
    </div>
    <?php endif; ?>

    <div id="keranjang"></div>
    <div class="total" id="total"></div>

    <button class="checkout" onclick="openInvoice()">Checkout</button>
</main>

<div class="popup" id="popup">
    <div class="popup-box">
        <h3>Invoice</h3>
        <div id="invoice"></div>
        <input type="file" id="bukti">
        <button class="checkout" onclick="uploadBukti()">Upload Bukti</button>
        <button onclick="closeInvoice()">Tutup</button>
    </div>
</div>

<script>
function loadKeranjang(){
    fetch('keranjang.php?aksi=load')
    .then(r=>r.json())
    .then(d=>{
        let html='';
        d.items.forEach(i=>{
            html+=`
            <div class="card">
                <img src="../uploads/${i.foto}">
                <div style="flex:1">
                    <b>${i.nama_produk}</b><br>
                    ${i.nama_penjual}<br>
                    Rp ${i.total_harga}
                </div>
                <button onclick="hapus(${i.id_pesanan})">Hapus</button>
            </div>`;
        });

        document.getElementById('keranjang').innerHTML=html;
        document.getElementById('total').innerHTML='Total : Rp '+d.total;
    });
}

function openInvoice(){
    document.getElementById('popup').classList.add('show');
    fetch('keranjang.php?aksi=invoice')
    .then(r=>r.text())
    .then(t=>document.getElementById('invoice').innerHTML=t);
}

function closeInvoice(){
    document.getElementById('popup').classList.remove('show');
}

function hapus(id){
    fetch('keranjang.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'aksi=hapus&id='+id
    }).then(()=>loadKeranjang());
}

function uploadBukti(){
    let f=document.getElementById('bukti').files[0];
    let fd=new FormData();
    fd.append('aksi','upload');
    fd.append('bukti',f);

    fetch('keranjang.php',{method:'POST',body:fd})
    .then(()=>{
        alert('Pesanan berhasil dikirim');
        closeInvoice();
        loadKeranjang();
    });
}

loadKeranjang();
setInterval(loadKeranjang,3000);
</script>

</body>
</html>










