<?php
session_start();

include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if(!isset($_SESSION['username'])){
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];

/* ===== DATA PEMBELI ===== */
$pembeli = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT * FROM pembeli WHERE username='$username'")
);

$id_pembeli = $pembeli['id_pembeli'];

/* ===== DATA ===== */
$produk = mysqli_query($conn,"SELECT * FROM produk ORDER BY id_produk DESC LIMIT 8");
$kategori = mysqli_query($conn,"SELECT * FROM kategori");

?>
<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<title>Dashboard Pembeli</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}

*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins}
body{background:#f4f6fb;display:flex}

/* Notifikasi (hitam di atas putih) */
.notif-widget{
    --notif-accent: #111111;
    --notif-accent-2: #111111;
    --notif-bg: #ffffff;
    --notif-text: #111111;
    --notif-muted: #5f5f5f;
    --notif-new: #f7f7f7;
    --notif-border: #e5e7eb;
}
.sidebar .notif-widget,
.sidebar .notif-widget *{
    color:#111111 !important;
}
.sidebar .notif-widget .notif-list{
    background:#ffffff !important;
    border-color:#e5e7eb !important;
}

/* ===== SIDEBAR ===== */
.sidebar{
    width:260px;
    background:brown;
    color:#fff;
    min-height:100vh;
    padding:20px;
    position:fixed;
}
.profile{text-align:center;margin-bottom:25px}
.profile img{
    width:80px;height:80px;border-radius:50%;
    border:3px solid #fff;object-fit:cover
}
.profile h3{margin-top:10px;font-size:17px}

.menu li{list-style:none;margin:8px 0}
.menu a{
    color:#fff;text-decoration:none;
    display:block;padding:10px 15px;
    border-radius:8px;
}
.menu a:hover{background:#334155}

.logout{background:#ef4444;margin-top:20px}

/* ===== MAIN ===== */
main{
    margin-left:260px;
    padding:25px;
    width:100%;
}

/* ===== HEADER ===== */
header{
    background:#fff;
    padding:15px 20px;
    border-radius:10px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}
.search input{
    padding:8px 15px;
    border-radius:25px;
    border:1px solid #ddd;
    width:250px;
}
.notif{
    position:relative;
    cursor:pointer;
    color:#111;
}
.notif .badge{
    position:absolute;
    top:-6px;right:-6px;
    background:#ef4444;color:#fff;
    font-size:11px;
    padding:2px 6px;border-radius:50%;
}
.notif-box{
    display:none;
    position:absolute;
    right:0;top:28px;
    background:#fff;
    border:1px solid #eee;
    width:260px;
    border-radius:10px;
    box-shadow:0 6px 16px rgba(0,0,0,.08);
    padding:8px;
    z-index:10;
    color:#111;
}
.notif-box,
.notif-box *{color:#111 !important;}
.notif-item{
    padding:8px;
    border-bottom:1px solid #f1f5f9;
    font-size:13px;
    color:#111;
}
.notif-item:last-child{border-bottom:none}
.notif-item.new{background:#fff !important;}

/* ===== BANNER ===== */
.banner{
    background:linear-gradient(135deg,#8d4545,#6b2f2f);
    color:#fff;
    padding:30px;
    border-radius:15px;
    margin-bottom:25px;
}
.banner h1{font-size:30px}

/* ===== PRODUK ===== */
.produk-grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
    gap:20px;
}
.produk{
    background:#fff;
    border-radius:12px;
    padding:15px;
    text-align:center;
    box-shadow:0 4px 10px rgba(0,0,0,.06);
}
.produk img{
    width:100%;
    height:160px;
    object-fit:cover;
    border-radius:10px;
}
.produk h4{margin:8px 0}

/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="profile">
        <img src="../uploads/<?= $pembeli['foto']; ?>">
        <h3><?= $pembeli['username']; ?></h3>
    </div>
    <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>

    <ul class="menu">
            <li><a href="dashboard_pembeli.php">Dashboard</a></li>
             <li><a href="produk.php">Produk</a></li>
            <li><a href="pesanan.php">Pesanan</a></li>
            <li><a href="status.php">Status</a></li>
            <li><a href="chat.php">Chat</a></li>
            <li><a href="laporan.php">Laporan</a></li>
            <li><a href="akun.php">My Account</a></li>
            <li><a href="help.php">Help</a></li>
            <li><a class="logout" href="../auth/logout.php">Sign Out</a></li>
    </ul>
</div>

<!-- MAIN -->
<main>
<header>
    <div class="search">
        <input type="text" placeholder="Cari buku...">
    </div>
    <div class="right" style="display:flex;align-items:center;gap:12px;">
        <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>
        <div class="user" style="display:flex;align-items:center;gap:10px;">
            <span><?= htmlspecialchars($pembeli['username']); ?></span>
            <img src="../uploads/<?= htmlspecialchars($pembeli['foto'] ?: 'default.png'); ?>" alt="Profil" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
        </div>
    </div>
</header>

<div class="banner">
    <h1>Selamat Datang, <?= $pembeli['username']; ?> 👋</h1>
    <p>Temukan buku favoritmu hari ini</p>
</div>

<h3>Produk Terbaru</h3>
<br>

<div class="produk-grid">
<?php while($p=mysqli_fetch_assoc($produk)): ?>
    <div class="produk">
        <img src="../uploads/<?= $p['foto']; ?>">
        <h4><?= $p['nama_produk']; ?></h4>
        <p>Rp <?= number_format($p['harga']); ?></p>
    </div>
<?php endwhile; ?>
</div>

</main>

</body>
</html>









