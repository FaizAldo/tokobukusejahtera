<?php
session_start();
include "../conn/koneksi.php";
include "../notifikasi/notif_system.php";
include "../notifikasi/widget.php";
include "../notifikasi/notif_system.php";

/* ================= CEK LOGIN PEMBELI ================= */
if(!isset($_SESSION['username'])){
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];
$pembeli = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM pembeli WHERE username='$username'"));
if(!$pembeli){
    header("Location: ../auth/login_users.php");
    exit;
}

$id_pembeli = $pembeli['id_pembeli'];

/* ================= DAFTAR PENJUAL ================= */
$penjual_q = mysqli_query($conn,"SELECT * FROM penjual ORDER BY username ASC");

/* ================= CHAT AJAX ================= */
if(isset($_GET['aksi'])){

    $partner = intval($_GET['id'] ?? 0);
    if($partner <= 0){
        exit("ID penjual tidak valid");
    }

    // LOAD CHAT
    if($_GET['aksi']=='load'){
        $partner_row = mysqli_fetch_assoc(mysqli_query($conn,"SELECT nama_penjual, username FROM penjual WHERE id_penjual='$partner'"));
        $partner_name = $partner_row['nama_penjual'] ?: ($partner_row['username'] ?? 'Penjual');
        $q = mysqli_query($conn,"SELECT * FROM messages 
            WHERE penjual_id='$partner' AND pembeli_id='$id_pembeli'
            ORDER BY id_message ASC");

        $last_date = '';
        while($m=mysqli_fetch_assoc($q)){
            $msg_date = date('Y-m-d', strtotime($m['created_at']));
            if ($msg_date !== $last_date) {
                $today = date('Y-m-d');
                $yesterday = date('Y-m-d', strtotime('-1 day'));
                if ($msg_date === $today) {
                    $label_day = 'Hari Ini';
                } elseif ($msg_date === $yesterday) {
                    $label_day = 'Kemarin';
                } else {
                    $label_day = date('d M Y', strtotime($msg_date));
                }
                echo "<div class='day-sep' data-date='".htmlspecialchars($msg_date)."'><span>".htmlspecialchars($label_day)."</span></div>";
                $last_date = $msg_date;
            }
            $me = ($m['sender']=='pembeli') ? 'me' : 'you';
            $label = ($m['sender']=='pembeli') ? 'Anda' : $partner_name;
            $time = date('H:i', strtotime($m['created_at']));
            echo "<div class='msg $me'>
                    <div class='msg-label'>".htmlspecialchars($label)."</div>
                    <div class='bubble'>".htmlspecialchars($m['message'])."</div>
                    <div class='msg-time'>".htmlspecialchars($time)."</div>
                  </div>";
        }

        // tandai pesan penjual sudah dibaca
        mysqli_query($conn,"UPDATE messages SET is_read=1 
            WHERE penjual_id='$partner' AND pembeli_id='$id_pembeli' AND sender='penjual'");
        exit;
    }

    // SEND CHAT
    if($_GET['aksi']=='send'){
        $msg = trim($_POST['msg']);
        if($msg != ''){
            mysqli_query($conn,"INSERT INTO messages
                (penjual_id,pembeli_id,sender,message,created_at)
                VALUES
                ('$partner','$id_pembeli','pembeli','$msg',NOW())");
            kirimNotif('penjual', $partner, "Pesan baru dari pembeli @{$pembeli['username']}", 'chat.php');
        }
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<title>Chat Pembeli</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
body{font-family:Arial; background:#f4f6f9; margin:0; padding:0;}
.chat-layout{display:flex; gap:20px; padding:20px; align-items:flex-start;}
.chat-sidebar{
    width:280px; background:#fff; border-radius:12px; padding:16px;
    box-shadow:0 5px 15px rgba(0,0,0,.08); position:sticky; top:20px;
}
.chat-sidebar h2{margin:12px 0 8px;font-size:18px;}
.chat-list{display:flex; flex-direction:column; gap:10px; max-height:70vh; overflow:auto; padding-right:4px;}
.card{background:#fff; padding:12px; border-radius:10px; display:flex; justify-content:space-between; align-items:center; border:1px solid #eee;}
.card.active{border-color:#8d4545; box-shadow:0 2px 8px rgba(141,69,69,.15);}
.card-text{display:flex;flex-direction:column;gap:2px;}
.card-name{font-weight:600;font-size:14px;color:#111;}
.card-sub{font-size:12px;color:#6b7280;}
.card a{text-decoration:none; color:#1e90ff; font-weight:bold;}
.chat-main{flex:1; min-width:0;}
.chat-box{
    width:100%; height:85vh; background:#fff;
    border-radius:14px; display:flex; flex-direction:column; box-shadow:0 15px 40px rgba(0,0,0,.12);
}
.header{padding:12px; border-bottom:1px solid #eee; display:flex; gap:10px; font-weight:bold;}
.back{text-decoration:none; font-size:18px; color:#333;}
.messages{flex:1; padding:12px; overflow:auto; background:#f9fafb;}
.msg{margin:6px 0;}
.msg.me{text-align:right;}
.bubble{display:inline-block; padding:8px 12px; border-radius:16px; max-width:75%; font-size:14px;}
.msg-label{font-size:11px;color:#6b7280;margin:2px 6px;}
.msg.me .msg-label{text-align:right;}
.msg-time{font-size:10px;color:#9ca3af;margin:2px 6px;}
.msg.me .msg-time{text-align:right;}
.day-sep{
    text-align:center; margin:10px 0; color:#6b7280; font-size:12px;
}
.day-sep span{
    background:#f1f5f9; padding:4px 10px; border-radius:999px; display:inline-block;
}
.me .bubble{background:#DCF8C6;}
.you .bubble{background:#fff;border:1px solid #eee;}
.input{display:flex; gap:8px; padding:10px; border-top:1px solid #eee;}
textarea{flex:1; height:45px; border-radius:12px; border:1px solid #ccc; padding:8px; resize:none;}
button{width:55px; border:none; border-radius:12px; background:#1e90ff; color:#fff; font-size:18px;}
.empty-state{
    height:85vh; background:#fff; border-radius:14px; display:flex; align-items:center; justify-content:center;
    color:#6b7280; font-size:14px; box-shadow:0 15px 40px rgba(0,0,0,.12);
}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<div class="chat-layout">
    <div class="chat-sidebar">
    <div class="topbar-account">
        <div class="title">Akun</div>
        <div class="right">
            <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>
            <div class="user">
                <span><?= htmlspecialchars($pembeli['username']); ?></span>
                <img src="../uploads/<?= htmlspecialchars($pembeli['foto'] ?: 'default.png'); ?>" alt="Profil">
            </div>
        </div>
    </div>
    <h2>Daftar Penjual</h2>
    <?php $current = isset($_GET['chat']) ? intval($_GET['chat']) : 0; ?>
    <?php while($p=mysqli_fetch_assoc($penjual_q)): ?>
                <div class="card <?= ($current === (int)$p['id_penjual']) ? 'active' : '' ?>">
                    <div class="card-text">
                        <div class="card-name"><?= htmlspecialchars($p['nama_penjual'] ?: $p['username']) ?></div>
                        <div class="card-sub">@<?= htmlspecialchars($p['username']) ?></div>
                    </div>
                    <a href="?chat=<?= $p['id_penjual'] ?>">Buka</a>
                </div>
    <?php endwhile; ?>
</div>
    <div class="chat-main">
<?php if(isset($_GET['chat'])): 
$partner = intval($_GET['chat']);
if($partner>0): ?>
<div class="chat-box">
    <div class="header">
        <a href="chat.php" class="back">⬅</a>
        Chat Penjual
    </div>
    <div class="messages" id="messages"></div>
    <div class="input">
        <textarea id="text" placeholder="Tulis pesan..."></textarea>
        <button id="send">➤</button>
    </div>
</div>

<script>
let partner = <?= $partner ?>;

function loadChat(){
    $("#messages").load("chat.php?aksi=load&id="+partner, function(){
        $("#messages").scrollTop($("#messages")[0].scrollHeight);
    });
}

$("#send").click(function(){
    let msg=$("#text").val();
    if(msg.trim()=="") return;
    $("#text").val("");
    // tampilkan langsung (optimistic UI)
    const now = new Date();
    const time = now.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
    const today = now.toISOString().slice(0,10);
    const lastSep = $("#messages .day-sep").last().data("date");
    if(lastSep !== today){
        $("#messages").append("<div class='day-sep' data-date='"+today+"'><span>Hari Ini</span></div>");
    }
    $("#messages").append(
        "<div class='msg me'>"+
        "<div class='msg-label'>Anda</div>"+
        "<div class='bubble'>"+$('<div>').text(msg).html()+"</div>"+
        "<div class='msg-time'>"+time+"</div>"+
        "</div>"
    );
    $("#messages").scrollTop($("#messages")[0].scrollHeight);
    $.post("chat.php?aksi=send&id="+partner,{msg:msg},function(){
    });
});

loadChat();
</script>
<?php endif; endif; ?>
<?php if(!isset($_GET['chat'])): ?>
<div class="empty-state">Pilih penjual di kiri untuk mulai chat.</div>
<?php endif; ?>
    </div>
</div>

</body>
</html>







