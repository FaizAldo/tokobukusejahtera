<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];

/* ============ UPLOAD CONFIG ============ */
$upload_base = __DIR__ . "/../uploads";
$upload_dir  = $upload_base; // pembeli pakai folder uploads root

if (!is_dir($upload_dir)) {
    if (!mkdir($upload_dir, 0755, true) && !is_dir($upload_dir)) {
        error_log("Gagal membuat folder upload: $upload_dir");
    }
}

/* ============ HELPERS ============ */
function esc($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

function save_uploaded_foto_pembeli(array $file, string $upload_dir, int $maxSize = 5*1024*1024) {
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];
    if (empty($file) || !isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) return '';
    if ($file['error'] !== UPLOAD_ERR_OK) return '';
    if ($file['size'] > $maxSize) return '';

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!isset($allowed[$mime])) return '';

    $ext = $allowed[$mime];
    $hash = hash_file('sha256', $file['tmp_name']);
    if ($hash === false) return '';

    $name = $hash . '.' . $ext;
    $target = rtrim($upload_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $name;

    if (!file_exists($target)) {
        if (!move_uploaded_file($file['tmp_name'], $target)) return '';
        @chmod($target, 0644);
    }

    return $name; // disimpan sebagai filename di kolom foto
}

/* ============ AMBIL DATA PEMBELI ============ */
$stm = $conn->prepare("SELECT * FROM pembeli WHERE username = ? LIMIT 1");
$stm->bind_param("s", $username);
$stm->execute();
$pembeli = $stm->get_result()->fetch_assoc();
$stm->close();

if (!$pembeli) {
    session_destroy();
    header("Location: ../auth/login_users.php");
    exit;
}

$id_pembeli = (int) $pembeli['id_pembeli'];

/* ============ HANDLE AJAX/POST ============ */
/*
 Expected POST actions:
 - update_profile: update nik, email, no_hp, alamat + foto (file)
 - change_password: old_password, new_password, confirm_password
 Responses: JSON { success:bool, message:string }
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    if (isset($_POST['update_profile'])) {
        $nik    = trim($_POST['nik'] ?? '');
        $email  = trim($_POST['email'] ?? '');
        $no_hp  = trim($_POST['no_hp'] ?? '');
        $alamat = trim($_POST['alamat'] ?? '');

        $foto_baru = '';
        if (!empty($_FILES['foto']['name'])) {
            $foto_baru = save_uploaded_foto_pembeli($_FILES['foto'], $upload_dir);
        }

        if ($foto_baru !== '') {
            $stmt = $conn->prepare("UPDATE pembeli SET nik=?, email=?, no_hp=?, alamat=?, foto=? WHERE id_pembeli=?");
            $stmt->bind_param("sssssi", $nik, $email, $no_hp, $alamat, $foto_baru, $id_pembeli);
        } else {
            $stmt = $conn->prepare("UPDATE pembeli SET nik=?, email=?, no_hp=?, alamat=? WHERE id_pembeli=?");
            $stmt->bind_param("ssssi", $nik, $email, $no_hp, $alamat, $id_pembeli);
        }

        $ok = $stmt->execute();
        $err = $stmt->error;
        $stmt->close();

        if ($foto_baru !== '') {
            $old = $pembeli['foto'] ?? '';
            if ($old && $old !== 'default.png' && $old !== $foto_baru) {
                $s = $conn->prepare("SELECT COUNT(*) AS cnt FROM pembeli WHERE foto = ?");
                $s->bind_param("s", $old);
                $s->execute();
                $cnt = $s->get_result()->fetch_assoc()['cnt'] ?? 0;
                $s->close();
                if ((int)$cnt <= 0) {
                    $old_path = $upload_base . '/' . $old;
                    if (file_exists($old_path)) @unlink($old_path);
                }
            }
        }

        if ($ok) {
            $stm = $conn->prepare("SELECT * FROM pembeli WHERE id_pembeli = ? LIMIT 1");
            $stm->bind_param("i", $id_pembeli);
            $stm->execute();
            $pembeli = $stm->get_result()->fetch_assoc();
            $stm->close();
            echo json_encode(['success' => true, 'message' => 'Profil berhasil diperbarui']);
            exit;
        } else {
            echo json_encode(['success' => false, 'message' => 'Update gagal: ' . $err]);
            exit;
        }
    }

    if (isset($_POST['change_password'])) {
        $old = $_POST['old_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $conf = $_POST['confirm_password'] ?? '';

        if ($new === '' || strlen($new) < 6) {
            echo json_encode(['success' => false, 'message' => 'Password baru minimal 6 karakter']);
            exit;
        }
        if ($new !== $conf) {
            echo json_encode(['success' => false, 'message' => 'Konfirmasi password tidak cocok']);
            exit;
        }

        $hash = $pembeli['password'] ?? '';
        if (!password_verify($old, $hash)) {
            echo json_encode(['success' => false, 'message' => 'Password lama salah']);
            exit;
        }

        $new_hash = password_hash($new, PASSWORD_DEFAULT);
        $s = $conn->prepare("UPDATE pembeli SET password = ? WHERE id_pembeli = ?");
        $s->bind_param("si", $new_hash, $id_pembeli);
        $ok = $s->execute();
        $err = $s->error;
        $s->close();

        if ($ok) {
            echo json_encode(['success' => true, 'message' => 'Password berhasil diubah']);
            exit;
        } else {
            echo json_encode(['success' => false, 'message' => 'Gagal mengubah password: ' . $err]);
            exit;
        }
    }

    echo json_encode(['success' => false, 'message' => 'Aksi tidak dikenal']);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="utf-8">
<title>My Account</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins}
body{background:#f4f6fb;display:flex}

/* Notifikasi (hitam di atas putih) */
.notif-widget{
    --notif-accent: #111111;
    --notif-accent-2: #111111;
    --notif-bg: #ffffff;
    --notif-text: #111111;
    --notif-muted: #5f5f5f;
    --notif-new: #f7f7f7;
    --notif-border: #e5e7eb;
}
.sidebar .notif-widget,
.sidebar .notif-widget *{
    color:#111111 !important;
}
.sidebar .notif-widget .notif-list{
    background:#ffffff !important;
    border-color:#e5e7eb !important;
}

/* SIDEBAR */
.sidebar{
    width:260px;
    background:brown;
    color:#fff;
    min-height:100vh;
    padding:20px;
    position:fixed;
}
.profile{text-align:center;margin-bottom:25px}
.profile img{width:80px;height:80px;border-radius:50%;border:3px solid #fff;object-fit:cover}
.profile h3{margin-top:10px;font-size:17px}

.menu li{list-style:none;margin:8px 0}
.menu a{
    color:#fff;text-decoration:none;
    display:block;padding:10px 15px;
    border-radius:8px;
}
.menu a:hover{background:#334155}
.menu a.active{background:#334155;font-weight:700}
.logout{background:#ef4444;margin-top:20px}

/* MAIN */
main{margin-left:260px;padding:25px;width:100%}

.card{background:#fff;padding:18px;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,.06);margin-bottom:18px;max-width:980px}
.header-row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}
.back-btn{background:#e0e0e0;color:#333;border:none;padding:8px 12px;border-radius:8px;cursor:pointer}

.row{display:flex;gap:20px;align-items:flex-start}
.col{flex:1}
.profile-pic{width:150px;height:150px;border-radius:10px;object-fit:cover;border:1px solid #ddd}
.notice{
    display:none;
    padding:10px 12px;
    border-radius:8px;
    margin-top:12px;
    font-size:14px;
}
.notice.success{display:block;background:#e7f6ec;color:#166534;border:1px solid #b7e4c7;}
.notice.error{display:block;background:#fee2e2;color:#991b1b;border:1px solid #fecaca;}
.form-group{margin:10px 0}
label{display:block;font-weight:600;margin-bottom:6px}
input[type=text],input[type=email],textarea,input[type=password]{width:100%;padding:10px;border-radius:8px;border:1px solid #ccc}
button.primary{background:#1e90ff;color:#fff;border:none;padding:10px 14px;border-radius:8px;cursor:pointer}
.small{font-size:13px;color:#666}
.success{color:green}
.error{color:#c00}

@media(max-width:900px){
    main{margin-left:0;padding:12px}
    .row{flex-direction:column}
}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="profile">
        <img src="../uploads/<?= $pembeli['foto']; ?>" alt="avatar">
        <h3><?= $pembeli['username']; ?></h3>
    </div>
    <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>

    <ul class="menu">
        <li><a href="dashboard_pembeli.php">Dashboard</a></li>
                <li><a href="produk.php">Produk</a></li>
        <li><a href="pesanan.php">Pesanan</a></li>
        <li><a href="status.php">Status</a></li>
        <li><a href="chat.php">Chat</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="akun.php" class="active">My Account</a></li>
        <li><a href="help.php">Help</a></li>
        <li><a class="logout" href="../auth/logout.php">Sign Out</a></li>
    </ul>
</div>

<!-- MAIN -->
<main>
    <?php
    $foto_path = $pembeli['foto'] ? ('../uploads/' . preg_replace('#^(?:\./)?uploads/#', '', $pembeli['foto'])) : '../uploads/default.png';
    ?>
    <div class="topbar-account">
        <div class="title">Profil</div>
        <div class="right">
            <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>
            <div class="user">
                <span><?= esc($pembeli['username']) ?></span>
                <img src="<?= esc($foto_path) ?>" alt="Profil">
            </div>
        </div>
    </div>
    <div class="card">
        <div class="header-row">
            <h2>My Account</h2>
            <button type="button" class="back-btn" onclick="window.history.back()">Kembali</button>
        </div>

        <div class="row">
            <div class="col" style="max-width:190px">
                <img src="<?= esc($foto_path) ?>" alt="Foto" class="profile-pic" id="profilePic">
                <p class="small">Foto saat ini</p>
            </div>

            <div class="col">
                <form id="profileForm" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>NIK</label>
                        <input type="text" name="nik" value="<?= esc($pembeli['nik'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" value="<?= esc($pembeli['username']) ?>" disabled>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value="<?= esc($pembeli['email'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label>No. HP</label>
                        <input type="text" name="no_hp" value="<?= esc($pembeli['no_hp'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label>Alamat</label>
                        <textarea name="alamat" rows="3"><?= esc($pembeli['alamat'] ?? '') ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>Ganti Foto (opsional)</label>
                        <input type="file" name="foto" accept="image/*" id="fotoInput">
                    </div>

                    <div class="form-group">
                        <button type="submit" class="primary" id="saveProfileBtn">Simpan Perubahan</button>
                        <div id="profileMsg" class="notice"></div>
                    </div>

                    <input type="hidden" name="update_profile" value="1">
                </form>
            </div>
        </div>
    </div>

    <div class="card">
        <h3>Ganti Password</h3>
        <form id="pwForm">
            <div class="form-group">
                <label>Password Lama</label>
                <input type="password" name="old_password" required>
            </div>
            <div class="form-group">
                <label>Password Baru</label>
                <input type="password" name="new_password" required>
            </div>
            <div class="form-group">
                <label>Konfirmasi Password Baru</label>
                <input type="password" name="confirm_password" required>
            </div>
            <div class="form-group">
                <button type="submit" class="primary">Ubah Password</button>
                <span id="pwMsg" class="small"></span>
            </div>
            <input type="hidden" name="change_password" value="1">
        </form>
    </div>
</main>

<script>
(function(){
    var fotoInput = document.getElementById('fotoInput');
    var profilePic = document.getElementById('profilePic');
    if (fotoInput) {
        fotoInput.addEventListener('change', function(){
            var f = this.files[0];
            if (!f) return;
            var url = URL.createObjectURL(f);
            profilePic.src = url;
        });
    }

    var profileForm = document.getElementById('profileForm');
    profileForm.addEventListener('submit', function(e){
        e.preventDefault();
        var btn = document.getElementById('saveProfileBtn');
        var status = document.getElementById('profileMsg');
        status.textContent = '';
        btn.disabled = true;
        btn.textContent = 'Menyimpan...';

        fetch('akun.php', {
            method: 'POST',
            body: new FormData(profileForm)
        }).then(function(res){
            return res.json();
        }).then(function(res){
            if (res.success) {
                status.className = 'small success';
                status.textContent = res.message;
                setTimeout(function(){ location.reload(); }, 800);
            } else {
                status.className = 'small error';
                status.textContent = res.message || 'Update gagal.';
            }
        }).catch(function(){
            status.className = 'small error';
            status.textContent = 'Permintaan gagal. Coba lagi.';
        }).finally(function(){
            btn.disabled = false;
            btn.textContent = 'Simpan Perubahan';
        });
    });

    var pwForm = document.getElementById('pwForm');
    pwForm.addEventListener('submit', function(e){
        e.preventDefault();
        var status = document.getElementById('pwMsg');
        status.textContent = '';

        fetch('akun.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams(new FormData(pwForm)).toString()
        }).then(function(res){
            return res.json();
        }).then(function(res){
            if (res.success) {
                status.className = 'small success';
                status.textContent = res.message;
                pwForm.reset();
            } else {
                status.className = 'small error';
                status.textContent = res.message || 'Gagal mengubah password.';
            }
        }).catch(function(){
            status.className = 'small error';
            status.textContent = 'Permintaan gagal. Coba lagi.';
        });
    });
})();
</script>

</body>
</html>










