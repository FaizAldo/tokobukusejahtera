<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];
$stmtp = $conn->prepare("SELECT * FROM pembeli WHERE username = ? LIMIT 1");
$stmtp->bind_param("s", $username);
$stmtp->execute();
$pembeli = $stmtp->get_result()->fetch_assoc();
$stmtp->close();

if (!$pembeli) {
    session_destroy();
    header("Location: ../auth/login_users.php");
    exit;
}

function esc($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<script src="../assets/responsive.js" defer></script>
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Profil Pembeli</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins}
body{background:#f4f6fb;display:flex}
.sidebar{
    width:260px;
    background:brown;
    color:#fff;
    min-height:100vh;
    padding:20px;
    position:fixed;
}
.profile{text-align:center;margin-bottom:25px}
.profile img{width:80px;height:80px;border-radius:50%;border:3px solid #fff;object-fit:cover}
.profile h3{margin-top:10px;font-size:17px}
.menu li{list-style:none;margin:8px 0}
.menu a{
    color:#fff;text-decoration:none;
    display:block;padding:10px 15px;
    border-radius:8px;
}
.menu a:hover{background:#334155}
.menu a.active{background:#334155;font-weight:700}
.logout{background:#ef4444;margin-top:20px}
main{margin-left:260px;padding:25px;width:100%}
.card{
    background:#fff;border-radius:12px;padding:20px;
    box-shadow:0 4px 10px rgba(0,0,0,.06);max-width:900px;
}
.row{display:flex;gap:20px;align-items:center;flex-wrap:wrap}
.photo{width:120px;height:120px;border-radius:12px;object-fit:cover;border:1px solid #e5e7eb}
.meta h3{margin:0 0 6px}
.meta p{margin:0 0 6px;color:#555}
@media(max-width:900px){
    main{margin-left:0;padding:12px}
}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
        <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
        <div class="store-name">TOKO BUKU SEJAHTERA</div>
    </div>
    <div class="profile">
        <img src="../uploads/<?= esc($pembeli['foto'] ?: 'default.png'); ?>" alt="avatar">
        <h3><?= esc($pembeli['username']); ?></h3>
    </div>
    <?php renderNotifWidget('pembeli', (int)$pembeli['id_pembeli']); ?>

    <ul class="menu">
        <li><a href="dashboard_pembeli.php">Dashboard</a></li>
        <li><a href="produk.php">Produk</a></li>
        <li><a href="pesanan.php">Pesanan</a></li>
        <li><a href="status.php">Status</a></li>
        <li><a href="chat.php">Chat</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="akun.php">My Account</a></li>
        <li><a href="help.php">Help</a></li>
        <li><a class="logout" href="../auth/logout.php">Sign Out</a></li>
    </ul>
</div>

<!-- MAIN -->
<main>
    <div class="topbar-account">
        <div class="title">Profil Pembeli</div>
        <div class="right" style="display:flex;align-items:center;gap:12px;margin-left:auto;">
            <?php renderNotifWidget('pembeli', (int)$pembeli['id_pembeli']); ?>
            <div class="user" style="display:flex;align-items:center;gap:10px;">
                <span><?= esc($pembeli['username']); ?></span>
                <img src="../uploads/<?= esc($pembeli['foto'] ?: 'default.png'); ?>" alt="Profil" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
            </div>
        </div>
    </div>

    <div class="card">
        <div class="row">
            <img class="photo" src="../uploads/<?= esc($pembeli['foto'] ?: 'default.png'); ?>" alt="Foto">
            <div class="meta">
                <h3><?= esc($pembeli['username']); ?></h3>
                <p><strong>NIK:</strong> <?= esc($pembeli['nik'] ?? '') ?></p>
                <p><strong>Email:</strong> <?= esc($pembeli['email'] ?? '') ?></p>
                <p><strong>No HP:</strong> <?= esc($pembeli['no_hp'] ?? '') ?></p>
                <p><strong>Alamat:</strong> <?= esc($pembeli['alamat'] ?? '') ?></p>
                <a class="btn" style="background:#8d4545;color:#fff;border:none;border-radius:8px;padding:8px 14px;display:inline-block;text-decoration:none" href="akun.php">Edit Profil</a>
            </div>
        </div>
    </div>
</main>

</body>
</html>
