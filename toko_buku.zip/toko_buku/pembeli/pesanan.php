<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

// ================= CEK LOGIN =================
if(!isset($_SESSION['username'])){
    header("Location: ../auth/login_users.php");
    exit;
}

// Ambil data pembeli
$username = $_SESSION['username'];
$pembeli = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pembeli WHERE username='$username'"));
$pembeli_id = $pembeli['id_pembeli'] ?? 0;

// ================= PROSES PEMESANAN =================
if(isset($_POST['produk_id'], $_POST['jumlah'])){
    $produk_id = (int)$_POST['produk_id'];
    $jumlah = (int)$_POST['jumlah'];

    // Ambil data produk
    $produk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM produk WHERE id_produk='$produk_id' AND status='aktif'"));

    if($produk){
        $id_penjual = $produk['penjual_id'];
        $harga = (int)$produk['harga'];
        $total_harga = $harga * $jumlah;
        $status = 'menunggu'; // harus sama persis dengan ENUM di database
        $kode_pesanan = 'PSN'.date('YmdHis').rand(10,99); // generate kode unik

        // Insert ke tabel pesanan
        $stmt = $conn->prepare("
            INSERT INTO pesanan 
            (id_pembeli, id_produk, id_penjual, kode_pesanan, jumlah, harga, total_harga, status, tanggal)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param(
            "iiiisiss",  // i=int, s=string
            $pembeli_id,
            $produk_id,
            $id_penjual,
            $kode_pesanan,
            $jumlah,
            $harga,
            $total_harga,
            $status
        );

        if($stmt->execute()){
            // Kurangi stok produk
            $new_stok = $produk['stok'] - $jumlah;
            if($new_stok < 0) $new_stok = 0;
            mysqli_query($conn, "UPDATE produk SET stok='$new_stok' WHERE id_produk='$produk_id'");

            // Redirect ke keranjang setelah berhasil pesan
            header("Location: keranjang.php");
            exit;
        }else{
            $pesan_sukses = "Gagal membuat pesanan: ".mysqli_error($conn);
        }
    }else{
        $pesan_sukses = "Produk tidak tersedia atau stok habis.";
    }
}

// ================= AMBIL PRODUK YANG DIPILIH =================
$produk_id = (int)($_GET['produk'] ?? 0);
$produk = null;
if ($produk_id > 0) {
    $produk = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT p.*, pen.nama_penjual 
        FROM produk p
        JOIN penjual pen ON p.penjual_id = pen.id_penjual
        WHERE p.id_produk='$produk_id' AND p.status='aktif'
        LIMIT 1
    "));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<script src="../assets/responsive.js" defer></script>
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pesanan</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
body{margin:0;font-family:'Poppins',sans-serif;background:#f5f6fa;color:#333;}
*{box-sizing:border-box;}
a{text-decoration:none;color:inherit;}

/* Notifikasi (hitam di atas putih) */
.notif-widget{
    --notif-accent: #111111;
    --notif-accent-2: #111111;
    --notif-bg: #ffffff;
    --notif-text: #111111;
    --notif-muted: #5f5f5f;
    --notif-new: #f7f7f7;
    --notif-border: #e5e7eb;
}
.sidebar .notif-widget,
.sidebar .notif-widget *{
    color:#111111 !important;
}
.sidebar .notif-widget .notif-list{
    background:#ffffff !important;
    border-color:#e5e7eb !important;
}

.sidebar{width:260px;height:100vh;background:linear-gradient(180deg,#8d4545,#6b2f2f);position:fixed;left:0;top:0;color:#fff;padding:20px;overflow-y:auto;}
.sidebar .profile{text-align:center;margin-bottom:25px;}
.sidebar .profile img{width:75px;height:75px;border-radius:50%;border:3px solid #fff;object-fit:cover;}
.sidebar .profile h3{margin:8px 0 0;font-size:17px;}
.sidebar .menu{list-style:none;padding:0;margin:0;}
.sidebar .menu li{margin:6px 0;list-style:none;}
.sidebar .menu li a{display:block;padding:11px 14px;border-radius:8px;color:#fff;transition:0.25s;}
.sidebar .menu li a:hover{background:rgba(255,255,255,0.2);}
.sidebar .menu li a.active{background:rgba(255,255,255,0.3);font-weight:700;}
.sidebar .menu li.logout a{background:#ef4444;}
main{margin-left:260px;padding:20px 25px;}
header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;}
header input{padding:7px 15px;border-radius:25px;border:none;width:300px;transition:0.3s;}
header input:focus{outline:none;box-shadow:0 0 8px rgba(30,144,255,0.5);}

.detail-card{background:#fff;padding:20px;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,0.08);max-width:900px;}
.detail-grid{display:grid;grid-template-columns:220px 1fr;gap:20px;align-items:start;}
.detail-img{width:220px;height:220px;object-fit:cover;border-radius:10px;border:1px solid #eee;}
.detail-title{font-size:20px;margin:0 0 6px;color:#1e90ff;}
.detail-meta{color:#555;margin:4px 0;}
.detail-actions{margin-top:12px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;}
.detail-actions input[type=number]{width:90px;padding:8px;border-radius:8px;border:1px solid #ccc;}
.detail-actions button{padding:9px 14px;border:none;border-radius:8px;background:#1e90ff;color:#fff;font-weight:600;cursor:pointer;}
.detail-actions button:hover{background:#187bcd;}
.empty-state{background:#fff;padding:18px;border-radius:10px;box-shadow:0 4px 12px rgba(0,0,0,0.06);max-width:700px;}
.empty-state a{color:#1e90ff;font-weight:600;}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="profile">
        <img src="../uploads/<?= $pembeli['foto']; ?>">
        <h3><?= $pembeli['username']; ?></h3>
    </div>
    <?php renderNotifWidget('pembeli', (int)$pembeli_id); ?>

    <ul class="menu">
        <li><a href="dashboard_pembeli.php">Dashboard</a></li>
        <li><a href="produk.php">Produk</a></li>
        <li><a class="active" href="pesanan.php">Pesanan</a></li>
        <li><a href="status.php">Status</a></li>
        <li><a href="chat.php">Chat</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="akun.php">My Account</a></li>
        <li><a href="help.php">Help</a></li>
        <li class="logout"><a href="../auth/logout.php">Sign Out</a></li>
    </ul>
</div>
<main>
<header>
    <input type="text" placeholder="Cari buku...">
    <div class="right" style="display:flex;align-items:center;gap:12px;margin-left:auto;">
        <?php renderNotifWidget('pembeli', (int)$pembeli['id_pembeli']); ?>
        <div class="user" style="display:flex;align-items:center;gap:10px;">
            <span><?= htmlspecialchars($pembeli['username']); ?></span>
            <img src="../uploads/<?= htmlspecialchars($pembeli['foto'] ?: 'default.png'); ?>" alt="Profil" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
        </div>
    </div>
</header>

<h2>Pesanan</h2>
<?php if (!$produk): ?>
    <div class="empty-state">
        Pilih produk terlebih dahulu di halaman <a href="produk.php">Produk</a>.
    </div>
<?php else: ?>
    <div class="detail-card">
        <div class="detail-grid">
            <img class="detail-img" src="../uploads/<?= $produk['foto']; ?>" alt="<?= htmlspecialchars($produk['nama_produk']); ?>">
            <div>
                <h3 class="detail-title"><?= htmlspecialchars($produk['nama_produk']); ?></h3>
                <div class="detail-meta">Penjual: <?= htmlspecialchars($produk['nama_penjual']); ?></div>
                <div class="detail-meta">Harga: Rp <?= number_format($produk['harga']); ?></div>
                <div class="detail-meta">Stok: <?= $produk['stok']; ?></div>
                <div class="detail-meta">Status: <?= htmlspecialchars($produk['status']); ?></div>

                <form method="POST" class="detail-actions">
                    <input type="hidden" name="produk_id" value="<?= (int)$produk['id_produk']; ?>">
                    <label for="jumlah">Jumlah:</label>
                    <input type="number" id="jumlah" name="jumlah" value="1" min="1">
                    <button type="submit">Lanjut ke Checkout</button>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>
</main>

</body>
</html>







