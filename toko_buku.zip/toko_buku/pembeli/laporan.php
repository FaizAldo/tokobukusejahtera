<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';
include '../notifikasi/widget.php';

if(!isset($_SESSION['username'])){
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];

/* ================= DATA PEMBELI ================= */
$pembeli = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT * FROM pembeli WHERE username='$username'")
);

$id_pembeli = $pembeli['id_pembeli'];

function normFoto($val) {
    $rel = $val ? preg_replace('#^(?:\.\./)?uploads/#', '', $val) : '';
    return $rel;
}

/* ================= FILTER ================= */
$tgl_awal  = $_GET['tgl_awal']  ?? '';
$tgl_akhir = $_GET['tgl_akhir'] ?? '';
$status    = $_GET['status']    ?? '';

$where = "WHERE t.id_pembeli='$id_pembeli'";

if($tgl_awal && $tgl_akhir){
    $where .= " AND DATE(t.tanggal) BETWEEN '$tgl_awal' AND '$tgl_akhir'";
}

if($status){
    $where .= " AND t.status='$status'";
}

/* ================= QUERY ================= */
$data = mysqli_query($conn,"
SELECT t.*, p.nama_produk, p.harga, t.bukti_transfer
FROM pesanan t
JOIN produk p ON t.id_produk=p.id_produk
$where
ORDER BY t.tanggal DESC
");

/* ================= DOWNLOAD PDF ================= */
if(isset($_GET['download']) && $_GET['download']=='pdf'){
    header('Content-Type: text/html; charset=utf-8');

    $imgDataUri = function($path){
        if (!$path || !file_exists($path)) return '';
        $data = @file_get_contents($path);
        if ($data === false) return '';
        $mime = 'image/png';
        if (function_exists('finfo_open')) {
            $f = finfo_open(FILEINFO_MIME_TYPE);
            if ($f) {
                $m = finfo_file($f, $path);
                if ($m) $mime = $m;
                finfo_close($f);
            }
        } else {
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if ($ext === 'jpg' || $ext === 'jpeg') $mime = 'image/jpeg';
            elseif ($ext === 'gif') $mime = 'image/gif';
            elseif ($ext === 'webp') $mime = 'image/webp';
        }
        return 'data:'.$mime.';base64,'.base64_encode($data);
    };

    echo '<!DOCTYPE html><html><head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css"><meta charset="utf-8"><title>Laporan Transaksi</title><style>
        body{font-family:Arial, sans-serif; font-size:11px; margin:20px; color:#111;}
        h2{margin:0 0 10px;}
        table{width:100%;border-collapse:collapse;}
        th,td{border:1px solid #ccc;padding:6px;text-align:center;word-break:break-word;}
        th{background:#f1f5f9;}
        td img{width:40px;height:40px;object-fit:cover;border-radius:6px;}
        .note{margin-top:10px;color:#666;font-size:10px;}
        @media print{.note{display:none;}}
    </style></head><body>';
    echo '<h2>Laporan Transaksi</h2>';
    echo '<table><tr><th>Bukti</th><th>Produk</th><th>Harga</th><th>Jumlah</th><th>Status</th><th>Tanggal</th></tr>';
    while($d=mysqli_fetch_assoc($data)){
        $rel = normFoto($d['bukti_transfer'] ?? '');
        $path = $rel ? (__DIR__ . '/../uploads/' . $rel) : '';
        $imgSrc = $path ? $imgDataUri($path) : '';
        echo '<tr>';
        echo $imgSrc ? '<td><img src="'.$imgSrc.'"></td>' : '<td>-</td>';
        echo '<td>'.htmlspecialchars($d['nama_produk']).'</td>';
        echo '<td>Rp '.number_format($d['harga']).'</td>';
        echo '<td>'.htmlspecialchars($d['jumlah']).'</td>';
        echo '<td>'.htmlspecialchars($d['status']).'</td>';
        echo '<td>'.htmlspecialchars($d['tanggal']).'</td>';
        echo '</tr>';
    }
    echo '</table><div class="note">Gunakan Print &gt; Save as PDF untuk menyimpan sebagai PDF.</div>
    <script>window.onload=function(){window.print();};</script></body></html>';
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="utf-8">
<title>Laporan Pembeli</title>

<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
body{
    margin:0;
    font-family:Segoe UI;
    background:#f1f5f9;
}

/* Notifikasi (hitam di atas putih) */
.notif-widget{
    --notif-accent: #111111;
    --notif-accent-2: #111111;
    --notif-bg: #ffffff;
    --notif-text: #111111;
    --notif-muted: #5f5f5f;
    --notif-new: #f7f7f7;
    --notif-border: #e5e7eb;
}
.sidebar .notif-widget,
.sidebar .notif-widget *{
    color:#111111 !important;
}
.sidebar .notif-widget .notif-list{
    background:#ffffff !important;
    border-color:#e5e7eb !important;
}

/* ===== SIDEBAR ===== */
.sidebar{
    width:240px;
    height:100vh;
    background:#111827;
    color:white;
    position:fixed;
}

.profile{
    text-align:center;
    padding:20px;
}

.profile img{
    width:80px;
    height:80px;
    border-radius:50%;
    object-fit:cover;
}

.menu{
    list-style:none;
    padding:0;
}

.menu li a{
    display:block;
    padding:12px 20px;
    color:white;
    text-decoration:none;
}

.menu li a:hover{
    background:#1f2937;
}

.logout{
    background:#dc2626;
}

/* ===== CONTENT ===== */
.content{
    margin-left:240px;
    padding:30px;
}

/* FILTER */
.filter-box{
    background:white;
    padding:15px;
    border-radius:12px;
    margin-bottom:20px;
    display:flex;
    gap:10px;
    align-items:center;
}

input,select{
    padding:8px;
    border-radius:8px;
    border:1px solid #ccc;
}

/* TABLE */
.table-box{
    background:white;
    border-radius:12px;
    padding:15px;
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#2563eb;
    color:white;
    padding:10px;
}

td{
    padding:10px;
    border-bottom:1px solid #eee;
    text-align:center;
}

td img{
    width:55px;
    height:55px;
    border-radius:8px;
    object-fit:cover;
}

/* BUTTON */
.btn{
    padding:8px 14px;
    border:none;
    border-radius:10px;
    color:white;
    text-decoration:none;
    cursor:pointer;
}

.filter-btn{background:#2563eb;}
.pdf{background:#dc2626;}

.download-box{
    margin-left:auto;
    display:flex;
    gap:10px;
}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="profile">
        <img src="../uploads/<?= $pembeli['foto']; ?>">
        <h3><?= $pembeli['username']; ?></h3>
    </div>
    <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>

    <ul class="menu">
        <li><a href="dashboard_pembeli.php">Dashboard</a></li>
                <li><a href="produk.php">Produk</a></li>
        <li><a href="pesanan.php">Pesanan</a></li>
        <li><a href="status.php">Status</a></li>
        <li><a href="chat.php">Chat</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="akun.php">My Account</a></li>
        <li><a href="help.php">Help</a></li>
        <li><a class="logout" href="../auth/logout.php">Sign Out</a></li>
    </ul>
</div>


<div class="content">
<div class="topbar-account">
    <div class="title">Profil</div>
    <div class="right">
        <?php renderNotifWidget('pembeli', (int)$id_pembeli); ?>
        <div class="user">
            <span><?= htmlspecialchars($pembeli['username']); ?></span>
            <img src="../uploads/<?= htmlspecialchars($pembeli['foto'] ?: 'default.png'); ?>" alt="Profil">
        </div>
    </div>
</div>

<h2>Laporan Transaksi</h2>

<!-- FILTER + DOWNLOAD -->
<form class="filter-box" method="GET">

    <input type="date" name="tgl_awal" value="<?= $tgl_awal ?>">
    <input type="date" name="tgl_akhir" value="<?= $tgl_akhir ?>">

    <select name="status">
        <option value="">Semua Status</option>
        <option <?= $status=='Proses'?'selected':'' ?>>Proses</option>
        <option <?= $status=='Dikirim'?'selected':'' ?>>Dikirim</option>
        <option <?= $status=='Selesai'?'selected':'' ?>>Selesai</option>
    </select>

    <button class="btn filter-btn">Filter</button>

    <?php
        $downloadQuery = http_build_query([
            'download' => 'pdf',
            'tgl_awal' => $tgl_awal,
            'tgl_akhir' => $tgl_akhir,
            'status' => $status
        ]);
    ?>
    <div class="download-box">
        <a href="?<?= htmlspecialchars($downloadQuery) ?>" class="btn pdf">Download PDF</a>
    </div>
</form>


<!-- TABLE -->
<div class="table-box">
<table>
<tr>
    <th>Bukti</th>
    <th>Produk</th>
    <th>Harga</th>
    <th>Jumlah</th>
    <th>Status</th>
    <th>Tanggal</th>
</tr>

<?php while($d=mysqli_fetch_assoc($data)){ ?>
<tr>
    <?php $bukti_rel = normFoto($d['bukti_transfer'] ?? ''); ?>
    <td>
        <?php if ($bukti_rel): ?>
            <img src="../uploads/<?= htmlspecialchars($bukti_rel); ?>">
        <?php else: ?>
            -
        <?php endif; ?>
    </td>
    <td><?= $d['nama_produk']; ?></td>
    <td>Rp <?= number_format($d['harga']); ?></td>
    <td><?= $d['jumlah']; ?></td>
    <td><?= $d['status']; ?></td>
    <td><?= $d['tanggal']; ?></td>
</tr>
<?php } ?>

</table>
</div>

</div>
</body>
</html>










