<?php
session_start();
include '../conn/koneksi.php';
include '../notifikasi/notif_system.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login_users.php");
    exit;
}

$username = $_SESSION['username'];
$halaman = basename($_SERVER['PHP_SELF']);

$stmtp = $conn->prepare("SELECT * FROM pembeli WHERE username = ? LIMIT 1");
$stmtp->bind_param("s", $username);
$stmtp->execute();
$pembeli = $stmtp->get_result()->fetch_assoc();
$stmtp->close();

function esc($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_help'])) {
    header('Content-Type: application/json; charset=utf-8');

    $id_pembeli = (int) ($pembeli['id_pembeli'] ?? 0);
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($id_pembeli <= 0) {
        echo json_encode(['success' => false, 'message' => 'Akun tidak terdeteksi. Silakan login ulang.']);
        exit;
    }
    if ($message === '') {
        echo json_encode(['success' => false, 'message' => 'Pesan tidak boleh kosong.']);
        exit;
    }

    $full = $subject ? ("[Subject: " . $subject . "]\n\n" . $message) : $message;

    $stmt = $conn->prepare("INSERT INTO messages (pembeli_id, sender, message, is_read) VALUES (?, 'pembeli', ?, 0)");
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Kesalahan sistem (prepare).']);
        exit;
    }
    $stmt->bind_param("is", $id_pembeli, $full);
    $ok = $stmt->execute();
    $err = $stmt->error;
    $stmt->close();

    if ($ok) {
        kirimNotifKeSuperadmin("Pesan bantuan dari pembeli @{$pembeli['username']}");
        echo json_encode(['success' => true, 'message' => 'Pesan terkirim. Tim support akan menindaklanjuti.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal mengirim: ' . $err]);
    }
    exit;
}

$topics = [
    [
        'id' => 'start',
        'q' => 'Bagaimana cara mulai belanja? ',
        'a' => 'Login sebagai pembeli lalu buka Dashboard. Pilih buku, klik detail produk, lalu masukkan ke Pesanan untuk melanjutkan checkout.'
    ],
    [
        'id' => 'payment',
        'q' => 'Metode pembayaran apa saja? ',
        'a' => 'Gunakan metode yang tersedia di halaman checkout. Setelah membayar, unggah bukti pembayaran sesuai instruksi.'
    ],
    [
        'id' => 'status',
        'q' => 'Bagaimana cek status pesanan? ',
        'a' => 'Buka menu Status untuk melihat proses pesanan: Proses, Dikirim, atau Selesai. Nomor resi akan tampil jika sudah dikirim.'
    ],
    [
        'id' => 'chat',
        'q' => 'Bagaimana chat dengan penjual? ',
        'a' => 'Buka menu Chat untuk mengirim pesan ke penjual terkait pesanan atau produk.'
    ],
    [
        'id' => 'cancel',
        'q' => 'Apakah pesanan bisa dibatalkan? ',
        'a' => 'Jika pesanan belum diproses penjual, Anda dapat menghubungi penjual melalui Chat untuk pembatalan. Jika sudah diproses, ikuti kebijakan yang berlaku.'
    ],
    [
        'id' => 'laporan',
        'q' => 'Bagaimana membuat laporan transaksi? ',
        'a' => 'Buka menu Laporan dan gunakan filter tanggal atau status. Anda bisa mengunduh laporan Word atau PDF.'
    ],
    [
        'id' => 'akun',
        'q' => 'Bagaimana mengubah data akun? ',
        'a' => 'Buka menu My Account untuk memperbarui profil, foto, atau password.'
    ],
    [
        'id' => 'contact',
        'q' => 'Saya butuh bantuan lain, bagaimana menghubungi support? ',
        'a' => 'Gunakan formulir Kontak di bawah untuk mengirim pesan ke tim support. Pesan akan dibalas melalui sistem pesan di dashboard.'
    ],
];
?>
<!DOCTYPE html>
<html>
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="utf-8">
<title>Help Pembeli</title>
<style>
/* sidebar-hover-active */
.sidebar a:hover,
.sidebar a.active,
.sidebar .menu a:hover,
.sidebar .menu a.active,
.sidebar .menu li.active a{
    background:#8d4545 !important;
    color:#fff !important;
}
/* topbar-account */
.topbar-account{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:10px 0 20px;padding:12px 16px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);} 
.topbar-account .title{font-weight:700;color:#6b2f2f;font-size:16px;}
.topbar-account .right{display:flex;align-items:center;gap:12px;margin-left:auto;}
.topbar-account .user{display:flex;align-items:center;gap:10px;color:#333;font-size:13px;}
.topbar-account .user img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #e5e7eb;}
.sidebar .profile{display:none !important;}
/* store-logo */
.store-logo{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:12px 10px;margin-bottom:10px;}
.store-logo img{width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.5);}
.store-logo .store-name{font-weight:700;font-size:13px;letter-spacing:.4px;text-align:left;line-height:1.2;color:#fff;}
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins}
body{background:#f4f6fb;display:flex}

/* SIDEBAR */
.sidebar{
    width:260px;
    background:brown;
    color:#fff;
    min-height:100vh;
    padding:20px;
    position:fixed;
}
.profile{text-align:center;margin-bottom:25px}
.profile img{width:80px;height:80px;border-radius:50%;border:3px solid #fff;object-fit:cover}
.profile h3{margin-top:10px;font-size:17px}

.menu li{list-style:none;margin:8px 0}
.menu a{
    color:#fff;text-decoration:none;
    display:block;padding:10px 15px;
    border-radius:8px;
}
.menu a:hover{background:#334155}
.menu a.active{background:#334155;font-weight:700}
.logout{background:#ef4444;margin-top:20px}

/* MAIN */
main{margin-left:260px;padding:25px;width:100%}

.header{
    background:#fff;
    padding:15px 20px;
    border-radius:10px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}
.search input{
    padding:8px 15px;
    border-radius:25px;
    border:1px solid #ddd;
    width:320px;
}

.helper{
    background:#fff;
    padding:12px 16px;
    border-radius:10px;
    margin-bottom:16px;
    border:1px solid #eee;
}

.topics{display:flex;flex-direction:column;gap:12px;max-width:900px}
.topic{background:#fff;border-radius:10px;padding:12px;border:1px solid #e6e6e6}
.topic .q{font-weight:700;cursor:pointer;display:flex;justify-content:space-between;align-items:center}
.topic .a{margin-top:8px;display:none;color:#333;line-height:1.5}
.topic .tag{background:#f1f3f3;padding:4px 8px;border-radius:12px;font-size:12px;color:#666}

.contact{margin-top:18px;background:#fff;padding:14px;border-radius:10px;border:1px solid #e6e6e6;max-width:700px}
.contact input[type=text], .contact textarea{width:100%;padding:8px;border-radius:8px;border:1px solid #ccc}
.contact textarea{min-height:120px;resize:vertical}
.contact .row{display:flex;gap:8px;margin-top:8px}
.contact .btn{background:#1e90ff;color:#fff;border:none;padding:10px 14px;border-radius:8px;cursor:pointer}
.contact .msg{margin-top:8px;font-size:13px}

@media(max-width:900px){
    main{margin-left:0;padding:12px}
    .search input{width:100%}
}
/* Theme override */
.sidebar{background:linear-gradient(180deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
.banner{background:linear-gradient(135deg,#8d4545,#6b2f2f) !important;color:#fff !important;}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="store-logo">
    <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg" alt="Toko Buku Sejahtera">
    <div class="store-name">TOKO BUKU SEJAHTERA</div>
</div>
    <div class="profile">
        <img src="../uploads/<?= $pembeli['foto']; ?>" alt="avatar">
        <h3><?= $pembeli['username']; ?></h3>
    </div>

    <ul class="menu">
        <li><a href="dashboard_pembeli.php">Dashboard</a></li>
                <li><a href="produk.php">Produk</a></li>
        <li><a href="pesanan.php">Pesanan</a></li>
        <li><a href="status.php">Status</a></li>
        <li><a href="chat.php">Chat</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="akun.php">My Account</a></li>
        <li><a href="help.php" class="active">Help</a></li>
        <li><a class="logout" href="../auth/logout.php">Sign Out</a></li>
    </ul>
</div>

<!-- MAIN -->
<main>
    <div class="header">
        <h2>Help Pembeli</h2>
        <div class="search">
            <input type="text" id="search" placeholder="Cari topik bantuan (contoh: pembayaran, status, chat)">
        </div>
        <div class="right" style="display:flex;align-items:center;gap:12px;margin-left:auto;">
            <div class="user" style="display:flex;align-items:center;gap:10px;">
                <span><?= htmlspecialchars($pembeli['username']); ?></span>
                <img src="../uploads/<?= htmlspecialchars($pembeli['foto'] ?: 'default.png'); ?>" alt="Profil" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
            </div>
        </div>
    </div>

    <div class="helper">
        <strong>Butuh bantuan cepat?</strong> Klik salah satu topik di bawah. Jika belum menemukan jawaban, gunakan formulir Kontak.
    </div>

    <div class="topics" id="topics">
        <?php foreach ($topics as $t): ?>
            <div class="topic" data-id="<?= esc($t['id']) ?>" data-key="<?= esc(strtolower($t['q'] . ' ' . $t['a'])) ?>">
                <div class="q">
                    <div><?= esc($t['q']) ?></div>
                    <div class="tag">Lihat</div>
                </div>
                <div class="a"><?= nl2br(esc($t['a'])) ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="contact">
        <h3>Kontak Support</h3>
        <form id="contactForm">
            <label for="subject">Subject (opsional)</label>
            <input type="text" name="subject" id="subject" placeholder="Ringkasan singkat (mis. Pesanan belum dikirim)">

            <label for="message" style="margin-top:8px">Pesan</label>
            <textarea name="message" id="message" placeholder="Jelaskan masalah Anda secara detail..."></textarea>

            <div class="row" style="margin-top:8px">
                <button type="submit" class="btn">Kirim</button>
                <div id="contactStatus" style="align-self:center;margin-left:8px;color:#333"></div>
            </div>
            <input type="hidden" name="send_help" value="1">
        </form>
        <div class="msg" id="contactNote">Kami akan membalas melalui sistem pesan di dashboard Anda.</div>
    </div>
</main>

<script>
(function(){
    var topics = document.querySelectorAll('.topic .q');
    topics.forEach(function(q){
        q.addEventListener('click', function(){
            var a = q.closest('.topic').querySelector('.a');
            document.querySelectorAll('.topic .a').forEach(function(other){
                if (other !== a) other.style.display = 'none';
            });
            a.style.display = (a.style.display === 'block') ? 'none' : 'block';
        });
    });

    var search = document.getElementById('search');
    search.addEventListener('input', function(){
        var q = search.value.trim().toLowerCase();
        document.querySelectorAll('.topic').forEach(function(t){
            var key = (t.getAttribute('data-key') || '');
            if (!q || key.indexOf(q) !== -1) t.style.display = 'block';
            else t.style.display = 'none';
        });
    });

    var form = document.getElementById('contactForm');
    form.addEventListener('submit', function(e){
        e.preventDefault();
        var btn = form.querySelector('button[type=submit]');
        var status = document.getElementById('contactStatus');
        status.textContent = '';
        btn.disabled = true;
        btn.textContent = 'Mengirim...';

        fetch('help.php', {
            method: 'POST',
            body: new FormData(form)
        }).then(function(res){
            return res.json();
        }).then(function(res){
            if (res.success) {
                status.style.color = 'green';
                status.textContent = res.message;
                form.reset();
            } else {
                status.style.color = 'red';
                status.textContent = res.message || 'Gagal mengirim pesan.';
            }
        }).catch(function(){
            status.style.color = 'red';
            status.textContent = 'Permintaan gagal. Coba lagi.';
        }).finally(function(){
            btn.disabled = false;
            btn.textContent = 'Kirim';
        });
    });
})();
</script>

</body>
</html>










