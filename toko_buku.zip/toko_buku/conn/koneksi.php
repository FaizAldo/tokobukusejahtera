<?php
// ================== SESSION ==================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ================== DATABASE ==================
$hostname = 'localhost';
$user     = 'root';
$pass     = '';
$db       = 'toko_buku';
$port     = 3307;

$conn = mysqli_connect($hostname, $user, $pass, $db, $port);

// ================== CEK KONEKSI ==================
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// ================== SET CHARSET ==================
mysqli_set_charset($conn, "utf8mb4");
