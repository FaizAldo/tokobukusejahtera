<?php
// ===============================
// FILE : notif_system.php
// SISTEM NOTIFIKASI UNIVERSAL
// ===============================

if (!isset($conn)) {
    include '../conn/koneksi.php';
}

/* ===============================
   FUNGSI TAMBAH NOTIFIKASI
================================ */

if (!function_exists('kirimNotif')) {
    /**
     * kirimNotif('pembeli', id, 'pesan')
     * kirimNotif('penjual', id, 'pesan')
     * kirimNotif('admin', id, 'pesan')
     */
    function kirimNotif($tipe, $id, $pesan, $link = null)
    {
        global $conn;

        if ($tipe == 'pembeli') {
            $stmt = $conn->prepare("
                INSERT INTO notifikasi (id_pembeli, pesan, link)
                VALUES (?, ?, ?)
            ");
            $stmt->bind_param("iss", $id, $pesan, $link);
        } elseif ($tipe == 'penjual') {
            $stmt = $conn->prepare("
                INSERT INTO notifikasi (id_penjual, pesan, link)
                VALUES (?, ?, ?)
            ");
            $stmt->bind_param("iss", $id, $pesan, $link);
        } elseif ($tipe == 'admin') {
            $stmt = $conn->prepare("
                INSERT INTO notifikasi (id_admin, pesan, link)
                VALUES (?, ?, ?)
            ");
            $stmt->bind_param("iss", $id, $pesan, $link);
        } else {
            return false;
        }

        return $stmt->execute();
    }
}

/**
 * kirim notifikasi ke semua superadmin
 */
if (!function_exists('kirimNotifKeSuperadmin')) {
    /**
     * kirim notifikasi ke semua superadmin
     */
    function kirimNotifKeSuperadmin($pesan)
    {
        global $conn;

        $q = $conn->query("SELECT id_admin FROM admin WHERE role='superadmin'");
        if (!$q) return false;

        while ($row = $q->fetch_assoc()) {
            $id_admin = (int) ($row['id_admin'] ?? 0);
            if ($id_admin > 0) {
                kirimNotif('admin', $id_admin, $pesan);
            }
        }
        return true;
    }
}

/* ===============================
   AMBIL NOTIFIKASI
================================ */

if (!function_exists('ambilNotif')) {
    function ambilNotif($tipe, $id)
    {
        global $conn;

        if ($tipe == 'pembeli') {
            $sql = "SELECT * FROM notifikasi
                    WHERE id_pembeli=?
                    ORDER BY waktu DESC";
        } elseif ($tipe == 'penjual') {
            $sql = "SELECT * FROM notifikasi
                    WHERE id_penjual=?
                    ORDER BY waktu DESC";
        } else {
            $sql = "SELECT * FROM notifikasi
                    WHERE id_admin=?
                    ORDER BY waktu DESC";
        }

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();

        return $stmt->get_result();
    }
}

/* ===============================
   HITUNG NOTIF BARU
================================ */

if (!function_exists('hitungNotif')) {
    function hitungNotif($tipe, $id)
    {
        global $conn;

        if ($tipe == 'pembeli') {
            $sql = "SELECT COUNT(*) total
                    FROM notifikasi
                    WHERE id_pembeli=? AND status='baru'";
        } elseif ($tipe == 'penjual') {
            $sql = "SELECT COUNT(*) total
                    FROM notifikasi
                    WHERE id_penjual=? AND status='baru'";
        } else {
            $sql = "SELECT COUNT(*) total
                    FROM notifikasi
                    WHERE id_admin=? AND status='baru'";
        }

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();

        return $stmt->get_result()->fetch_assoc()['total'] ?? 0;
    }
}

/* ===============================
   TANDAI SUDAH DIBACA
================================ */

if (!function_exists('bacaNotif')) {
    function bacaNotif($tipe, $id)
    {
        global $conn;

        if ($tipe == 'pembeli') {
            $sql = "UPDATE notifikasi
                    SET status='dibaca'
                    WHERE id_pembeli=?";
        } elseif ($tipe == 'penjual') {
            $sql = "UPDATE notifikasi
                    SET status='dibaca'
                    WHERE id_penjual=?";
        } else {
            $sql = "UPDATE notifikasi
                    SET status='dibaca'
                    WHERE id_admin=?";
        }

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}
