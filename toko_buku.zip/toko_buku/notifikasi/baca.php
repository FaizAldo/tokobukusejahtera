﻿<?php
session_start();
include '../conn/koneksi.php';
include 'notif_system.php';

if (!isset($_SESSION['username'])) {
    http_response_code(401);
    exit;
}

$tipe = $_GET['tipe'] ?? '';
$notif_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$username = $_SESSION['username'];

if ($tipe === 'pembeli') {
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_pembeli FROM pembeli WHERE username='$username'"));
    $id = $row['id_pembeli'] ?? 0;
    if ($id) {
        if ($notif_id > 0) {
            $stmt = $conn->prepare("UPDATE notifikasi SET status='dibaca' WHERE id_notif=? AND id_pembeli=?");
            $stmt->bind_param("ii", $notif_id, $id);
            $stmt->execute();
        } else {
            bacaNotif('pembeli', (int)$id);
        }
    }
}
elseif ($tipe === 'penjual') {
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_penjual FROM penjual WHERE username='$username'"));
    $id = $row['id_penjual'] ?? 0;
    if ($id) {
        if ($notif_id > 0) {
            $stmt = $conn->prepare("UPDATE notifikasi SET status='dibaca' WHERE id_notif=? AND id_penjual=?");
            $stmt->bind_param("ii", $notif_id, $id);
            $stmt->execute();
        } else {
            bacaNotif('penjual', (int)$id);
        }
    }
}
elseif ($tipe === 'admin') {
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_admin FROM admin WHERE username='$username'"));
    $id = $row['id_admin'] ?? 0;
    if ($id) {
        if ($notif_id > 0) {
            $stmt = $conn->prepare("UPDATE notifikasi SET status='dibaca' WHERE id_notif=? AND id_admin=?");
            $stmt->bind_param("ii", $notif_id, $id);
            $stmt->execute();
        } else {
            bacaNotif('admin', (int)$id);
        }
    }
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true]);
