<?php
// Widget notifikasi sederhana (tanpa auto-read)
// Usage: include this file + call renderNotifWidget($tipe, $id)

if (!function_exists('renderNotifWidget')) {
    function renderNotifWidget(string $tipe, int $id) {
        if (!isset($GLOBALS['conn'])) return;
        $conn = $GLOBALS['conn'];

        $map = [
            'pembeli' => 'id_pembeli',
            'penjual' => 'id_penjual',
            'admin'   => 'id_admin'
        ];
        if (!isset($map[$tipe])) return;

        $col = $map[$tipe];
        $id = (int)$id;

        $total = function_exists('hitungNotif') ? hitungNotif($tipe, $id) : 0;
        $list = mysqli_query($conn, "
            SELECT id_notif, pesan, status, waktu, link
            FROM notifikasi
            WHERE $col = '$id'
            ORDER BY id_notif DESC
            LIMIT 5
        ");

        $inferLink = function(string $tipe, string $pesan): ?string {
            $msg = strtolower($pesan);
            $has = function(string $needle) use ($msg): bool {
                return strpos($msg, strtolower($needle)) !== false;
            };

            if ($has('pesan bantuan')) {
                if ($tipe === 'admin') return 'help_admin.php';
                return 'help.php';
            }
            if ($has('pesan baru')) {
                return 'chat.php';
            }
            if ($has('registrasi pembeli')) {
                return $tipe === 'admin' ? 'pembeli.php' : null;
            }
            if ($has('registrasi penjual')) {
                return $tipe === 'admin' ? 'admin_penjual.php' : null;
            }
            if ($has('pesanan')) {
                if ($tipe === 'penjual') return 'approve.php';
                if ($tipe === 'pembeli') return 'status.php';
                if ($tipe === 'admin') return 'dashboard_admin.php';
            }
            return null;
        };

        static $counter = 0;
        $counter++;
        $uid = 'notif_' . $tipe . '_' . $id . '_' . $counter;
        ?>
        <style>
        /* paksa tampil di topbar (pojok kanan atas) */
        /* allow dropdown to escape common topbar containers */
        .topbar, header, .header, .topbar-account, .global-topbar, .main, .main-content, .content, .container{
            overflow: visible !important;
        }
        .notif-widget{
            --notif-accent: var(--notif-accent, #111111);
            --notif-accent-2: var(--notif-accent-2, #111111);
            --notif-bg: var(--notif-bg, #ffffff);
            --notif-text: var(--notif-text, #111111);
            --notif-muted: var(--notif-muted, #5f5f5f);
            --notif-new: var(--notif-new, #f7f7f7);
            --notif-border: var(--notif-border, #e5e7eb);
            position:relative;
            z-index:2000;
            display:inline-flex;
            align-items:center;
            color:var(--notif-text) !important;
            filter:none !important;
            opacity:1 !important;
        }
        .notif-widget *{color:var(--notif-text) !important;}
        .notif-widget .notif-bell{
            cursor:pointer;
            font-size:18px;
            position:relative;
            color:var(--notif-text) !important;
            background:#ffffff !important;
            border:1px solid var(--notif-border);
            width:34px;
            height:34px;
            border-radius:50%;
            display:flex;
            align-items:center;
            justify-content:center;
            box-shadow:0 2px 6px rgba(0,0,0,.08);
            line-height:1;
        }
        .notif-widget .notif-badge{
            position:absolute;top:-6px;right:-8px;background:#ef4444;color:#fff;
            font-size:11px;padding:2px 6px;border-radius:50%;
        }
        .notif-widget .notif-list{
            display:none;position:absolute;right:0;top:26px;background:var(--notif-bg);border:1px solid var(--notif-border);
            width:280px;max-width:90vw;border-radius:10px;box-shadow:0 8px 20px rgba(0,0,0,.10);
            padding:8px;z-index:2100;color:var(--notif-text) !important;
            opacity:1 !important;
        }
        .notif-widget .notif-list *{color:var(--notif-text) !important;}
        .notif-widget .notif-item{
            display:block;
            padding:8px;
            border-bottom:1px solid #f1f5f9;
            font-size:13px;
            color:var(--notif-text) !important;
            text-decoration:none;
            border-radius:6px;
            background:#ffffff !important;
            line-height:1.35;
        }
        .notif-widget .notif-item *{color:var(--notif-text) !important;}
        .notif-widget .notif-item:last-child{border-bottom:none;}
        .notif-widget .notif-item.new{background:#ffffff !important;}
        .notif-widget .notif-item:hover{background:#f2f2f2 !important;}
        .notif-widget .notif-item:focus{outline:2px solid var(--notif-accent);outline-offset:2px;}
        .notif-widget .notif-item .time{display:block;font-size:11px;color:var(--notif-muted);margin-top:4px;}
        @media (max-width: 600px){
            .notif-widget .notif-list{
                right:0;
                left:auto;
                width:min(320px, 92vw);
                max-height:60vh;
                overflow:auto;
            }
        }

        /* ===== Global Brown Theme (All Roles) ===== */
        :root{
            --theme-primary:#8d4545;
            --theme-primary-dark:#6b2f2f;
            --theme-hover:rgba(255,255,255,0.2);
            --theme-active:rgba(255,255,255,0.3);
            --theme-logout:#ef4444;
        }
        .sidebar{
            background:linear-gradient(180deg,var(--theme-primary),var(--theme-primary-dark)) !important;
            color:#fff !important;
        }
        .sidebar .menu a{
            color:#fff !important;
        }
        .sidebar .menu a:hover{
            background:var(--theme-hover) !important;
        }
        .sidebar .menu a.active,
        .sidebar .menu li.active a{
            background:var(--theme-active) !important;
            font-weight:700;
        }
        .sidebar .menu .logout a,
        .sidebar .logout a{
            background:var(--theme-logout) !important;
            color:#fff !important;
        }
        /* Hide notif widget inside sidebar to avoid duplicates */
        .sidebar .notif-widget{display:none !important;}
        </style>
        <div class="notif-widget" id="<?= $uid ?>">
            <div class="notif-bell">&#128276;
                <span class="notif-badge" style="<?= $total > 0 ? '' : 'display:none;' ?>"><?= (int)$total ?></span>
            </div>
            <div class="notif-list">
                <?php if($list && mysqli_num_rows($list) > 0): ?>
                    <?php while($n = mysqli_fetch_assoc($list)): ?>
                        <?php
                            $pesan = $n['pesan'] ?? '';
                            $link = $n['link'] ?? '';
                            if (!$link) $link = $inferLink($tipe, $pesan);
                            $time = $n['waktu'] ?? '';
                            $timeText = $time ? date('d M Y H:i', strtotime($time)) : '';
                            $notifId = (int)($n['id_notif'] ?? 0);
                        ?>
                        <?php if ($link): ?>
                            <a class="notif-item <?= $n['status']=='baru'?'new':'' ?>" href="<?= htmlspecialchars($link, ENT_QUOTES, 'UTF-8') ?>" data-notif-id="<?= $notifId ?>">
                                <?= htmlspecialchars($pesan); ?>
                                <?php if ($timeText): ?><span class="time"><?= htmlspecialchars($timeText); ?></span><?php endif; ?>
                            </a>
                        <?php else: ?>
                            <div class="notif-item <?= $n['status']=='baru'?'new':'' ?>" data-notif-id="<?= $notifId ?>">
                                <?= htmlspecialchars($pesan); ?>
                                <?php if ($timeText): ?><span class="time"><?= htmlspecialchars($timeText); ?></span><?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="notif-item">Belum ada notifikasi</div>
                <?php endif; ?>
            </div>
        </div>
        <script>
        (function(){
            var root = document.getElementById('<?= $uid ?>');
            if(!root) return;
            var bell = root.querySelector('.notif-bell');
            var list = root.querySelector('.notif-list');
            var tipe = '<?= $tipe ?>';
            var readUrl = '../notifikasi/baca.php';
            bell.addEventListener('click', function(e){
                e.stopPropagation();
                list.style.display = (list.style.display === 'block') ? 'none' : 'block';
            });
            list.addEventListener('click', function(e){
                e.stopPropagation();
            });
            document.addEventListener('click', function(){
                list.style.display = 'none';
            });
            list.addEventListener('click', function(e){
                var item = e.target.closest('.notif-item');
                if(!item) return;
                var id = item.getAttribute('data-notif-id');
                if(!id) return;
                fetch(readUrl + '?tipe=' + encodeURIComponent(tipe) + '&id=' + encodeURIComponent(id), {
                    method: 'GET',
                    credentials: 'same-origin'
                }).catch(function(){});
            });
        })();
        </script>
        <?php
    }
}
