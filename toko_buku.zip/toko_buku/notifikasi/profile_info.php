<?php
session_start();
require '../conn/koneksi.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$username = $_SESSION['username'];
$role = $_SESSION['role'] ?? ($_SESSION['user_role'] ?? '');

function jsonOut($data) {
    echo json_encode($data);
    exit;
}

function buildPhotoPath($foto) {
    $foto = $foto ?: 'default.png';
    $foto = preg_replace('#^(?:\.\./)?uploads/#', '', $foto);
    return '../uploads/' . $foto;
}

if ($role === 'admin') {
    $stmt = $conn->prepare("SELECT id_admin, username, email, foto, role FROM admin WHERE username=? LIMIT 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $admin = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$admin) {
        jsonOut(['success' => false, 'message' => 'Admin not found']);
    }

    jsonOut([
        'success' => true,
        'role' => $admin['role'] ?? 'admin',
        'name' => $admin['username'] ?? '',
        'username' => $admin['username'] ?? '',
        'email' => $admin['email'] ?? '',
        'phone' => '',
        'address' => '',
        'nik' => '',
        'photo' => buildPhotoPath($admin['foto'] ?? '')
    ]);
}

// Non-admin: try penjual then pembeli
$stmt = $conn->prepare("SELECT id_penjual, nama_penjual, username, email, no_hp, alamat, foto FROM penjual WHERE username=? LIMIT 1");
$stmt->bind_param("s", $username);
$stmt->execute();
$penjual = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($penjual) {
    jsonOut([
        'success' => true,
        'role' => 'penjual',
        'name' => $penjual['nama_penjual'] ?? '',
        'username' => $penjual['username'] ?? '',
        'email' => $penjual['email'] ?? '',
        'phone' => $penjual['no_hp'] ?? '',
        'address' => $penjual['alamat'] ?? '',
        'nik' => '',
        'photo' => buildPhotoPath($penjual['foto'] ?? '')
    ]);
}

$stmt = $conn->prepare("SELECT id_pembeli, nik, username, email, no_hp, alamat, foto FROM pembeli WHERE username=? LIMIT 1");
$stmt->bind_param("s", $username);
$stmt->execute();
$pembeli = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($pembeli) {
    jsonOut([
        'success' => true,
        'role' => 'pembeli',
        'name' => $pembeli['username'] ?? '',
        'username' => $pembeli['username'] ?? '',
        'email' => $pembeli['email'] ?? '',
        'phone' => $pembeli['no_hp'] ?? '',
        'address' => $pembeli['alamat'] ?? '',
        'nik' => $pembeli['nik'] ?? '',
        'photo' => buildPhotoPath($pembeli['foto'] ?? '')
    ]);
}

jsonOut(['success' => false, 'message' => 'User not found']);
