<?php
require '../conn/koneksi.php';

if (!isset($_POST['email'], $_POST['token'], $_POST['password'], $_POST['confirm'])) {
    exit("Akses tidak valid");
}

$email = trim($_POST['email']);
$token = trim($_POST['token']);
$password = $_POST['password'];
$confirm = $_POST['confirm'];
$role = trim($_POST['role'] ?? '');

if ($email === '' || $token === '' || $password === '' || $confirm === '') {
    exit("Semua field wajib diisi");
}
if ($password !== $confirm) {
    exit("Konfirmasi password tidak cocok");
}
if (strlen($password) < 6) {
    exit("Password minimal 6 karakter");
}

$roles = ['admin', 'penjual', 'pembeli'];
if ($role !== '' && in_array($role, $roles, true)) {
    $roles = [$role];
}

$found = false;
$byTokenOnly = false;
$target = null;

foreach ($roles as $r) {
    $table = $r;
    $id_col = $r === 'admin' ? 'id_admin' : ($r === 'penjual' ? 'id_penjual' : 'id_pembeli');

    $stmt = $conn->prepare("SELECT $id_col, email, reset_token, token_expired FROM $table WHERE email=? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) continue;

    if (($row['reset_token'] ?? '') !== $token) {
        continue;
    }

    $expired = $row['token_expired'] ?? null;
    if ($expired && strtotime($expired) < time()) {
        exit("Token sudah kedaluwarsa");
    }

    $target = ['table'=>$table,'id_col'=>$id_col,'id'=>$row[$id_col],'email'=>$row['email']];
    $found = true;
    break;
}

if (!$found) {
    // fallback: cari berdasarkan token saja (untuk menghindari typo email)
    foreach ($roles as $r) {
        $table = $r;
        $id_col = $r === 'admin' ? 'id_admin' : ($r === 'penjual' ? 'id_penjual' : 'id_pembeli');

        $stmt = $conn->prepare("SELECT $id_col, email, reset_token, token_expired FROM $table WHERE reset_token=? LIMIT 1");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$row) continue;

        $expired = $row['token_expired'] ?? null;
        if ($expired && strtotime($expired) < time()) {
            exit("Token sudah kedaluwarsa");
        }

        $target = ['table'=>$table,'id_col'=>$id_col,'id'=>$row[$id_col],'email'=>$row['email']];
        $found = true;
        $byTokenOnly = true;
        break;
    }
}

if (!$found || !$target) {
    exit("Token/email tidak valid");
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare("UPDATE {$target['table']} SET password=?, reset_token=NULL, token_expired=NULL WHERE {$target['id_col']}=?");
$stmt->bind_param("si", $hash, $target['id']);
$stmt->execute();
$stmt->close();

echo "Password berhasil direset. Silakan login kembali.";
