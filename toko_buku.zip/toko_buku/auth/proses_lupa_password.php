<?php
require '../conn/koneksi.php';
require 'mailer.php';

/* ================= VALIDASI AKSES ================= */
if (!isset($_POST['email'])) {
    exit("Akses tidak valid");
}

$email = trim($_POST['email']);

if ($email == '') {
    exit("Email wajib diisi");
}

/* ================= GENERATE TOKEN ================= */
$token   = bin2hex(random_bytes(32));
$expired = date('Y-m-d H:i:s', strtotime('+15 minutes'));

$role = '';

/* ==================================================
   CEK ADMIN
================================================== */
$stmt = $conn->prepare("SELECT id_admin FROM admin WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

if ($admin) {
    $update = $conn->prepare("
        UPDATE admin 
        SET reset_token = ?, token_expired = ?
        WHERE email = ?
    ");
    $update->bind_param("sss", $token, $expired, $email);
    $update->execute();
    $role = 'admin';
} else {

    /* ==================================================
       CEK PEMBELI
    ================================================== */
    $stmt = $conn->prepare("SELECT id_pembeli FROM pembeli WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $pembeli = $stmt->get_result()->fetch_assoc();

    if ($pembeli) {

        $update = $conn->prepare("
            UPDATE pembeli 
            SET reset_token = ?, token_expired = ?
            WHERE email = ?
        ");
        $update->bind_param("sss", $token, $expired, $email);
        $update->execute();

        $role = 'pembeli';

    /* ==================================================
       CEK PENJUAL
    ================================================== */
    } else {

        $stmt = $conn->prepare("SELECT id_penjual FROM penjual WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $penjual = $stmt->get_result()->fetch_assoc();

        if ($penjual) {

            $update = $conn->prepare("
                UPDATE penjual 
                SET reset_token = ?, token_expired = ?
                WHERE email = ?
            ");
            $update->bind_param("sss", $token, $expired, $email);
            $update->execute();

            $role = 'penjual';

        } else {
            exit("Email tidak terdaftar di sistem");
        }
    }
}

/* ================= LINK RESET ================= */
$link = "http://localhost/usk/toko_buku/auth/reset_password.php?token=$token&role=$role&email=" . urlencode($email);

/* ================= KIRIM EMAIL ================= */
sendMail(
    $email,
    "Reset Password Akun",
    "
    Halo,<br><br>

    Kami menerima permintaan reset password untuk akun <b>$role</b>.<br><br>

    Silakan klik link berikut untuk melanjutkan:<br>
    <a href='$link'>$link</a><br><br>

    Link ini hanya berlaku selama <b>15 menit</b>.<br><br>

    Jika Anda tidak merasa melakukan permintaan ini,
    silakan abaikan email ini.<br><br>

    Terima kasih,<br>
    <b>Tim Toko</b>
    "
);

echo "Link reset password berhasil dikirim ke email";
