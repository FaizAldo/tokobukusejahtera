<?php
session_start();
include '../conn/koneksi.php';

$error = '';

// Jika sudah login, redirect sesuai role
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'admin') header("Location: ../admin/dashboard_admin.php");
    elseif ($_SESSION['role'] == 'penjual') header("Location: ../penjual/dashboard_penjual.php");
    elseif ($_SESSION['role'] == 'pembeli') header("Location: ../pembeli/dashboard_pembeli.php");
    exit;
}

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $tables = ['admin', 'penjual', 'pembeli'];
    $idCols = [
        'admin' => 'id_admin',
        'penjual' => 'id_penjual',
        'pembeli' => 'id_pembeli'
    ];
    $found = false;

    foreach ($tables as $table) {
        $query = mysqli_query($conn, "SELECT * FROM $table WHERE username='$username' LIMIT 1");
        if (mysqli_num_rows($query) > 0) {
            $user = mysqli_fetch_assoc($query);

            // cek password (plain text atau hash)
            if (isset($user['password']) && ($user['password'] === $password || password_verify($password, $user['password']))) {
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $table;
                $_SESSION['user_role'] = $table;
                $_SESSION['foto'] = $user['foto'] ?? 'default.png';
                $idCol = $idCols[$table] ?? null;
                if ($idCol && isset($user[$idCol])) {
                    $_SESSION['user_id'] = (int) $user[$idCol];
                }

                // Set user online otomatis setelah login berhasil
                if ($table == 'penjual' && isset($_SESSION['user_id'])) {
                    mysqli_query($conn, "UPDATE penjual SET status='online', is_online=1 WHERE id_penjual=" . (int) $_SESSION['user_id']);
                } elseif ($table == 'pembeli' && isset($_SESSION['user_id'])) {
                    mysqli_query($conn, "UPDATE pembeli SET status='online', is_online=1 WHERE id_pembeli=" . (int) $_SESSION['user_id']);
                }

                // redirect sesuai role
                if ($table == 'admin') header("Location: ../admin/dashboard_admin.php");
                elseif ($table == 'penjual') header("Location: ../penjual/dashboard_penjual.php");
                elseif ($table == 'pembeli') header("Location: ../pembeli/dashboard_pembeli.php");
                exit;
            } else {
                $error = "Password salah!";
            }

            $found = true;
            break; // keluar loop jika ditemukan
        }
    }

    if (!$found) {
        $error = "Username tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<script src="../assets/responsive.js" defer></script>
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Users</title>
<style>
body { font-family: Arial; background:#f0f2f5; display:flex; justify-content:center; align-items:center; height:100vh; }
.login-box { background:#fff; padding:20px; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.2); width:300px; text-align:center; }
.login-box h2 { margin-bottom:20px; }
.login-box input { width:100%; padding:10px; margin:5px 0; border:1px solid #ccc; border-radius:5px; }
.login-box button { width:100%; padding:10px; background:#007bff; color:#fff; border:none; border-radius:5px; cursor:pointer; }
.login-box button:hover { background:#0056b3; }
.login-box a { display:block; margin-top:10px; color:#007bff; text-decoration:none; }
.login-box a:hover { text-decoration:underline; }
.error { color:red; margin-bottom:10px; }
</style>
</head>
<body>
<div class="login-box">
    <h2>Login</h2>
    <?php if($error) echo "<div class='error'>$error</div>"; ?>
    <form method="post">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
    </form>
    <a href="reset_password.php">Reset Password</a>
</div>
</body>
</html>


