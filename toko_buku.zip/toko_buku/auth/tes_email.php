<?php
require 'mailer.php';

sendMail(
    'muhammadfaizaldo@gmail.com',
    'TES EMAIL TOKO',
    'Jika email ini masuk, maka sistem EMAIL KAMU SUDAH FIX.'
);
