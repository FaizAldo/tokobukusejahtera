<?php
session_start();
include '../conn/koneksi.php';

if (isset($_SESSION['user_id'], $_SESSION['user_role'])) {

    $user_id = $_SESSION['user_id'];
    $role    = $_SESSION['user_role'];

    if ($role == 'penjual') {
        mysqli_query($conn, "
            UPDATE penjual 
            SET status='offline', is_online=0 
            WHERE id_penjual = $user_id
        ");
    }

    if ($role == 'pembeli') {
        mysqli_query($conn, "
            UPDATE pembeli 
            SET status='offline', is_online=0 
            WHERE id_pembeli = $user_id
        ");
    }
}

session_unset();
session_destroy();

header("Location: ../landing/landing.html");
exit;
