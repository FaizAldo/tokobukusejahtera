<!DOCTYPE html>
<html lang="id">
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<title>Lupa Password</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Segoe UI, sans-serif;
}

body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:#f5eee8;
}

.container{
    width:850px;
    height:480px;
    background:#fff;
    display:flex;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 12px 35px rgba(0,0,0,.25);
}

/* FOTO */
.left{
    width:45%;
    background:linear-gradient(135deg,#8b5a2b,#6f431f);
    display:flex;
    justify-content:center;
    align-items:center;
}

.left img{
    width:80%;
    border-radius:12px;
}

/* FORM */
.right{
    width:55%;
    padding:45px;
}

.right h2{
    margin-bottom:20px;
    color:#6f431f;
}

.right input{
    width:100%;
    padding:13px;
    margin-bottom:14px;
    border-radius:10px;
    border:1px solid #d7b899;
    outline:none;
}

.right input:focus{
    border-color:#8b5a2b;
}

.right button{
    width:100%;
    padding:13px;
    background:#8b5a2b;
    color:#fff;
    border:none;
    border-radius:10px;
    font-size:16px;
    cursor:pointer;
    transition:.3s;
}

.right button:hover{
    background:#6f431f;
}

.link{
    margin-top:12px;
    text-align:center;
    color:#8b5a2b;
    font-weight:600;
    cursor:pointer;
}

.step{
    display:none;
}
.step.active{
    display:block;
}

@media(max-width:768px){
    .container{
        flex-direction:column;
        height:auto;
    }
    .left{
        display:none;
    }
}
</style>
</head>

<body>

<div class="container">

    <!-- FOTO -->
    <div class="left">
        <img src="../uploads/buku/TOKO BUKU SEJAHTERA.jpg">
    </div>

    <!-- FORM -->
    <div class="right">

        <!-- STEP 1 -->
        <div class="step active" id="step1">
            <h2>Lupa Password</h2>
            <form action="proses_lupa_password.php" method="post">
                <input type="email" name="email" placeholder="Masukkan Email" required>
                <button>Kirim Token</button>
            </form>

            <div class="link" onclick="showStep2()">
                Sudah punya token?
            </div>
        </div>

        <!-- STEP 2 -->
        <div class="step" id="step2">
            <h2>Reset Password</h2>
            <form action="proses_reset_password.php" method="post">
                <input type="email" name="email" placeholder="Email" required value="<?= htmlspecialchars($_GET['email'] ?? '') ?>">
                <input type="text" name="token" placeholder="Token dari Email" required value="<?= htmlspecialchars($_GET['token'] ?? '') ?>">
                <input type="hidden" name="role" value="<?= htmlspecialchars($_GET['role'] ?? '') ?>">
                <input type="password" name="password" placeholder="Password Baru" required>
                <input type="password" name="confirm" placeholder="Konfirmasi Password" required>
                <button>Reset Password</button>
            </form>

            <div class="link" onclick="showStep1()">
                Kembali ke Email
            </div>
        </div>

    </div>

</div>

<script>
function showStep2(){
    document.getElementById('step1').classList.remove('active');
    document.getElementById('step2').classList.add('active');
}
function showStep1(){
    document.getElementById('step2').classList.remove('active');
    document.getElementById('step1').classList.add('active');
}
<?php if (!empty($_GET['token'])): ?>
showStep2();
<?php endif; ?>
</script>

</body>
</html>


