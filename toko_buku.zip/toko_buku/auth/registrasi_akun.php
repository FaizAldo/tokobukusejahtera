<?php
session_start();
require '../conn/koneksi.php';
require '../notifikasi/notif_system.php';

$error = '';
$success = '';

// Jika form dikirim
if (isset($_POST['register'])) {
    $role = $_POST['role']; // 'pembeli' atau 'penjual'
    
    // Ambil data dari form
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];
    $no_hp    = trim($_POST['no_hp'] ?? '');
    $alamat   = trim($_POST['alamat'] ?? '');
    $foto     = 'default.png';
    $nik      = trim($_POST['nik'] ?? '');
    $nama_penjual = trim($_POST['nama_penjual'] ?? '');

    // Validasi sederhana
    if ($username == '' || $email == '' || $password == '' || $confirm == '') {
        $error = "Harap isi semua field yang wajib.";
    } elseif ($password !== $confirm) {
        $error = "Password dan konfirmasi password tidak sama.";
    } else {
        // Cek apakah email, username, atau NIK sudah ada
        if ($role === 'pembeli') {
            $cek = mysqli_query($conn, "SELECT * FROM pembeli WHERE email='$email' OR username='$username' OR nik='$nik'");
        } else {
            $cek = mysqli_query($conn, "SELECT * FROM penjual WHERE email='$email' OR username='$username'");
        }

        if (mysqli_num_rows($cek) > 0) {
            $error = "Email, username, atau NIK sudah terdaftar.";
        } else {
            // Upload foto jika ada
            if (!empty($_FILES['foto']['name'])) {
                $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
                $foto = time().'_'.rand(100,999).'.'.$ext;
                move_uploaded_file($_FILES['foto']['tmp_name'], '../uploads/'.$foto);
            }

            // Hash password
            $hash = password_hash($password, PASSWORD_DEFAULT);

            // Insert data
            if ($role === 'pembeli') {
                $sql = "INSERT INTO pembeli 
                        (nik, username, email, password, no_hp, foto, alamat, created_at, is_online, status) 
                        VALUES 
                        ('$nik', '$username', '$email', '$hash', '$no_hp', '$foto', '$alamat', NOW(), 0, 'offline')";
            } else {
                $sql = "INSERT INTO penjual 
                        (nama_penjual, username, email, password, foto, no_hp, alamat, created_at) 
                        VALUES 
                        ('$nama_penjual', '$username', '$email', '$hash', '$foto', '$no_hp', '$alamat', NOW())";
            }

            if (mysqli_query($conn, $sql)) {
                $success = "Registrasi berhasil! Silakan login.";
                if ($role === 'pembeli') {
                    kirimNotifKeSuperadmin("Registrasi pembeli baru: @$username");
                } else {
                    kirimNotifKeSuperadmin("Registrasi penjual baru: @$username");
                }
            } else {
                $error = "Terjadi kesalahan: " . mysqli_error($conn);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<script src="../assets/responsive.js" defer></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../assets/responsive.css">
<meta charset="UTF-8">
<title>Registrasi Akun</title>
<style>
body {
    font-family: Arial; 
    background: #f2f2f2; 
    display: flex; 
    justify-content: center; 
    align-items: center; 
    height: 100vh; 
    margin: 0;
}
.form-container {
    display: flex;
    background: #fff; 
    border-radius: 10px; 
    overflow: hidden;
    box-shadow: 0 0 15px rgba(0,0,0,0.1); 
    width: 800px; 
    max-width: 95%;
}
.form-image {
    flex: 1;
    background: url('../uploads/buku/TOKO BUKU SEJAHTERA.jpg') center/contain no-repeat;
    min-width: 250px;
    height: auto;
}

.form-box {
    flex: 1;
    padding: 30px;
}
h2{text-align:center;}
form {
    display: flex;
    flex-direction: column;
}
.form-grid {
    display: flex;
    gap: 15px;
}
.form-grid > div {
    flex: 1;
    display: flex;
    flex-direction: column;
}
input, select, button {
    width: 100%; 
    padding: 10px; 
    margin-top: 10px; 
    border-radius: 5px; 
    border: 1px solid #ccc; 
    box-sizing: border-box;
}
button {
    background: #007BFF; 
    color: #fff; 
    border: none; 
    cursor: pointer;
    transition: background 0.3s;
}
button:hover {background: #0056b3;}
.error {color: red; text-align:center; margin-bottom:10px;}
.success {color: green; text-align:center; margin-bottom:10px;}
.extra-link {text-align:center; margin-top:12px;}
.extra-link a {color: #007BFF; text-decoration:none; font-size:14px;}
.extra-link a:hover {text-decoration:underline;}
@media(max-width:768px){
    .form-container{
        flex-direction: column; 
        width: 90%;
    }
    .form-image{
        width: 100%;
        height: 200px;
    }
    .form-grid{
        flex-direction: column;
    }
}
</style>
</head>
<body>

<div class="form-container">
    <div class="form-image"></div> <!-- Gambar kiri -->

    <div class="form-box"> <!-- Form kanan -->
        <h2>Registrasi Akun</h2>

        <?php if($error) echo "<div class='error'>$error</div>"; ?>
        <?php if($success) echo "<div class='success'>$success</div>"; ?>

        <form method="post" enctype="multipart/form-data">
            <label>Pilih Akun:</label>
            <select name="role" id="role" onchange="toggleFields()">
                <option value="pembeli">Pembeli</option>
                <option value="penjual">Penjual</option>
            </select>

            <div class="form-grid">
                <!-- Kolom kiri -->
                <div>
                    <div id="pembeli_fields">
                        <input type="text" name="nik" placeholder="NIK (16 digit)">
                    </div>
                    <div id="penjual_fields" style="display:none;">
                        <input type="text" name="nama_penjual" placeholder="Nama Penjual">
                    </div>
                    <input type="text" name="username" placeholder="Username">
                    <input type="email" name="email" placeholder="Email">
                </div>

                <!-- Kolom kanan -->
                <div>
                    <input type="password" name="password" placeholder="Password">
                    <input type="password" name="confirm_password" placeholder="Konfirmasi Password">
                    <input type="text" name="no_hp" placeholder="No HP">
                    <input type="text" name="alamat" placeholder="Alamat">
                    <input type="file" name="foto" accept="image/*">
                </div>
            </div>

            <button type="submit" name="register">Daftar</button>
            <div class="extra-link">
                <a href="login_users.php">Sudah Daftar Akun? Silakan Login</a><br>
            </div>
        </form>
    </div>
</div>

<script>
function toggleFields() {
    var role = document.getElementById('role').value;
    document.getElementById('pembeli_fields').style.display = role === 'pembeli' ? 'block' : 'none';
    document.getElementById('penjual_fields').style.display = role === 'penjual' ? 'block' : 'none';
}
</script>
</body>
</html>


